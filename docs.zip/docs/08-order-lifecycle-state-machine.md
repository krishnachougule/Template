# 08 — Order Lifecycle State Machine

> **State Machine Specification**
> Stateless library · Transition rules · Guard conditions · Replayability

---

## 1. Overview

The Order Lifecycle State Machine governs every status transition for a Purchase Order. It ensures:

- **No invalid transitions** (e.g., cannot go from `Received` directly to `SubmittedForFulfillment`)
- **Auditable history** (every transition is recorded with timestamp, actor, and context)
- **Concurrency safety** (optimistic locking prevents conflicting updates)
- **Replayability** (failed orders can be replayed from their last valid state)

---

## 2. State Diagram

```
                            ┌─────────────────────┐
                            │                     │
                            ▼                     │
                    ┌───────────────┐             │
          ┌────────│   Received    │             │
          │        └───────┬───────┘             │
          │                │                      │
          │                ▼                      │
          │        ┌───────────────┐             │
          │        │  Validating   │             │
          │        └───┬───────┬───┘             │
          │            │       │                  │
          │     success│       │failure           │
          │            ▼       ▼                  │
          │    ┌──────────┐  ┌──────────────────┐│
          │    │ Validated │  │ ValidationFailed ││
          │    └─────┬─────┘  └──────────────────┘│
          │          │                             │
          │          ▼                             │
          │    ┌──────────┐                       │
          │    │Processing│                       │
          │    └──┬─────┬─┘                       │
          │       │     │                          │
          │success│     │failure                   │
          │       ▼     ▼                          │
          │ ┌─────────────────────────┐ ┌───────────────────────────────┐        │
          │ │SubmittedForFulfillment  │ │FulfillmentSubmissionFailed    │────────┘
          │ └────────────┬────────────┘ └───────────────────────────────┘  (via ReplayPending)
          │       │
          │       ▼
          │ ┌─────────────────────────┐
          │ │    Acknowledged         │
          │ │    OR                   │
          │ │    PartiallyAcknowledged│
          │ │    OR                   │
          │ │    Rejected             │
          │ └─────────────────────────┘
          │
          │   (from any non-terminal state)
          └──────────► ┌───────────┐
                       │ Cancelled │
                       └───────────┘
```

---

## 3. State Definitions

| State | Code | Terminal? | Description |
|-------|------|-----------|-------------|
| `Received` | 0 | No | Order payload stored. Awaiting validation. |
| `Validating` | 10 | No | Account validation in progress. |
| `Validated` | 20 | No | All account fields validated successfully. |
| `ValidationFailed` | 25 | Yes* | Validation rejected the order. *Can be replayed.* |
| `Processing` | 30 | No | Order being transformed for fulfillment submission. |
| `SubmittedForFulfillment` | 40 | No | Order successfully submitted to the fulfillment system. |
| `FulfillmentSubmissionFailed` | 45 | Yes* | Fulfillment submission failed after retries. *Can be replayed.* |
| `Acknowledged` | 50 | Yes | Full POA received — all items confirmed. |
| `PartiallyAcknowledged` | 55 | Yes | POA received — some items backordered/rejected. |
| `Rejected` | 60 | Yes | Order fully rejected by downstream. |
| `Cancelled` | 70 | Yes | Order cancelled by client or operator. |
| `ReplayPending` | 80 | No | Order queued for reprocessing from a prior state. |

> *States marked "Yes*" are **soft-terminal**: they are end-states under normal flow but can be transitioned to `ReplayPending` by an admin replay action.

---

## 4. Transition Rules

| From State | To State | Trigger | Guard Condition |
|------------|----------|---------|-----------------|
| `Received` | `Validating` | `BeginValidation` | Order has required header fields |
| `Validating` | `Validated` | `ValidationSucceeded` | Validation result `isValid == true` |
| `Validating` | `ValidationFailed` | `ValidationFailed` | Validation result `isValid == false` or timeout |
| `Validated` | `Processing` | `BeginProcessing` | Consumer picks up Kafka event |
| `Processing` | `SubmittedForFulfillment` | `FulfillmentSubmissionSucceeded` | Fulfillment submission confirmed |
| `Processing` | `FulfillmentSubmissionFailed` | `FulfillmentSubmissionFailed` | Fulfillment submission failed after retries |
| `SubmittedForFulfillment` | `Acknowledged` | `AcknowledgementReceived` | Full acknowledgement from downstream |
| `SubmittedForFulfillment` | `PartiallyAcknowledged` | `PartialAcknowledgementReceived` | Partial acknowledgement |
| `SubmittedForFulfillment` | `Rejected` | `OrderRejected` | Full rejection from downstream |
| `ValidationFailed` | `ReplayPending` | `ReplayRequested` | Admin triggers replay |
| `FulfillmentSubmissionFailed` | `ReplayPending` | `ReplayRequested` | Admin triggers replay |
| `ReplayPending` | `Validating` | `BeginValidation` | Replay from validation stage |
| `ReplayPending` | `Processing` | `BeginProcessing` | Replay from processing stage |
| `*` (any non-terminal) | `Cancelled` | `CancelOrder` | Not in a terminal state |

---

## 5. Trigger Definitions

```csharp
namespace OrderService.Domain.StateMachine;

/// <summary>
/// All triggers (commands) that cause state transitions.
/// </summary>
public enum OrderTrigger
{
    BeginValidation,
    ValidationSucceeded,
    ValidationFailed,
    BeginProcessing,
    FulfillmentSubmissionSucceeded,
    FulfillmentSubmissionFailed,
    AcknowledgementReceived,
    PartialAcknowledgementReceived,
    OrderRejected,
    ReplayRequested,
    CancelOrder
}
```

---

## 6. Stateless Library Configuration

```csharp
using Stateless;

namespace OrderService.Domain.StateMachine;

/// <summary>
/// Configures the order lifecycle state machine using the Stateless library.
/// The state machine does NOT persist itself — the PurchaseOrder entity
/// holds the current state, and transitions are persisted via EF Core.
/// </summary>
public sealed class OrderLifecycleStateMachine
{
    private readonly StateMachine<OrderStatus, OrderTrigger> _machine;
    private readonly PurchaseOrder _order;

    public OrderLifecycleStateMachine(PurchaseOrder order)
    {
        _order = order;
        _machine = new StateMachine<OrderStatus, OrderTrigger>(
            () => _order.CurrentStatus,
            s => { /* State is set via _order.TransitionTo() in entry actions */ });

        Configure();
    }

    public OrderStatus CurrentState => _machine.State;

    public bool CanFire(OrderTrigger trigger) => _machine.CanFire(trigger);

    public IEnumerable<OrderTrigger> PermittedTriggers => _machine.PermittedTriggers;

    public void Fire(OrderTrigger trigger) => _machine.Fire(trigger);

    private void Configure()
    {
        // ── Received ──
        _machine.Configure(OrderStatus.Received)
            .Permit(OrderTrigger.BeginValidation, OrderStatus.Validating)
            .Permit(OrderTrigger.CancelOrder, OrderStatus.Cancelled);

        // ── Validating ──
        _machine.Configure(OrderStatus.Validating)
            .Permit(OrderTrigger.ValidationSucceeded, OrderStatus.Validated)
            .Permit(OrderTrigger.ValidationFailed, OrderStatus.ValidationFailed)
            .Permit(OrderTrigger.CancelOrder, OrderStatus.Cancelled);

        // ── Validated ──
        _machine.Configure(OrderStatus.Validated)
            .Permit(OrderTrigger.BeginProcessing, OrderStatus.Processing)
            .Permit(OrderTrigger.CancelOrder, OrderStatus.Cancelled);

        // ── ValidationFailed (soft-terminal) ──
        _machine.Configure(OrderStatus.ValidationFailed)
            .Permit(OrderTrigger.ReplayRequested, OrderStatus.ReplayPending);

        // ── Processing ──
        _machine.Configure(OrderStatus.Processing)
            .Permit(OrderTrigger.FulfillmentSubmissionSucceeded, OrderStatus.SubmittedForFulfillment)
            .Permit(OrderTrigger.FulfillmentSubmissionFailed, OrderStatus.FulfillmentSubmissionFailed)
            .Permit(OrderTrigger.CancelOrder, OrderStatus.Cancelled);

        // ── SubmittedForFulfillment ──
        _machine.Configure(OrderStatus.SubmittedForFulfillment)
            .Permit(OrderTrigger.AcknowledgementReceived, OrderStatus.Acknowledged)
            .Permit(OrderTrigger.PartialAcknowledgementReceived, 
                    OrderStatus.PartiallyAcknowledged)
            .Permit(OrderTrigger.OrderRejected, OrderStatus.Rejected);

        // ── FulfillmentSubmissionFailed (soft-terminal) ──
        _machine.Configure(OrderStatus.FulfillmentSubmissionFailed)
            .Permit(OrderTrigger.ReplayRequested, OrderStatus.ReplayPending);

        // ── ReplayPending ──
        _machine.Configure(OrderStatus.ReplayPending)
            .Permit(OrderTrigger.BeginValidation, OrderStatus.Validating)
            .Permit(OrderTrigger.BeginProcessing, OrderStatus.Processing);

        // ── Terminal states: no outgoing transitions ──
        _machine.Configure(OrderStatus.Acknowledged);
        _machine.Configure(OrderStatus.PartiallyAcknowledged);
        _machine.Configure(OrderStatus.Rejected);
        _machine.Configure(OrderStatus.Cancelled);
    }
}
```

---

## 7. State Transition Orchestration

### 7.1 Usage in API Module (Validation Flow)

```csharp
// Pseudocode: How the state machine is used during order processing

public async Task<OrderResponse> ProcessOrderAsync(PurchaseOrderRequest request, ...)
{
    // 1. Create order entity with Received status
    var order = CreateOrderEntity(request);
    await _repository.AddAsync(order);  // Persists as Received

    // 2. Transition: Received → Validating
    var sm = new OrderLifecycleStateMachine(order);
    sm.Fire(OrderTrigger.BeginValidation);
    order.TransitionTo(OrderStatus.Validating, "Account validation started.");
    await _repository.UpdateAsync(order);

    // 3. Call external validation
    var result = await _validationClient.ValidateAsync(validationRequest, ...);

    if (result.IsValid)
    {
        // 4a. Transition: Validating → Validated
        sm.Fire(OrderTrigger.ValidationSucceeded);
        order.TransitionTo(OrderStatus.Validated, "Validation passed.");
        await _repository.UpdateAsync(order);

        // 5. Publish to Kafka
        await _eventProducer.PublishAsync("icg.orders.validated", ...);
    }
    else
    {
        // 4b. Transition: Validating → ValidationFailed
        sm.Fire(OrderTrigger.ValidationFailed);
        order.TransitionTo(OrderStatus.ValidationFailed, 
            $"Validation failed: {result.Errors.First().Message}");
        await _repository.UpdateAsync(order);
    }

    return MapToResponse(order);
}
```

### 7.2 Usage in Worker Module (MQ Delivery Flow)

```csharp
// Pseudocode: Worker consumer handling

public async Task HandleOrderValidatedAsync(OrderValidatedEvent event, ...)
{
    var order = await _repository.GetByTrackingIdAsync(event.TrackingId);
    var sm = new OrderLifecycleStateMachine(order);

    // Transition: Validated → Processing
    sm.Fire(OrderTrigger.BeginProcessing);
    order.TransitionTo(OrderStatus.Processing, "Fulfillment submission started.");
    await _repository.UpdateAsync(order);

    try
    {
        var mqMessageId = await _mqProducer.SendAsync(order);

        // Transition: Processing → SubmittedForFulfillment
        sm.Fire(OrderTrigger.FulfillmentSubmissionSucceeded);
        order.SetMqDelivery(mqMessageId);
        order.TransitionTo(OrderStatus.SubmittedForFulfillment, 
            $"Order submitted for fulfillment. Reference: {mqMessageId}");
        await _repository.UpdateAsync(order);

        await _eventProducer.PublishAsync("icg.orders.submitted-for-fulfillment", ...);
    }
    catch (Exception ex)
    {
        // Transition: Processing → FulfillmentSubmissionFailed
        sm.Fire(OrderTrigger.FulfillmentSubmissionFailed);
        order.TransitionTo(OrderStatus.FulfillmentSubmissionFailed, 
            $"Fulfillment submission failed: {ex.Message}");
        await _repository.UpdateAsync(order);
    }
}
```

---

## 8. Concurrency Control

| Mechanism | Implementation |
|-----------|---------------|
| **Optimistic Locking** | `Version` column (integer) incremented on every update |
| **EF Core Token** | `IsConcurrencyToken()` on `Version` property |
| **Conflict Resolution** | On `DbUpdateConcurrencyException`, re-read the entity and retry the state machine transition |
| **Max Retries** | 3 attempts for concurrency conflicts before failing |

### Conflict Scenario

```
Time 0: Worker A reads Order (version = 3)
Time 1: Worker B reads Order (version = 3)
Time 2: Worker A updates Order (version = 3 → 4) ✅ Success
Time 3: Worker B updates Order (version = 3 → 4) ❌ DbUpdateConcurrencyException
Time 4: Worker B re-reads Order (version = 4), re-evaluates state machine, retries
```

---

## 9. Replayability Design

### 9.1 Replay Flow

```
Admin triggers: POST /api/v1/admin/orders/{trackingId}/replay
  │
  ├── Load order from DB (current state: FulfillmentSubmissionFailed or ValidationFailed)
  │
  ├── Create state machine, verify ReplayRequested is permitted
  │
  ├── Transition: FulfillmentSubmissionFailed → ReplayPending
  │
  ├── Determine replay starting point:
  │     ├── If FulfillmentSubmissionFailed → replay from Processing (re-submit to fulfillment)
  │     └── If ValidationFailed → replay from Validating (re-validate)
  │
  ├── Transition: ReplayPending → Validating/Processing
  │
  └── Re-publish appropriate Kafka event to trigger the Worker
```

### 9.2 Raw Payload for Replay

The `raw_payload` JSONB column in the `orders` table stores the **exact** incoming JSON. During replay:

1. The system reads `raw_payload` from the database
2. Re-parses it as if it were a fresh submission
3. Re-processes from the determined starting state
4. All previous status history is preserved (not overwritten)

This ensures complete auditability — the replay is just another set of transitions appended to `order_status_history`.

---

## 10. State Machine Visualization (DOT Format)

For generating diagrams from the state machine configuration:

```dot
digraph OrderLifecycle {
    rankdir=LR;
    node [shape=box, style=rounded];
    
    Received -> Validating [label="BeginValidation"];
    Validating -> Validated [label="ValidationSucceeded"];
    Validating -> ValidationFailed [label="ValidationFailed"];
    Validated -> Processing [label="BeginProcessing"];
    Processing -> SubmittedForFulfillment [label="FulfillmentSubmissionSucceeded"];
    Processing -> FulfillmentSubmissionFailed [label="FulfillmentSubmissionFailed"];
    SubmittedForFulfillment -> Acknowledged [label="AckReceived"];
    SubmittedForFulfillment -> PartiallyAcknowledged [label="PartialAck"];
    SubmittedForFulfillment -> Rejected [label="OrderRejected"];
    
    ValidationFailed -> ReplayPending [label="ReplayRequested", style=dashed];
    FulfillmentSubmissionFailed -> ReplayPending [label="ReplayRequested", style=dashed];
    ReplayPending -> Validating [label="BeginValidation", style=dashed];
    ReplayPending -> Processing [label="BeginProcessing", style=dashed];
    
    Received -> Cancelled [label="Cancel"];
    Validating -> Cancelled [label="Cancel"];
    Validated -> Cancelled [label="Cancel"];
    Processing -> Cancelled [label="Cancel"];
    
    // Terminal states
    Acknowledged [style="rounded,filled", fillcolor="#90EE90"];
    PartiallyAcknowledged [style="rounded,filled", fillcolor="#FFD700"];
    Rejected [style="rounded,filled", fillcolor="#FF6347"];
    Cancelled [style="rounded,filled", fillcolor="#D3D3D3"];
    ValidationFailed [style="rounded,filled", fillcolor="#FFA07A"];
    FulfillmentSubmissionFailed [style="rounded,filled", fillcolor="#FFA07A"];
}
```
