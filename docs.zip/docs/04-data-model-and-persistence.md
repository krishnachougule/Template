# 04 — Data Model & Persistence

> **PostgreSQL Schema Design**
> JSONB raw payload storage · EF Core mapping · Audit trail · Indexes

---

## 1. Design Principles

| Principle | Implementation |
|-----------|---------------|
| **Raw Payload Preservation** | Store the incoming PO JSON *as-is* in a JSONB column for auditability and replayability |
| **Normalized Relational Model** | Parse and store critical fields in typed columns for fast querying and indexing |
| **Event Sourcing Lite** | Track all state transitions in a history table (not full event sourcing, but complete lifecycle visibility) |
| **Temporal Consistency** | All timestamps are `TIMESTAMPTZ` (UTC). Application and database share the same timezone convention. |
| **Soft Delete** | Records are never physically deleted. Use `is_deleted` flags where applicable. |

---

## 2. Entity Relationship Diagram

```
┌──────────────────────────────────────────┐
│                 orders                    │
│──────────────────────────────────────────│
│ PK  id                 UUID              │
│     tracking_id        UUID (UNIQUE)     │
│     po_number          VARCHAR(50)       │
│     account_number     VARCHAR(20)       │
│     bill_to_account    VARCHAR(20)       │
│     ship_to_account    VARCHAR(20)       │
│     current_status     VARCHAR(30)       │
│     raw_payload        JSONB             │◄── Raw PO as-is
│     version            INTEGER           │◄── Optimistic concurrency
│     received_at        TIMESTAMPTZ       │
│     last_updated_at    TIMESTAMPTZ       │
│     created_by         VARCHAR(64)       │
└──────────┬───────────────────────────────┘
           │ 1
           │
           │ N
┌──────────┴───────────────────────────────┐
│            order_line_items               │
│──────────────────────────────────────────│
│ PK  id                 UUID              │
│ FK  order_id           UUID              │
│     line_number        INTEGER           │
│     line_po_number     VARCHAR(30)       │
│     item_number        VARCHAR(20)       │◄── ISBN / EAN
│     item_number_type   VARCHAR(10)       │
│     quantity           INTEGER           │
│     unit_price         DECIMAL(10,2)     │
│     backorder_code     VARCHAR(5)        │
│     department_code    VARCHAR(10)       │
│     enrichment_data    JSONB             │◄── "enriched?" fields
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│          order_status_history             │
│──────────────────────────────────────────│
│ PK  id                 BIGSERIAL         │
│ FK  order_id           UUID              │
│     status             VARCHAR(30)       │
│     message            TEXT              │
│     metadata           JSONB             │◄── Contextual data
│     occurred_at        TIMESTAMPTZ       │
│     actor              VARCHAR(64)       │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│            order_audit_log                │
│──────────────────────────────────────────│
│ PK  id                 BIGSERIAL         │
│ FK  order_id           UUID              │
│     action             VARCHAR(10)       │◄── INSERT/UPDATE/DELETE
│     old_data           JSONB             │
│     new_data           JSONB             │
│     changed_fields     TEXT[]            │
│     changed_at         TIMESTAMPTZ       │
│     changed_by         VARCHAR(64)       │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│         webhook_subscriptions             │
│──────────────────────────────────────────│
│ PK  id                 UUID              │
│     client_id          VARCHAR(64)       │
│     callback_url       VARCHAR(2048)     │
│     events             TEXT[]            │
│     secret_hash        VARCHAR(128)      │
│     status             VARCHAR(20)       │
│     created_at         TIMESTAMPTZ       │
│     updated_at         TIMESTAMPTZ       │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│          webhook_delivery_log             │
│──────────────────────────────────────────│
│ PK  id                 BIGSERIAL         │
│ FK  webhook_id         UUID              │
│ FK  order_id           UUID              │
│     event_type         VARCHAR(50)       │
│     payload            JSONB             │
│     http_status        INTEGER           │
│     attempt_number     INTEGER           │
│     delivered_at       TIMESTAMPTZ       │
│     next_retry_at      TIMESTAMPTZ       │
│     is_successful      BOOLEAN           │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│           idempotency_keys                │
│──────────────────────────────────────────│
│ PK  key                VARCHAR(128)      │
│     client_id          VARCHAR(64)       │
│     response_code      INTEGER           │
│     response_body      JSONB             │
│     created_at         TIMESTAMPTZ       │
│     expires_at         TIMESTAMPTZ       │
└──────────────────────────────────────────┘
```

---

## 3. DDL — Table Definitions

### 3.1 Orders Table

```sql
CREATE TABLE orders (
    id                UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    tracking_id       UUID            NOT NULL UNIQUE DEFAULT gen_random_uuid(),
    po_number         VARCHAR(50)     NOT NULL,
    account_number    VARCHAR(20)     NOT NULL,
    bill_to_account   VARCHAR(20),
    ship_to_account   VARCHAR(20),
    order_date        DATE,
    current_status    VARCHAR(30)     NOT NULL DEFAULT 'Received',
    raw_payload       JSONB           NOT NULL,
    parsed_header     JSONB,                         -- Parsed orderHeader + customerOrderHeader
    purchase_options  JSONB,                          -- purchaseOrderOptions
    version           INTEGER         NOT NULL DEFAULT 1,  -- Optimistic concurrency token
    mq_message_id     VARCHAR(100),                   -- IBM MQ correlation ID
    mq_posted_at      TIMESTAMPTZ,
    validation_result JSONB,                          -- Cached validation response
    error_details     JSONB,                          -- Failure context
    received_at       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    last_updated_at   TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by        VARCHAR(64)     NOT NULL,       -- Client ID from auth
    is_deleted        BOOLEAN         NOT NULL DEFAULT FALSE,
    
    CONSTRAINT chk_status CHECK (current_status IN (
        'Received', 'Validating', 'Validated', 'ValidationFailed',
        'Processing', 'PostedToMQ', 'FailedToPostMQ',
        'Acknowledged', 'PartiallyAcknowledged', 'Rejected',
        'Cancelled', 'ReplayPending'
    ))
);

COMMENT ON COLUMN orders.raw_payload IS 
    'Stores the raw incoming PO JSON payload as-is for audit and replay purposes';
COMMENT ON COLUMN orders.version IS 
    'Optimistic concurrency token. Incremented on every update.';
```

### 3.2 Order Line Items Table

```sql
CREATE TABLE order_line_items (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id            UUID            NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    line_number         INTEGER         NOT NULL,
    line_po_number      VARCHAR(30),
    item_number         VARCHAR(20)     NOT NULL,     -- ISBN / EAN
    item_number_type    VARCHAR(10)     DEFAULT 'IB', -- IB = ISBN
    quantity            INTEGER         NOT NULL,
    unit_price          DECIMAL(10,2),
    backorder_code      VARCHAR(5),
    special_action_code VARCHAR(10),
    ddc_fulfillment     BOOLEAN         DEFAULT FALSE,
    department_code     VARCHAR(10),
    gift_wrap_code      VARCHAR(10),
    secondary_item_no   VARCHAR(30),                  -- SKU
    backorder_cancel_dt DATE,
    enrichment_data     JSONB,                        -- Library enrichment fields
    
    CONSTRAINT uq_order_line UNIQUE (order_id, line_number)
);

COMMENT ON COLUMN order_line_items.enrichment_data IS 
    'Stores optional library enrichment fields (agencyFund, branch, barcode, etc.)';
```

### 3.3 Order Status History Table

```sql
CREATE TABLE order_status_history (
    id              BIGSERIAL       PRIMARY KEY,
    order_id        UUID            NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    status          VARCHAR(30)     NOT NULL,
    previous_status VARCHAR(30),
    message         TEXT,
    metadata        JSONB,          -- e.g., { "validationErrors": [...] }
    occurred_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    actor           VARCHAR(64)     NOT NULL DEFAULT 'system'
);

COMMENT ON TABLE order_status_history IS 
    'Complete lifecycle history for every order status transition. Append-only.';
```

### 3.4 Order Audit Log Table

```sql
CREATE TABLE order_audit_log (
    id              BIGSERIAL       PRIMARY KEY,
    order_id        UUID            NOT NULL,
    action          VARCHAR(10)     NOT NULL,   -- INSERT, UPDATE, DELETE
    old_data        JSONB,
    new_data        JSONB,
    changed_fields  TEXT[],                     -- Array of changed column names
    changed_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    changed_by      VARCHAR(64)     NOT NULL DEFAULT 'system'
);
```

### 3.5 Webhook Tables

```sql
CREATE TABLE webhook_subscriptions (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id       VARCHAR(64)     NOT NULL,
    callback_url    VARCHAR(2048)   NOT NULL,
    events          TEXT[]          NOT NULL,     -- e.g., {'order.validated', 'order.failed'}
    secret_hash     VARCHAR(128)    NOT NULL,     -- Hashed HMAC secret
    status          VARCHAR(20)     NOT NULL DEFAULT 'active',
    failure_count   INTEGER         NOT NULL DEFAULT 0,
    last_failure_at TIMESTAMPTZ,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_webhook_status CHECK (status IN ('active', 'paused', 'disabled'))
);

CREATE TABLE webhook_delivery_log (
    id              BIGSERIAL       PRIMARY KEY,
    webhook_id      UUID            NOT NULL REFERENCES webhook_subscriptions(id),
    order_id        UUID            NOT NULL,
    event_type      VARCHAR(50)     NOT NULL,
    payload         JSONB           NOT NULL,
    http_status     INTEGER,
    response_body   TEXT,
    attempt_number  INTEGER         NOT NULL DEFAULT 1,
    delivered_at    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    next_retry_at   TIMESTAMPTZ,
    is_successful   BOOLEAN         NOT NULL DEFAULT FALSE,
    error_message   TEXT
);
```

---

## 4. Indexes

```sql
-- === Orders ===
CREATE UNIQUE INDEX idx_orders_tracking_id  ON orders (tracking_id);
CREATE INDEX        idx_orders_po_number    ON orders (po_number);
CREATE INDEX        idx_orders_account      ON orders (account_number);
CREATE INDEX        idx_orders_status       ON orders (current_status);
CREATE INDEX        idx_orders_received_at  ON orders (received_at DESC);
CREATE INDEX        idx_orders_raw_payload  ON orders USING GIN (raw_payload);

-- === Line Items ===
CREATE INDEX idx_line_items_order    ON order_line_items (order_id);
CREATE INDEX idx_line_items_isbn     ON order_line_items (item_number);

-- === Status History ===
CREATE INDEX idx_status_history_order ON order_status_history (order_id, occurred_at DESC);

-- === Audit Log ===
CREATE INDEX idx_audit_order         ON order_audit_log (order_id);
CREATE INDEX idx_audit_changed_at    ON order_audit_log (changed_at DESC);
CREATE INDEX idx_audit_data          ON order_audit_log USING GIN (new_data);

-- === Webhooks ===
CREATE INDEX idx_webhook_client      ON webhook_subscriptions (client_id);
CREATE INDEX idx_webhook_delivery    ON webhook_delivery_log (webhook_id, delivered_at DESC);
CREATE INDEX idx_webhook_retry       ON webhook_delivery_log (next_retry_at) 
    WHERE is_successful = FALSE AND next_retry_at IS NOT NULL;

-- === Idempotency ===
CREATE INDEX idx_idempotency_expires ON idempotency_keys (expires_at);
```

---

## 5. PostgreSQL Audit Trigger

```sql
-- Audit trigger function: captures all changes to the orders table
CREATE OR REPLACE FUNCTION fn_orders_audit() 
RETURNS TRIGGER AS $$
DECLARE
    v_changed_fields TEXT[];
    v_changed_by TEXT;
BEGIN
    -- Read application context (set via SET LOCAL in EF Core)
    BEGIN
        v_changed_by := current_setting('audit.current_user', true);
    EXCEPTION WHEN OTHERS THEN
        v_changed_by := 'system';
    END;
    
    IF v_changed_by IS NULL OR v_changed_by = '' THEN
        v_changed_by := 'system';
    END IF;

    -- Calculate changed fields for UPDATE operations
    IF TG_OP = 'UPDATE' THEN
        SELECT ARRAY_AGG(key) INTO v_changed_fields
        FROM (
            SELECT key FROM jsonb_each(to_jsonb(NEW)) 
            EXCEPT 
            SELECT key FROM jsonb_each(to_jsonb(OLD))
                WHERE (to_jsonb(NEW))->>key = (to_jsonb(OLD))->>key
        ) diff;
    END IF;

    INSERT INTO order_audit_log (
        order_id, action, old_data, new_data, changed_fields, changed_by
    ) VALUES (
        COALESCE(NEW.id, OLD.id),
        TG_OP,
        CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN to_jsonb(OLD) END,
        CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN to_jsonb(NEW) END,
        v_changed_fields,
        v_changed_by
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_audit
    AFTER INSERT OR UPDATE OR DELETE ON orders
    FOR EACH ROW EXECUTE FUNCTION fn_orders_audit();
```

---

## 6. EF Core Entity Configuration Strategy

### 6.1 DbContext Registration

```
OrderDbContext
├── DbSet<Order>               Orders
├── DbSet<OrderLineItem>       OrderLineItems
├── DbSet<OrderStatusHistory>  OrderStatusHistory
├── DbSet<WebhookSubscription> WebhookSubscriptions
├── DbSet<IdempotencyKey>      IdempotencyKeys
└── (Read-only) OrderAuditLog  via raw SQL or view
```

### 6.2 Key Mapping Decisions

| EF Core Feature | Configuration |
|-----------------|---------------|
| **Primary Keys** | `UUID` via `gen_random_uuid()` (database-generated) |
| **Concurrency Token** | `Version` property with `IsRowVersion()` for optimistic concurrency |
| **JSONB Columns** | Use EF Core's native `ToJson()` mapping for `raw_payload`, `enrichment_data`, `metadata` |
| **Value Converters** | `OrderStatus` enum → `VARCHAR(30)` via value converter |
| **Query Filters** | Global filter: `.HasQueryFilter(o => !o.IsDeleted)` |
| **Shadow Properties** | `LastUpdatedAt` updated automatically via `SaveChanges` interceptor |

### 6.3 Optimistic Concurrency Example

```
// EF Core configuration
builder.Property(o => o.Version)
    .HasColumnName("version")
    .IsConcurrencyToken();

// On update, EF Core generates:
// UPDATE orders SET ..., version = version + 1
// WHERE id = @id AND version = @expectedVersion
```

---

## 7. Data Retention & Maintenance

| Table | Retention | Strategy |
|-------|-----------|----------|
| `orders` | Indefinite | Soft delete (`is_deleted = TRUE`). Archive after 2 years. |
| `order_line_items` | Same as parent order | Cascading soft delete |
| `order_status_history` | Indefinite | Append-only. Partition by `occurred_at` yearly. |
| `order_audit_log` | 3 years | Partition by `changed_at` monthly. Drop old partitions. |
| `webhook_delivery_log` | 90 days | Purge via scheduled job. |
| `idempotency_keys` | 24 hours | Purge expired rows via pg_cron or app-level job. |

### Partitioning Strategy (Audit Log)

```sql
-- Partition order_audit_log by month for efficient purging
CREATE TABLE order_audit_log (
    id              BIGSERIAL,
    order_id        UUID            NOT NULL,
    action          VARCHAR(10)     NOT NULL,
    old_data        JSONB,
    new_data        JSONB,
    changed_fields  TEXT[],
    changed_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    changed_by      VARCHAR(64)     NOT NULL DEFAULT 'system'
) PARTITION BY RANGE (changed_at);

-- Create monthly partitions
CREATE TABLE order_audit_log_2026_07 PARTITION OF order_audit_log
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE TABLE order_audit_log_2026_08 PARTITION OF order_audit_log
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
-- ... automated via pg_partman or application-level migration
```
