# 10 — Tracking & Webhooks

> **Client Order Tracking & POA Webhook Callbacks**
> GET endpoint · Webhook subscriptions · POA payload · Retry delivery

---

## 1. Overview

The Order Service provides two mechanisms for clients to track order status:

| Mechanism | Pattern | Use Case |
|-----------|---------|----------|
| **GET Endpoint** | Pull (polling) | Client queries status on demand |
| **Webhook Callbacks** | Push (event-driven) | Server pushes status changes to client URL |

Both mechanisms use the `trackingId` (UUIDv7) returned at order submission as the primary lookup key.

---

## 2. GET Tracking Endpoint

### 2.1 Endpoint: `GET /api/v1/orders/{trackingId}/status`

See [03-api-specification.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/03-api-specification.md) § 5.2 for the full contract.

### 2.2 Response Model

```json
{
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "poNumber": "CUST-PO-001",
  "accountNumber": "20BE991",
  "currentStatus": "SubmittedForFulfillment",
  "currentStatusMessage": "Order posted to fulfillment system.",
  "lastUpdatedAt": "2026-07-26T14:31:05.000Z",
  "statusHistory": [
    {
      "status": "Received",
      "message": "Order received and stored.",
      "occurredAt": "2026-07-26T14:30:00.000Z"
    },
    {
      "status": "Validating",
      "message": "Account validation in progress.",
      "occurredAt": "2026-07-26T14:30:01.000Z"
    },
    {
      "status": "Validated",
      "message": "Account validation successful.",
      "occurredAt": "2026-07-26T14:30:03.000Z"
    },
    {
      "status": "Processing",
      "message": "Order transformation and delivery in progress.",
      "occurredAt": "2026-07-26T14:30:45.000Z"
    },
    {
      "status": "SubmittedForFulfillment",
      "message": "Order posted to fulfillment system.",
      "occurredAt": "2026-07-26T14:31:05.000Z"
    }
  ]
}
```

### 2.3 Query Optimization

```sql
-- Optimized query: single round-trip with lateral join
SELECT 
    o.tracking_id,
    o.po_number,
    o.account_number,
    o.current_status,
    o.last_updated_at,
    h.history
FROM orders o
LEFT JOIN LATERAL (
    SELECT jsonb_agg(
        jsonb_build_object(
            'status', sh.status,
            'message', sh.message,
            'occurredAt', sh.occurred_at
        ) ORDER BY sh.occurred_at ASC
    ) AS history
    FROM order_status_history sh
    WHERE sh.order_id = o.id
) h ON TRUE
WHERE o.tracking_id = @trackingId;
```

---

## 3. Webhook System Design

### 3.1 Architecture

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  Order Status    │     │  Webhook         │     │  Client          │
│  Change          │────▶│  Dispatcher      │────▶│  Callback URL    │
│  (Kafka event)   │     │  (Worker Module) │     │                  │
└──────────────────┘     └────────┬─────────┘     └──────────────────┘
                                  │
                                  ▼
                         ┌──────────────────┐
                         │  Delivery Log    │
                         │  (PostgreSQL)    │
                         └──────────────────┘
```

### 3.2 Subscription Model

Clients register for specific events. Only matching events trigger callbacks.

**Supported Events:**

| Event Type | Trigger |
|------------|---------|
| `order.received` | Order initially stored |
| `order.validated` | Account validation succeeded |
| `order.validation_failed` | Account validation failed |
| `order.submitted_for_fulfillment` | Order submitted to fulfillment system |
| `order.acknowledged` | Full POA received |
| `order.partially_acknowledged` | Partial POA received |
| `order.rejected` | Order rejected by downstream |
| `order.failed` | Any failure state (catch-all) |

### 3.3 Subscription Registration

```
POST /api/v1/webhooks
```

```json
{
  "callbackUrl": "https://partner.example.com/webhooks/orders",
  "events": ["order.validated", "order.submitted_for_fulfillment", "order.acknowledged"],
  "secret": "whsec_my_secret_key_for_hmac_signing"
}
```

> The `secret` is used to generate HMAC-SHA256 signatures on outgoing webhook payloads, allowing the client to verify authenticity.

---

## 4. Webhook Callback Payload

### 4.1 Standard Callback Format

Every webhook callback includes the following structure:

```
POST https://partner.example.com/webhooks/orders
Content-Type: application/json
X-Webhook-Id: wh_evt_0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b
X-Webhook-Timestamp: 1753539065
X-Webhook-Signature: sha256=d4f5a8b3c2e1...
X-Correlation-Id: corr-abc123
```

```json
{
  "webhookId": "wh_evt_0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "eventType": "order.acknowledged",
  "occurredAt": "2026-07-26T15:00:00.000Z",
  "data": {
    "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "poNumber": "CUST-PO-001",
    "accountNumber": "20BE991",
    "currentStatus": "Acknowledged",
    "previousStatus": "SubmittedForFulfillment",
    "statusMessage": "Order fully acknowledged by fulfillment system."
  }
}
```

### 4.2 POA Acknowledgement Callback (Full Detail)

When the event is `order.acknowledged` or `order.partially_acknowledged`, the payload includes the full POA detail:

```json
{
  "webhookId": "wh_evt_0192f8a0-...",
  "eventType": "order.acknowledged",
  "occurredAt": "2026-07-26T15:00:00.000Z",
  "data": {
    "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "poNumber": "CUST-PO-001",
    "accountNumber": "20BE991",
    "shipToAccountNumber": "1234567",
    "currentStatus": "Acknowledged",
    "acknowledgement": {
      "transactionOrderCode": "TOC0000000001",
      "acknowledgementStatus": "Acknowledged",
      "acknowledgementDate": "2026-07-26",
      "acknowledgementType": "full confirmation",
      "cancellationDate": "2026-08-31",
      "vendorMessages": [
        { "message": "Order received and processed successfully" }
      ],
      "items": [
        {
          "lineItemPurchaseOrderNumber": "LINE000001",
          "itemNumber": "9781234567890",
          "statusCode": "OK",
          "warehouseCode": "N",
          "shippableQuantity": 2,
          "availabilityDate": "2026-07-30",
          "discountCode": "A",
          "title": "",
          "author": "",
          "publisher": "",
          "discountPercentage": 99.99
        },
        {
          "lineItemPurchaseOrderNumber": "LINE000002",
          "itemNumber": "9780987654321",
          "statusCode": "BO",
          "warehouseCode": "C",
          "shippableQuantity": 2,
          "availabilityDate": "2026-07-30",
          "discountCode": "A",
          "title": "",
          "author": "",
          "publisher": "",
          "discountPercentage": 99.99
        }
      ],
      "summary": {
        "totalLineItems": 2,
        "totalOrdersAcknowledged": 0,
        "totalUnitsAcknowledged": 0
      }
    }
  }
}
```

---

## 5. Webhook Security (HMAC Signature Verification)

### 5.1 Signature Generation (Server-Side)

```
1. Construct the signing payload:
   signedContent = "{webhookId}.{timestamp}.{body}"

2. Compute HMAC-SHA256:
   signature = HMAC-SHA256(secret, signedContent)

3. Set headers:
   X-Webhook-Id: {webhookId}
   X-Webhook-Timestamp: {unix_timestamp}
   X-Webhook-Signature: sha256={base64(signature)}
```

### 5.2 Signature Verification (Client-Side)

```
1. Extract headers: X-Webhook-Id, X-Webhook-Timestamp, X-Webhook-Signature
2. Verify timestamp is within ±5 minutes of current time (replay protection)
3. Reconstruct signing payload: "{id}.{timestamp}.{body}"
4. Compute HMAC-SHA256 with stored secret
5. Compare computed signature with X-Webhook-Signature
6. If match → process event; if mismatch → reject with 401
```

### 5.3 .NET Signature Generation

```csharp
public static string ComputeSignature(string webhookId, long timestamp, 
    string body, string secret)
{
    var signedContent = $"{webhookId}.{timestamp}.{body}";
    var key = Encoding.UTF8.GetBytes(secret);
    var contentBytes = Encoding.UTF8.GetBytes(signedContent);
    
    var hash = HMACSHA256.HashData(key, contentBytes);
    return $"sha256={Convert.ToBase64String(hash)}";
}
```

---

## 6. Webhook Delivery & Retry Strategy

### 6.1 Delivery Flow

```
Status change event published to Kafka (icg.orders.status-changed)
  │
  ▼
Webhook Dispatcher Consumer
  │
  ├── Query webhook_subscriptions WHERE client_id = ? AND events @> '{event_type}'
  │
  ├── For each matching subscription:
  │     │
  │     ├── Build callback payload
  │     ├── Compute HMAC signature
  │     ├── POST to callbackUrl (timeout: 10s)
  │     │
  │     ├── 2xx response → Log success
  │     │
  │     └── Non-2xx or timeout → Schedule retry
  │
  └── Record delivery in webhook_delivery_log
```

### 6.2 Retry Schedule

| Attempt | Delay | Total Elapsed |
|---------|-------|---------------|
| 1 | Immediate | 0 |
| 2 | 30 seconds | 30s |
| 3 | 2 minutes | 2m 30s |
| 4 | 10 minutes | 12m 30s |
| 5 | 30 minutes | 42m 30s |
| 6 | 2 hours | 2h 42m 30s |
| 7 | 6 hours | 8h 42m 30s |
| 8 (final) | 12 hours | 20h 42m 30s |

After 8 failed attempts:
- Mark delivery as permanently failed
- Increment `failure_count` on the subscription
- If `failure_count` > 50 → auto-disable subscription (`status = 'disabled'`)
- Alert the client via email (if configured)

### 6.3 Retry Implementation

```sql
-- Query for pending retries (run by a scheduled job every 30 seconds)
SELECT wdl.id, wdl.webhook_id, wdl.order_id, wdl.event_type, wdl.payload,
       ws.callback_url, ws.secret_hash
FROM webhook_delivery_log wdl
JOIN webhook_subscriptions ws ON ws.id = wdl.webhook_id
WHERE wdl.is_successful = FALSE
  AND wdl.next_retry_at <= NOW()
  AND wdl.attempt_number < 8
  AND ws.status = 'active'
ORDER BY wdl.next_retry_at ASC
LIMIT 100
FOR UPDATE SKIP LOCKED;  -- Concurrent-safe: skip rows being processed by other workers
```

---

## 7. Webhook Subscription Lifecycle

```
┌──────────┐    Register     ┌──────────┐    Delivery failures    ┌──────────┐
│  (none)  │───────────────▶ │  Active  │ ──────────────────────▶ │  Paused  │
└──────────┘                 └────┬─────┘                         └────┬─────┘
                                  │                                    │
                                  │ Manual disable                     │ 50+ failures
                                  │ or DELETE                          │
                                  ▼                                    ▼
                             ┌──────────┐                        ┌──────────┐
                             │ (deleted) │                        │ Disabled │
                             └──────────┘                        └──────────┘
                                                                       │
                                                                       │ Manual re-enable
                                                                       ▼
                                                                 ┌──────────┐
                                                                 │  Active  │
                                                                 └──────────┘
```

---

## 8. Client-Facing Tracking Workflow

### 8.1 Recommended Client Integration

```
1. Submit order:
   POST /api/v1/orders
   → Receive trackingId in 202 response

2. Option A — Poll status:
   GET /api/v1/orders/{trackingId}/status
   → Poll every 30 seconds until terminal state

3. Option B — Register webhook (preferred):
   POST /api/v1/webhooks
   → Receive push notifications on status changes
   → No polling needed

4. View full acknowledgement:
   Webhook callback delivers full POA detail
   OR
   GET /api/v1/orders/{trackingId} after status = Acknowledged
```

### 8.2 Polling Guidance

For clients using the GET endpoint:

| Order Stage | Recommended Poll Interval |
|-------------|--------------------------|
| `Received` → `Validated` | Every 5 seconds (validation is fast) |
| `Validated` → `SubmittedForFulfillment` | Every 15 seconds |
| `SubmittedForFulfillment` → `Acknowledged` | Every 60 seconds (downstream processing may take minutes) |

> **API rate limits** (100 requests/min per API key) apply to polling. Webhooks are strongly recommended for production integrations.
