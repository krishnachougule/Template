# 09 — IBM MQ Integration

> **Downstream Order Delivery via IBM MQ**
> Native .NET client vs. Kafka Connect · Message format · DLQ · Transactional guarantees

---

## 1. Overview

After validation and processing, the Order Service delivers transformed purchase orders to IBM MQ for consumption by Ingram's legacy fulfillment systems (mainframe/ERP). This is a **Kafka → Worker → IBM MQ** flow.

---

## 2. Integration Pattern Evaluation

### 2.1 Option A: Native IBM MQ .NET Client (Recommended)

```
Kafka Consumer (Worker) ──► IBM MQ .NET Client ──► IBM MQ Queue Manager
                                                     └── ORDER.VALIDATED.QUEUE
```

| Aspect | Assessment |
|--------|-----------|
| **Control** | Full control over message format, headers, correlation IDs |
| **Error Handling** | Custom retry logic with DLQ routing |
| **Observability** | Tracing spans for each MQ put operation |
| **Transactional** | Can participate in local transactions with DB status update |
| **Complexity** | Moderate — requires MQ client dependency and connection management |

### 2.2 Option B: Kafka Connect MQ Sink Connector

```
Kafka Topic ──► Kafka Connect Runtime ──► MQ Sink Connector ──► IBM MQ
```

| Aspect | Assessment |
|--------|-----------|
| **Control** | Limited — connector controls message format via SMTs |
| **Error Handling** | Connector-level DLQ, less granular |
| **Observability** | Separate monitoring for Connect cluster |
| **Transactional** | Connector manages offsets independently |
| **Complexity** | Lower code, but higher infrastructure (separate Connect cluster) |

### 2.3 Decision: **Native .NET Client**

**Rationale:**
1. The Worker must **transform** the order payload before posting to MQ (legacy format mapping). A Kafka Connect SMT (Single Message Transform) is insufficient for complex transformations.
2. The Worker must **update the database status** atomically with the MQ write. This requires application-level coordination.
3. The team already manages the .NET application stack — adding a Kafka Connect cluster is additional infrastructure overhead.
4. Full control over message headers (correlation ID, reply-to queue, message type) is required for mainframe integration.

---

## 3. IBM MQ Configuration

### 3.1 Queue Manager & Queue Details

| Property | Value | Notes |
|----------|-------|-------|
| **Queue Manager** | `ICG.ORDER.QM01` | Primary queue manager |
| **Target Queue** | `ORDER.VALIDATED.QUEUE` | Input queue for fulfillment system |
| **Dead Letter Queue** | `ORDER.DLQ.QUEUE` | Failed messages |
| **Reply Queue** | `ORDER.REPLY.QUEUE` | POA responses from downstream |
| **Channel** | `ICG.ORDER.SVRCONN` | Server connection channel |
| **Port** | `1414` | Default MQ listener port |
| **Transport** | `TCP/TLS` | TLS 1.2+ required |
| **Message Format** | `MQFMT_STRING` | JSON string payload |
| **Persistence** | `MQPER_PERSISTENT` | Messages survive queue manager restart |

### 3.2 Message Properties

| MQ Header | Value | Purpose |
|-----------|-------|---------|
| `CorrelId` | `trackingId` (bytes) | Correlate response (POA) to request |
| `ReplyToQ` | `ORDER.REPLY.QUEUE` | Where downstream sends the POA |
| `ReplyToQMgr` | `ICG.ORDER.QM01` | Reply queue manager |
| `MsgType` | `MQMT_REQUEST` | Request-reply pattern |
| `Format` | `MQFMT_STRING` | JSON string |
| `Expiry` | `MQEI_UNLIMITED` | No expiration |
| `Persistence` | `MQPER_PERSISTENT` | Persisted to disk |
| `usr.trackingId` | `{trackingId}` | Custom property for routing |
| `usr.poNumber` | `{poNumber}` | Custom property for identification |
| `usr.correlationId` | `{X-Correlation-Id}` | End-to-end trace |

---

## 4. Message Payload Format

The MQ message body is a JSON string representing the validated order in a format expected by the downstream fulfillment system.

```json
{
  "messageHeader": {
    "messageId": "msg_0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "messageType": "PURCHASE_ORDER",
    "version": "1.0",
    "timestamp": "2026-07-26T14:31:05.000Z",
    "source": "icg-order-service"
  },
  "orderData": {
    "purchaseOrderNumber": "CUST-PO-001",
    "accountNumber": "20BE991",
    "billToAccountNumber": "7654321",
    "shipToAccountNumber": "1234567",
    "orderDate": "2026-07-26",
    "warehouseCode": "N",
    "shippingInstructions": "STANDARD GROUND",
    "lineItems": [
      {
        "lineNumber": 1,
        "lineItemPurchaseOrderNumber": "LINE000001",
        "itemNumber": "9781234567890",
        "itemNumberType": "IB",
        "quantity": 5,
        "unitPrice": 19.99,
        "backorderCode": "Y",
        "departmentCode": "BOOK"
      },
      {
        "lineNumber": 2,
        "lineItemPurchaseOrderNumber": "LINE000002",
        "itemNumber": "9780987654321",
        "itemNumberType": "IB",
        "quantity": 2,
        "unitPrice": 29.50,
        "backorderCode": "N",
        "departmentCode": "MUSC"
      }
    ]
  },
  "metadata": {
    "validatedAt": "2026-07-26T14:30:03.000Z",
    "lineItemCount": 2,
    "totalUnits": 7
  }
}
```

---

## 5. .NET Implementation Design

### 5.1 MQ Client Interface

```csharp
namespace OrderService.Domain.Contracts;

/// <summary>
/// Port interface for IBM MQ message delivery.
/// </summary>
public interface IMqOrderProducer
{
    /// <summary>
    /// Sends a validated order to IBM MQ.
    /// </summary>
    /// <returns>The MQ message ID for correlation.</returns>
    Task<string> SendOrderAsync(
        PurchaseOrder order, 
        string correlationId, 
        CancellationToken cancellationToken = default);
}
```

### 5.2 Connection Management

```csharp
// Connection management strategy

namespace OrderService.Infrastructure.Mq;

/// <summary>
/// Manages IBM MQ connection lifecycle.
/// Uses connection pooling with health checks.
/// </summary>
public sealed class MqConnectionManager : IDisposable
{
    // Connection pool settings
    private const int MaxConnections = 5;
    private const int ConnectionIdleTimeoutMinutes = 10;
    
    // Reconnection settings
    private const int MaxReconnectAttempts = 5;
    private const int ReconnectBackoffBaseMs = 1000;
    
    // Connection health check
    private const int HealthCheckIntervalSeconds = 30;
}
```

### 5.3 Producer Implementation Pattern

```csharp
// Simplified producer flow

public async Task<string> SendOrderAsync(PurchaseOrder order, string correlationId, ...)
{
    // 1. Transform domain entity to MQ message format
    var mqPayload = _transformer.TransformToMqFormat(order);
    var jsonBody = JsonSerializer.Serialize(mqPayload);

    // 2. Create MQ message with headers
    var message = new MQMessage();
    message.WriteString(jsonBody);
    message.Format = MQC.MQFMT_STRING;
    message.Persistence = MQC.MQPER_PERSISTENT;
    message.ReplyToQueueName = "ORDER.REPLY.QUEUE";
    message.ReplyToQueueManagerName = "ICG.ORDER.QM01";
    message.SetStringProperty("usr.trackingId", order.TrackingId.ToString());
    message.SetStringProperty("usr.poNumber", order.PurchaseOrderNumber);
    message.SetStringProperty("usr.correlationId", correlationId);
    
    // Set correlation ID from tracking ID
    var correlBytes = order.TrackingId.ToByteArray();
    message.CorrelationId = correlBytes;

    // 3. Put message to queue
    var putOptions = new MQPutMessageOptions
    {
        Options = MQC.MQPMO_SYNCPOINT | MQC.MQPMO_NEW_MSG_ID
    };

    using var activity = _activitySource.StartActivity("mq.put");
    activity?.SetTag("mq.queue", "ORDER.VALIDATED.QUEUE");
    activity?.SetTag("mq.tracking_id", order.TrackingId);

    _queue.Put(message, putOptions);
    _queueManager.Commit();  // Commit the syncpoint

    var messageId = BitConverter.ToString(message.MessageId);
    
    _logger.LogInformation(
        "Order {TrackingId} posted to IBM MQ. MessageId: {MqMessageId}",
        order.TrackingId, messageId);

    return messageId;
}
```

---

## 6. POA (Reply) Consumption

The downstream system sends Purchase Order Acknowledgements back via the reply queue.

### 6.1 Reply Consumer Design

```
ORDER.REPLY.QUEUE ──► MQ Reply Consumer (BackgroundService)
                            │
                            ├── Parse POA message
                            ├── Match to order via CorrelationId (trackingId)
                            ├── Update order status → Acknowledged/PartiallyAcknowledged/Rejected
                            ├── Store POA data in orders table
                            ├── Publish icg.orders.acknowledged event to Kafka
                            └── Fire webhook (if subscribed)
```

### 6.2 POA Message Matching

```csharp
// Matching incoming POA to the original order

var correlationId = new Guid(poaMessage.CorrelationId);  // trackingId
var order = await _repository.GetByTrackingIdAsync(correlationId);

if (order == null)
{
    _logger.LogWarning("Received POA for unknown tracking ID: {TrackingId}", correlationId);
    // Move to DLQ or orphan table
    return;
}

// Determine acknowledgement type
var ackStatus = DetermineAckStatus(poaData);
// Acknowledged | PartiallyAcknowledged | Rejected
```

---

## 7. Error Handling & DLQ

### 7.1 Failure Scenarios

| Scenario | Handling |
|----------|---------|
| **Connection refused** | Retry with exponential backoff (1s, 2s, 4s). After 3 attempts, circuit break for 30s. |
| **Queue full** | Retry after backoff. Alert ops if persists > 5 min. |
| **Message too large** | Log error, move to DLQ, status → FailedToPostMQ. |
| **Authentication failure** | Immediate failure. Alert ops. Status → FailedToPostMQ. |
| **Network timeout** | Retry up to 3 times. If persists, status → FailedToPostMQ. |
| **Queue manager down** | Circuit breaker opens. All orders queue in Kafka until MQ recovers. |

### 7.2 Circuit Breaker for MQ

```
MQ Circuit Breaker Configuration:
├── Failure threshold: 5 consecutive failures
├── Break duration: 30 seconds
├── Half-open: Allow 1 test request after break duration
├── Reset: Full open after successful test request
└── On break: Orders remain in Kafka → Worker retries when circuit closes
```

---

## 8. Transactional Integrity

### 8.1 The "Status + MQ" Consistency Challenge

The Worker must ensure that the database status update (`PostedToMQ`) and the MQ put happen atomically. Since PostgreSQL and IBM MQ are different systems, true distributed transactions (2PC) are heavyweight. Instead, use an **Outbox-like pattern**:

```
1. Update order status → Processing (DB commit)
2. Put message to IBM MQ (with syncpoint)
3. Commit MQ syncpoint
4. Update order status → PostedToMQ (DB commit)
5. If step 3 or 4 fails → Rollback MQ, status → FailedToPostMQ
```

### 8.2 Failure Recovery

| Failure Point | Recovery |
|---------------|----------|
| After step 2, before step 3 | MQ syncpoint auto-rolls back on disconnect |
| After step 3, before step 4 | Message is in MQ, but status is `Processing`. Recovery job detects "stuck" Processing orders and verifies MQ delivery. |
| After step 4 | All committed. Happy path. |

### 8.3 Recovery Job

A periodic job (every 5 minutes) checks for orders stuck in `Processing` state for more than a configurable threshold (e.g., 2 minutes). For each:

1. Check if MQ message was delivered (via message ID lookup on the queue manager)
2. If delivered → update status to `PostedToMQ`
3. If not delivered → retry MQ put or escalate to `FailedToPostMQ`

---

## 9. Security

| Concern | Implementation |
|---------|---------------|
| **Transport** | TLS 1.2+ for all MQ connections |
| **Authentication** | Username/password or mTLS certificate |
| **Credential Storage** | Kubernetes Secret (`order-service-mq`) |
| **Credential Rotation** | Support for dynamic secret reload without pod restart |
| **Network** | MQ accessible only from the K8s cluster (network policy) |

---

## 10. Monitoring

| Metric | Source | Alert |
|--------|--------|-------|
| `mq.put.duration_ms` (P95) | Application | > 1,000 ms |
| `mq.put.errors` | Application | > 0 for > 1 min |
| `mq.connection.pool.active` | Application | = max pool size |
| `mq.circuit_breaker.state` | Application | `Open` |
| `mq.queue.depth` (ORDER.VALIDATED.QUEUE) | MQ Manager | > 10,000 messages |
| `mq.queue.depth` (ORDER.DLQ.QUEUE) | MQ Manager | > 0 |
