# 05 — Domain Models (.NET 10)

> **Standardized C# Models for Purchase Order (PO) & Purchase Order Acknowledgement (POA)**
> Clean field naming · Serialization mapping · Validation annotations

---

## 1. Design Principles

| Principle | Implementation |
|-----------|---------------|
| **PascalCase Properties** | All .NET properties follow C# conventions regardless of JSON source |
| **Record Types** | Immutable DTOs use `record` types. Mutable domain entities use `class` |
| **Explicit Mapping** | `[JsonPropertyName]` attributes map between raw JSON names and clean .NET names |
| **Nullable Safety** | .NET nullable reference types enabled. Optional fields are explicitly nullable |
| **Separation** | Request DTOs ≠ Domain Entities ≠ Response DTOs. Each has its own model |

---

## 2. Field Mapping — Purchase Order (PO)

### 2.1 Order Header Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `orderHeader.accountNumber` | `accountNumber` | `AccountNumber` | `string` | ✅ | Trading partner account |
| `orderHeader.poNumber` | `poNumber` | `PurchaseOrderNumber` | `string` | ✅ | Customer PO reference |
| `orderHeader.billToAccount` | `billToAccount` | `BillToAccountNumber` | `string` | ✅ | Billing account |
| `orderHeader.shipToAccount` | `shipToAccount` | `ShipToAccountNumber` | `string` | ✅ | Shipping account |
| `orderHeader.accountPassword` | `accountPassword` | `AccountPassword` | `string` | ✅ | Account credential (masked in logs) |
| `orderHeader.orderDate` | `orderDate` | `OrderDate` | `DateOnly` | ✅ | Date of order |
| `orderHeader.version` | `version` | `PayloadVersion` | `string` | ❌ | API version of PO format |
| `orderHeader.createdDate` | `createdDate` | `CreatedDate` | `DateTimeOffset` | ❌ | Client-side creation timestamp |

### 2.2 Customer Order Header Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `customerOrderHeader.backorderCancellationDate` | `backorderCancellationDate` | `BackorderCancellationDate` | `DateOnly?` | ❌ | Format: YYYYMMDD |
| `customerOrderHeader.backorderCode` | `backorderCode` | `BackorderCode` | `string?` | ❌ | Backorder handling instruction |
| `customerOrderHeader.doNotShipBeforeDate` | `doNotShipBeforeDate` | `DoNotShipBeforeDate` | `DateOnly?` | ❌ | Format: YYMMDD |

### 2.3 Purchase Order Options Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `purchaseOrderOptions.purchaseOrderType` | `purchaseOrderType` | `OrderType` | `string` | ✅ | "0" = standard |
| `purchaseOrderOptions.warehouseCode` | `warehouseCode` | `WarehouseCode` | `string?` | ❌ | Fulfillment warehouse |
| `purchaseOrderOptions.shipToPassword` | `shipToPassword` | `ShipToPassword` | `string?` | ❌ | Ship-to credential |
| `purchaseOrderOptions.shippingInstructions` | `shippingInstructions` | `ShippingInstructions` | `string?` | ❌ | Carrier/method instructions |

### 2.4 Line Item Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `lineItems[].lineItem.lineItemPoNumber` | `lineItemPoNumber` | `LineItemPurchaseOrderNumber` | `string` | ✅ | Line-level PO reference |
| `lineItems[].lineItem.itemNumber` | `itemNumber` | `ItemNumber` | `string` | ✅ | ISBN / EAN / product ID |
| `lineItems[].lineItem.backorderCode` | `backorderCode` | `BackorderCode` | `string?` | ❌ | Y/N backorder flag |
| `lineItems[].lineItem.specialActionCode` | `specialActionCode` | `SpecialActionCode` | `string?` | ❌ | Special handling instruction |
| `lineItems[].lineItem.ddcFulfillment` | `ddcFulfillment` | `IsDdcFulfillment` | `bool` | ❌ | Direct-to-consumer flag |
| `lineItems[].lineItem.itemNumberType` | `itemNumberType` | `ItemNumberType` | `string` | ✅ | IB=ISBN, etc. |

### 2.5 Line Item Detail Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `lineItems[].lineItemDetails.price` | `price` | `UnitPrice` | `decimal` | ✅ | Parsed from zero-padded string |
| `lineItems[].lineItemDetails.backorderCancellationDate` | `backorderCancellationDate` | `BackorderCancellationDate` | `DateOnly?` | ❌ | Format: YYMMDD |
| `lineItems[].lineItemDetails.giftWrapCode` | `giftWrapCode` | `GiftWrapCode` | `string?` | ❌ | Gift wrap option ID |
| `lineItems[].lineItemDetails.orderQuantity` | `orderQuantity` | `OrderQuantity` | `int` | ✅ | Parsed from zero-padded string |
| `lineItems[].lineItemDetails.secondaryItemNumber` | `secondaryItemNumber` | `SecondaryItemNumber` | `string?` | ❌ | Alternate SKU |
| `lineItems[].lineItemDetails.departmentCode` | `departmentCode` | `DepartmentCode` | `string?` | ❌ | Product category |

### 2.6 Enrichment Fields (Optional — Library Systems)

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Notes |
|---------------|---------------|---------------------------|------|-------|
| `lineItems[].enriched?.agencyFund` | `agencyFund` | `AgencyFund` | `string?` | Funding agency |
| `lineItems[].enriched?.branch` | `branch` | `Branch` | `string?` | Library branch |
| `lineItems[].enriched?.collectionCode` | `collectionCode` | `CollectionCode` | `string?` | Collection identifier |
| `lineItems[].enriched?.circLocation` | `circLocation` | `CirculationLocation` | `string?` | Circ desk location |
| `lineItems[].enriched?.shelfLocation` | `shelfLocation` | `ShelfLocation` | `string?` | Physical shelf |
| `lineItems[].enriched?.callnumber` | `callnumber` | `CallNumber` | `string?` | Library call number |
| `lineItems[].enriched?.itemType` | `itemType` | `ItemType` | `string?` | Item classification |
| `lineItems[].enriched?.loanType` | `loanType` | `LoanType` | `string?` | Loan policy type |
| `lineItems[].enriched?.barcode` | `barcode` | `Barcode` | `string?` | Physical barcode |
| `lineItems[].enriched?.bibNumber` | `bibNumber` | `BibliographicNumber` | `string?` | Bib record ID |
| `lineItems[].enriched?.controlNumber` | `controlNumber` | `ControlNumber` | `string?` | MARC control number |
| `lineItems[].enriched?.locationQty` | `locationQty` | `LocationQuantity` | `string?` | Per-location qty |
| `lineItems[].enriched?.systemPo` | `systemPo` | `SystemPurchaseOrder` | `string?` | ILS system PO |
| `lineItems[].enriched?.cutEan` | `cutEan` | `TruncatedEan` | `string?` | Shortened EAN |
| `lineItems[].enriched?.enumerationNotes` | `enumerationNotes` | `EnumerationNotes` | `string?` | Volume/issue info |
| `lineItems[].enriched?.note` | `note` | `Note` | `string?` | Free-text note |

---

## 3. Field Mapping — Purchase Order Acknowledgement (POA)

### 3.1 Response Header Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `OrderResponse.trackingId` | `trackingId` | `TrackingId` | `Guid` | ✅ | System-generated UUID |
| `OrderResponse.poNumber` | `poNumber` | `PurchaseOrderNumber` | `string` | ✅ | Echoed PO reference |
| `OrderResponse.accountNumber` | `accountNumber` | `AccountNumber` | `string` | ✅ | Echoed account |
| `OrderResponse.shipToAccount` | `shipToAccount` | `ShipToAccountNumber` | `string` | ✅ | Echoed ship-to |
| `OrderResponse.toc?` | `toc?` | `TransactionOrderCode` | `string?` | ❌ | Internal tracking code |
| `OrderResponse.status?` | `status?` | `AcknowledgementStatus` | `string?` | ❌ | Overall order status |
| `OrderResponse.dateOfAcknowledgment` | `dateOfAcknowledgment` | `AcknowledgementDate` | `DateOnly` | ✅ | Format: YYMMDD |
| `OrderResponse.purchaseOrderDate?` | `purchaseOrderDate?` | `PurchaseOrderDate` | `DateOnly?` | ❌ | Echoed order date |
| `OrderResponse.poCancellationDate?` | `poCancellationDate?` | `CancellationDate` | `DateOnly?` | ❌ | Auto-cancel deadline |
| `OrderResponse.acknowledgmentType` | `acknowledgmentType` | `AcknowledgementType` | `string` | ✅ | "full confirmation" / "partial" |
| `OrderResponse.creationDate` | `creationDate` | `CreationDate` | `DateTimeOffset` | ✅ | POA creation timestamp |

### 3.2 Vendor Messages

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Notes |
|---------------|---------------|---------------------------|------|-------|
| `OrderResponse.vendorMessage[].message` | `message` | `Message` | `string` | Vendor/system message text |

### 3.3 POA Line Item Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Required | Notes |
|---------------|---------------|---------------------------|------|----------|-------|
| `items[].lineItem.lineItemPoNumber` | `lineItemPoNumber` | `LineItemPurchaseOrderNumber` | `string` | ✅ | Echoed line PO ref |
| `items[].lineItem.itemNumber` | `itemNumber` | `ItemNumber` | `string` | ✅ | ISBN/EAN |
| `items[].lineItem.statusCode` | `statusCode` | `StatusCode` | `string` | ✅ | OK/BO/RJ/etc. |
| `items[].lineItem.warehouseCode` | `warehouseCode` | `WarehouseCode` | `string?` | ❌ | Fulfilling warehouse |

### 3.4 POA Additional Detail Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Notes |
|---------------|---------------|---------------------------|------|-------|
| `items[].additionalDetail.secondaryShippableQuantity` | `secondaryShippableQuantity` | `SecondaryShippableQuantity` | `int?` | Alternate qty available |
| `items[].additionalDetail.secondaryWarehouseCode` | `secondaryWarehouseCode` | `SecondaryWarehouseCode` | `string?` | Alternate warehouse |
| `items[].additionalDetail.availabilityDate` | `availabilityDate` | `AvailabilityDate` | `DateOnly?` | Expected availability |
| `items[].additionalDetail.discountCode` | `discountCode` | `DiscountCode` | `string?` | Pricing tier |
| `items[].additionalDetail.dcStockInformation` | `dcStockInformation` | `DistributionCenterStockInfo` | `string?` | DC stock summary |

### 3.5 POA Additional Line Item Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Notes |
|---------------|---------------|---------------------------|------|-------|
| `items[].additionalLineItem.title` | `title` | `Title` | `string?` | Book/product title |
| `items[].additionalLineItem.author` | `author` | `Author` | `string?` | Author name |
| `items[].additionalLineItem.bindingCode` | `bindingCode` | `BindingCode` | `string?` | HC/PB/etc. |
| `items[].additionalLineItem.publisher` | `publisher` | `Publisher` | `string?` | Publisher name |
| `items[].additionalLineItem.publisherDate` | `publisherDate` | `PublicationDate` | `string?` | Pub date |
| `items[].additionalLineItem.originalSeqNumber` | `originalSeqNumber` | `OriginalSequenceNumber` | `string?` | Original line seq |
| `items[].additionalLineItem.discountPercentage` | `discountPercentage` | `DiscountPercentage` | `decimal?` | Discount % |
| `items[].additionalLineItem.totalShipQtyPrimary` | `totalShipQtyPrimary` | `TotalShipQuantityPrimary` | `int?` | Primary ship qty |
| `items[].additionalLineItem.totalShipQtySecondary` | `totalShipQtySecondary` | `TotalShipQuantitySecondary` | `int?` | Secondary ship qty |

### 3.6 POA Trailer (Summary) Fields

| Raw JSON Path | Raw JSON Name | Standardized .NET Property | Type | Notes |
|---------------|---------------|---------------------------|------|-------|
| `OrderResponse.tailerDetails.totalLineItems` | `totalLineItems` | `TotalLineItems` | `int` | Count of line items |
| `OrderResponse.tailerDetails.totalPO_Acknowledge` | `totalPO_Acknowledge` | `TotalOrdersAcknowledged` | `int` | Acknowledged PO count |
| `OrderResponse.tailerDetails.totalUnitsAcknowledge` | `totalUnitsAcknowledge` | `TotalUnitsAcknowledged` | `int` | Acknowledged unit count |

> **Note:** `tailerDetails` is a typo in the source payload (should be `trailerDetails`). The standardized model corrects this to `TrailerSummary`.

---

## 4. C# Model Definitions

### 4.1 Purchase Order — Request DTO

```csharp
// ── Incoming Request Models (Deserialization) ──────────────────────

namespace OrderService.Contracts.Requests;

/// <summary>
/// Root Purchase Order request model.
/// Maps from the raw JSON PO payload submitted by trading partners.
/// </summary>
public sealed record PurchaseOrderRequest
{
    [JsonPropertyName("orderHeader")]
    public required OrderHeaderRequest OrderHeader { get; init; }

    [JsonPropertyName("customerOrderHeader")]
    public CustomerOrderHeaderRequest? CustomerOrderHeader { get; init; }

    [JsonPropertyName("purchaseOrderOptions")]
    public PurchaseOrderOptionsRequest? PurchaseOrderOptions { get; init; }

    [JsonPropertyName("lineItems")]
    public required IReadOnlyList<LineItemGroupRequest> LineItems { get; init; }
}

public sealed record OrderHeaderRequest
{
    [JsonPropertyName("accountNumber")]
    public required string AccountNumber { get; init; }

    [JsonPropertyName("poNumber")]
    public required string PurchaseOrderNumber { get; init; }

    [JsonPropertyName("billToAccount")]
    public required string BillToAccountNumber { get; init; }

    [JsonPropertyName("shipToAccount")]
    public required string ShipToAccountNumber { get; init; }

    [JsonPropertyName("accountPassword")]
    public required string AccountPassword { get; init; }

    [JsonPropertyName("orderDate")]
    public required DateOnly OrderDate { get; init; }

    [JsonPropertyName("version")]
    public string? PayloadVersion { get; init; }

    [JsonPropertyName("createdDate")]
    public DateTimeOffset? CreatedDate { get; init; }
}

public sealed record CustomerOrderHeaderRequest
{
    [JsonPropertyName("backorderCancellationDate")]
    public string? BackorderCancellationDate { get; init; }

    [JsonPropertyName("backorderCode")]
    public string? BackorderCode { get; init; }

    [JsonPropertyName("doNotShipBeforeDate")]
    public string? DoNotShipBeforeDate { get; init; }
}

public sealed record PurchaseOrderOptionsRequest
{
    [JsonPropertyName("purchaseOrderType")]
    public string? OrderType { get; init; }

    [JsonPropertyName("warehouseCode")]
    public string? WarehouseCode { get; init; }

    [JsonPropertyName("shipToPassword")]
    public string? ShipToPassword { get; init; }

    [JsonPropertyName("shippingInstructions")]
    public string? ShippingInstructions { get; init; }
}

public sealed record LineItemGroupRequest
{
    [JsonPropertyName("lineItem")]
    public required LineItemRequest LineItem { get; init; }

    [JsonPropertyName("lineItemDetails")]
    public required LineItemDetailsRequest LineItemDetails { get; init; }

    [JsonPropertyName("enriched?")]
    public EnrichmentDataRequest? EnrichmentData { get; init; }
}

public sealed record LineItemRequest
{
    [JsonPropertyName("lineItemPoNumber")]
    public required string LineItemPurchaseOrderNumber { get; init; }

    [JsonPropertyName("itemNumber")]
    public required string ItemNumber { get; init; }

    [JsonPropertyName("backorderCode")]
    public string? BackorderCode { get; init; }

    [JsonPropertyName("specialActionCode")]
    public string? SpecialActionCode { get; init; }

    [JsonPropertyName("ddcFulfillment")]
    public string? DdcFulfillment { get; init; }

    [JsonPropertyName("itemNumberType")]
    public required string ItemNumberType { get; init; }
}

public sealed record LineItemDetailsRequest
{
    [JsonPropertyName("price")]
    public required string Price { get; init; }  // "00019.99" → parsed downstream

    [JsonPropertyName("backorderCancellationDate")]
    public string? BackorderCancellationDate { get; init; }

    [JsonPropertyName("giftWrapCode")]
    public string? GiftWrapCode { get; init; }

    [JsonPropertyName("orderQuantity")]
    public required string OrderQuantity { get; init; }  // "0000005" → parsed downstream

    [JsonPropertyName("secondaryItemNumber")]
    public string? SecondaryItemNumber { get; init; }

    [JsonPropertyName("departmentCode")]
    public string? DepartmentCode { get; init; }
}

public sealed record EnrichmentDataRequest
{
    [JsonPropertyName("agencyFund")]       public string? AgencyFund { get; init; }
    [JsonPropertyName("branch")]           public string? Branch { get; init; }
    [JsonPropertyName("collectionCode")]   public string? CollectionCode { get; init; }
    [JsonPropertyName("circLocation")]     public string? CirculationLocation { get; init; }
    [JsonPropertyName("shelfLocation")]    public string? ShelfLocation { get; init; }
    [JsonPropertyName("callnumber")]       public string? CallNumber { get; init; }
    [JsonPropertyName("itemType")]         public string? ItemType { get; init; }
    [JsonPropertyName("loanType")]         public string? LoanType { get; init; }
    [JsonPropertyName("barcode")]          public string? Barcode { get; init; }
    [JsonPropertyName("bibNumber")]        public string? BibliographicNumber { get; init; }
    [JsonPropertyName("controlNumber")]    public string? ControlNumber { get; init; }
    [JsonPropertyName("locationQty")]      public string? LocationQuantity { get; init; }
    [JsonPropertyName("systemPo")]         public string? SystemPurchaseOrder { get; init; }
    [JsonPropertyName("cutEan")]           public string? TruncatedEan { get; init; }
    [JsonPropertyName("enumerationNotes")] public string? EnumerationNotes { get; init; }
    [JsonPropertyName("note")]             public string? Note { get; init; }
}
```

### 4.2 Purchase Order Acknowledgement — Response DTO

```csharp
// ── POA Response Models (Serialization) ────────────────────────────

namespace OrderService.Contracts.Responses;

/// <summary>
/// Purchase Order Acknowledgement (POA) response.
/// Represents the webhook callback payload and GET /status response.
/// </summary>
public sealed record PurchaseOrderAcknowledgementResponse
{
    public required Guid TrackingId { get; init; }
    public required string PurchaseOrderNumber { get; init; }
    public required string AccountNumber { get; init; }
    public required string ShipToAccountNumber { get; init; }
    public string? TransactionOrderCode { get; init; }
    public required string AcknowledgementStatus { get; init; }
    public required DateOnly AcknowledgementDate { get; init; }
    public DateOnly? PurchaseOrderDate { get; init; }
    public DateOnly? CancellationDate { get; init; }
    public required string AcknowledgementType { get; init; }
    public IReadOnlyList<VendorMessageResponse>? VendorMessages { get; init; }
    public required DateTimeOffset CreationDate { get; init; }
    public required IReadOnlyList<AcknowledgementLineItemResponse> Items { get; init; }
    public required TrailerSummaryResponse TrailerSummary { get; init; }
}

public sealed record VendorMessageResponse
{
    public required string Message { get; init; }
}

public sealed record AcknowledgementLineItemResponse
{
    public required AckLineItemResponse LineItem { get; init; }
    public AckAdditionalDetailResponse? AdditionalDetail { get; init; }
    public AckAdditionalLineItemResponse? AdditionalLineItem { get; init; }
}

public sealed record AckLineItemResponse
{
    public required string LineItemPurchaseOrderNumber { get; init; }
    public required string ItemNumber { get; init; }
    public required string StatusCode { get; init; }
    public string? WarehouseCode { get; init; }
}

public sealed record AckAdditionalDetailResponse
{
    public int? SecondaryShippableQuantity { get; init; }
    public string? SecondaryWarehouseCode { get; init; }
    public DateOnly? AvailabilityDate { get; init; }
    public string? DiscountCode { get; init; }
    public string? DistributionCenterStockInfo { get; init; }
}

public sealed record AckAdditionalLineItemResponse
{
    public string? Title { get; init; }
    public string? Author { get; init; }
    public string? BindingCode { get; init; }
    public string? Publisher { get; init; }
    public string? PublicationDate { get; init; }
    public string? OriginalSequenceNumber { get; init; }
    public decimal? DiscountPercentage { get; init; }
    public int? TotalShipQuantityPrimary { get; init; }
    public int? TotalShipQuantitySecondary { get; init; }
}

public sealed record TrailerSummaryResponse
{
    public required int TotalLineItems { get; init; }
    public int TotalOrdersAcknowledged { get; init; }
    public int TotalUnitsAcknowledged { get; init; }
}
```

### 4.3 Domain Entity (Internal)

```csharp
// ── Domain Entities ────────────────────────────────────────────────

namespace OrderService.Domain.Models;

/// <summary>
/// Core domain entity representing a Purchase Order in the system.
/// Mutable class because its status changes through its lifecycle.
/// </summary>
public sealed class PurchaseOrder
{
    public Guid Id { get; private set; } = Guid.CreateVersion7();
    public Guid TrackingId { get; private set; } = Guid.CreateVersion7();
    public required string PurchaseOrderNumber { get; init; }
    public required string AccountNumber { get; init; }
    public required string BillToAccountNumber { get; init; }
    public required string ShipToAccountNumber { get; init; }
    public DateOnly? OrderDate { get; init; }
    public OrderStatus CurrentStatus { get; private set; } = OrderStatus.Received;
    public required JsonDocument RawPayload { get; init; }  // JSONB storage
    public int Version { get; private set; } = 1;           // Concurrency token
    public string? MqMessageId { get; private set; }
    public DateTimeOffset? MqPostedAt { get; private set; }
    public DateTimeOffset ReceivedAt { get; private set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastUpdatedAt { get; private set; } = DateTimeOffset.UtcNow;
    public required string CreatedBy { get; init; }

    public ICollection<OrderLineItem> LineItems { get; init; } = [];
    public ICollection<OrderStatusTransition> StatusHistory { get; init; } = [];

    // ── State Transition Methods ──
    public void TransitionTo(OrderStatus newStatus, string? message = null, string actor = "system")
    {
        // Validated by the state machine (see 08-order-lifecycle-state-machine.md)
        var transition = new OrderStatusTransition
        {
            OrderId = Id,
            PreviousStatus = CurrentStatus,
            Status = newStatus,
            Message = message,
            Actor = actor
        };

        CurrentStatus = newStatus;
        LastUpdatedAt = DateTimeOffset.UtcNow;
        Version++;
        StatusHistory.Add(transition);
    }

    public void SetMqDelivery(string messageId)
    {
        MqMessageId = messageId;
        MqPostedAt = DateTimeOffset.UtcNow;
    }
}

/// <summary>
/// Represents a single line item within a Purchase Order.
/// </summary>
public sealed class OrderLineItem
{
    public Guid Id { get; private set; } = Guid.CreateVersion7();
    public Guid OrderId { get; init; }
    public required int LineNumber { get; init; }
    public required string LineItemPurchaseOrderNumber { get; init; }
    public required string ItemNumber { get; init; }
    public required string ItemNumberType { get; init; }
    public required int Quantity { get; init; }
    public decimal? UnitPrice { get; init; }
    public string? BackorderCode { get; init; }
    public string? SpecialActionCode { get; init; }
    public bool IsDdcFulfillment { get; init; }
    public string? DepartmentCode { get; init; }
    public string? GiftWrapCode { get; init; }
    public string? SecondaryItemNumber { get; init; }
    public DateOnly? BackorderCancellationDate { get; init; }
    public JsonDocument? EnrichmentData { get; init; }  // JSONB for library fields
}

/// <summary>
/// Represents a state transition in the order lifecycle.
/// </summary>
public sealed class OrderStatusTransition
{
    public long Id { get; private set; }
    public Guid OrderId { get; init; }
    public required OrderStatus Status { get; init; }
    public OrderStatus? PreviousStatus { get; init; }
    public string? Message { get; init; }
    public JsonDocument? Metadata { get; init; }
    public DateTimeOffset OccurredAt { get; private set; } = DateTimeOffset.UtcNow;
    public string Actor { get; init; } = "system";
}
```

### 4.4 Order Status Enum

```csharp
namespace OrderService.Domain.Models;

/// <summary>
/// All possible states in the order lifecycle.
/// Maps to the CHECK constraint on orders.current_status.
/// </summary>
public enum OrderStatus
{
    /// <summary>Order received and raw payload stored.</summary>
    Received = 0,

    /// <summary>Account validation in progress.</summary>
    Validating = 10,

    /// <summary>Account validation succeeded.</summary>
    Validated = 20,

    /// <summary>Account validation failed.</summary>
    ValidationFailed = 25,

    /// <summary>Order being transformed and prepared for MQ delivery.</summary>
    Processing = 30,

    /// <summary>Order successfully submitted to the fulfillment system.</summary>
    SubmittedForFulfillment = 40,

    /// <summary>Fulfillment submission failed after retries.</summary>
    FulfillmentSubmissionFailed = 45,

    /// <summary>Full acknowledgement received from downstream.</summary>
    Acknowledged = 50,

    /// <summary>Partial acknowledgement (some items backordered/rejected).</summary>
    PartiallyAcknowledged = 55,

    /// <summary>Order rejected by downstream system.</summary>
    Rejected = 60,

    /// <summary>Order cancelled by client or system.</summary>
    Cancelled = 70,

    /// <summary>Order queued for replay from a previous state.</summary>
    ReplayPending = 80
}
```

---

## 5. Value Parsers

The raw payload uses legacy formatting (zero-padded numbers, YYMMDD dates). These parsers handle the conversion:

```csharp
namespace OrderService.Domain.ValueParsers;

/// <summary>
/// Handles legacy format conversions from raw PO payload fields.
/// </summary>
public static class LegacyFormatParser
{
    /// <summary>
    /// Parses zero-padded price string to decimal.
    /// "00019.99" → 19.99m
    /// </summary>
    public static decimal ParsePrice(string raw)
        => decimal.TryParse(raw.TrimStart('0'), out var result) ? result : 0m;

    /// <summary>
    /// Parses zero-padded quantity string to integer.
    /// "0000005" → 5
    /// </summary>
    public static int ParseQuantity(string raw)
        => int.TryParse(raw.TrimStart('0'), out var result) ? result : 0;

    /// <summary>
    /// Parses YYMMDD date format to DateOnly.
    /// "260831" → 2026-08-31
    /// </summary>
    public static DateOnly? ParseShortDate(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw) || raw.Length != 6) return null;
        return DateOnly.TryParseExact(raw, "yyMMdd", out var result) ? result : null;
    }

    /// <summary>
    /// Parses Y/N string flag to boolean.
    /// "Y" → true, anything else → false
    /// </summary>
    public static bool ParseYesNo(string? raw)
        => string.Equals(raw, "Y", StringComparison.OrdinalIgnoreCase);
}
```
