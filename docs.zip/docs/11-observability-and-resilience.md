# 11 — Observability & Resilience

> **OpenTelemetry · Health Checks · Circuit Breakers · Retry Policies**
> End-to-end tracing · Structured logging · Kubernetes probes

---

## 1. Observability Strategy

The Order Service follows the **three pillars of observability**: Traces, Metrics, and Logs — all unified through OpenTelemetry.

```
┌───────────────────────────────────────────────────────────────┐
│                    ORDER SERVICE                               │
│                                                                │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐                │
│  │  Traces  │    │ Metrics  │    │   Logs   │                │
│  │(OTel SDK)│    │(OTel SDK)│    │(Serilog) │                │
│  └────┬─────┘    └────┬─────┘    └────┬─────┘                │
│       │               │               │                       │
│       └───────────┬───┘───────────────┘                       │
│                   │                                            │
│            ┌──────▼──────┐                                    │
│            │  OTel       │                                    │
│            │  Collector  │  (Sidecar or DaemonSet)            │
│            └──────┬──────┘                                    │
└───────────────────┼───────────────────────────────────────────┘
                    │
        ┌───────────┼───────────────┐
        ▼           ▼               ▼
  ┌──────────┐ ┌──────────┐  ┌──────────┐
  │  Jaeger/ │ │Prometheus│  │  Loki/   │
  │  Tempo   │ │ /Grafana │  │  ELK     │
  │ (Traces) │ │(Metrics) │  │ (Logs)   │
  └──────────┘ └──────────┘  └──────────┘
```

---

## 2. Distributed Tracing

### 2.1 Trace Context Propagation

W3C `traceparent` header is propagated across all system boundaries:

```
HTTP Request ──► API Module ──► Kafka (header) ──► Worker Module ──► IBM MQ (property)
     │               │                                    │                │
     └── span ───────┘── span ─── span ──────────────────┘── span ───────┘
     
     Trace ID: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
```

### 2.2 Custom Activity Sources

```csharp
// Activity sources for custom spans

namespace OrderService.Infrastructure.Telemetry;

public static class ActivitySources
{
    public static readonly ActivitySource OrderApi = new("OrderService.Api");
    public static readonly ActivitySource OrderWorker = new("OrderService.Worker");
    public static readonly ActivitySource OrderKafka = new("OrderService.Kafka");
    public static readonly ActivitySource OrderMq = new("OrderService.Mq");
    public static readonly ActivitySource OrderValidation = new("OrderService.Validation");
    public static readonly ActivitySource OrderWebhook = new("OrderService.Webhook");
}
```

### 2.3 Key Spans

| Span Name | Source | Tags |
|-----------|--------|------|
| `order.receive` | API Module | `tracking_id`, `po_number`, `account_number` |
| `order.validate` | API Module | `tracking_id`, `validation_result` |
| `kafka.produce` | API Module | `topic`, `partition`, `offset`, `tracking_id` |
| `kafka.consume` | Worker Module | `topic`, `partition`, `offset`, `consumer_group` |
| `mq.put` | Worker Module | `queue`, `message_id`, `tracking_id` |
| `mq.get` (POA) | Worker Module | `queue`, `correlation_id` |
| `webhook.dispatch` | Worker Module | `callback_url`, `event_type`, `http_status` |

### 2.4 OpenTelemetry SDK Configuration

```csharp
// Program.cs — OpenTelemetry registration

builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource => resource
        .AddService("order-service", serviceVersion: "1.0.0")
        .AddAttributes(new Dictionary<string, object>
        {
            ["deployment.environment"] = builder.Environment.EnvironmentName,
            ["service.namespace"] = "icg"
        }))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddEntityFrameworkCoreInstrumentation()
        .AddSource(ActivitySources.OrderApi.Name)
        .AddSource(ActivitySources.OrderWorker.Name)
        .AddSource(ActivitySources.OrderKafka.Name)
        .AddSource(ActivitySources.OrderMq.Name)
        .AddSource(ActivitySources.OrderValidation.Name)
        .AddSource(ActivitySources.OrderWebhook.Name)
        .AddOtlpExporter())
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()
        .AddProcessInstrumentation()
        .AddMeter("OrderService.Metrics")
        .AddOtlpExporter());
```

---

## 3. Metrics

### 3.1 Custom Business Metrics

```csharp
namespace OrderService.Infrastructure.Telemetry;

public sealed class OrderMetrics
{
    private static readonly Meter Meter = new("OrderService.Metrics", "1.0.0");

    // Counters
    public static readonly Counter<long> OrdersReceived = 
        Meter.CreateCounter<long>("orders.received.total", description: "Total orders received");
    
    public static readonly Counter<long> OrdersValidated = 
        Meter.CreateCounter<long>("orders.validated.total", description: "Orders validated successfully");
    
    public static readonly Counter<long> OrdersValidationFailed = 
        Meter.CreateCounter<long>("orders.validation_failed.total", description: "Orders that failed validation");
    
    public static readonly Counter<long> OrdersPostedToMq = 
        Meter.CreateCounter<long>("orders.posted_to_mq.total", description: "Orders posted to IBM MQ");
    
    public static readonly Counter<long> OrdersMqFailed = 
        Meter.CreateCounter<long>("orders.mq_failed.total", description: "Orders that failed MQ delivery");
    
    public static readonly Counter<long> WebhooksSent = 
        Meter.CreateCounter<long>("webhooks.sent.total", description: "Webhook callbacks sent");
    
    public static readonly Counter<long> WebhooksFailed = 
        Meter.CreateCounter<long>("webhooks.failed.total", description: "Webhook callbacks that failed");

    // Histograms
    public static readonly Histogram<double> OrderProcessingDuration = 
        Meter.CreateHistogram<double>("orders.processing.duration_ms", 
            unit: "ms", description: "End-to-end order processing duration");
    
    public static readonly Histogram<double> ValidationDuration = 
        Meter.CreateHistogram<double>("orders.validation.duration_ms", 
            unit: "ms", description: "Account validation call duration");
    
    public static readonly Histogram<double> MqPutDuration = 
        Meter.CreateHistogram<double>("orders.mq_put.duration_ms", 
            unit: "ms", description: "IBM MQ put operation duration");

    // Gauges (via Observable)
    // kafka.consumer.lag — reported by Kafka consumer metrics
    // mq.connection.pool.active — reported by MQ connection manager
}
```

### 3.2 Dashboard Panels (Grafana)

| Panel | Metric | Visualization |
|-------|--------|---------------|
| **Orders/min** | `rate(orders.received.total[5m])` | Time series |
| **Validation Success Rate** | `orders.validated / orders.received * 100` | Gauge (target > 95%) |
| **MQ Delivery Success Rate** | `orders.posted_to_mq / orders.validated * 100` | Gauge (target > 99.9%) |
| **Processing Latency (P95)** | `histogram_quantile(0.95, orders.processing.duration_ms)` | Heatmap |
| **Kafka Consumer Lag** | `kafka_consumer_group_lag` | Time series |
| **Active Connections** | `mq.connection.pool.active` | Gauge |
| **Error Rate** | `rate(orders.validation_failed.total + orders.mq_failed.total)` | Time series |

---

## 4. Structured Logging

### 4.1 Log Configuration (Serilog)

```csharp
// Structured logging with Serilog

builder.Host.UseSerilog((context, config) => config
    .ReadFrom.Configuration(context.Configuration)
    .Enrich.FromLogContext()
    .Enrich.WithProperty("ServiceName", "order-service")
    .Enrich.WithProperty("Environment", context.HostingEnvironment.EnvironmentName)
    .Enrich.WithCorrelationId()           // X-Correlation-Id
    .Enrich.WithClientId()                // X-Client-Id
    .WriteTo.Console(new JsonFormatter())  // JSON for log aggregation
    .Filter.ByExcluding(logEvent =>        // Health check noise reduction
        logEvent.Properties.ContainsKey("RequestPath") &&
        logEvent.Properties["RequestPath"].ToString().Contains("/health")));
```

### 4.2 Log Entry Structure

```json
{
  "timestamp": "2026-07-26T14:30:03.000Z",
  "level": "Information",
  "message": "Order validated successfully",
  "serviceName": "order-service",
  "environment": "production",
  "correlationId": "corr-abc123",
  "clientId": "partner-xyz",
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "poNumber": "CUST-PO-001",
  "accountNumber": "20BE991",
  "duration_ms": 1250,
  "traceId": "4bf92f3577b34da6a3ce929d0e0e4736",
  "spanId": "00f067aa0ba902b7"
}
```

### 4.3 Sensitive Data Masking

| Field | Masking Rule |
|-------|-------------|
| `accountPassword` | **Never logged.** Destructured as `"***MASKED***"` |
| `shipToPassword` | **Never logged.** Destructured as `"***MASKED***"` |
| `X-API-Key` | Last 4 characters only: `"****abcd"` |
| `Authorization` | Header name logged, value never logged |
| `webhook.secret` | **Never logged.** |

---

## 5. Health Checks

### 5.1 Endpoints

| Endpoint | K8s Probe | Purpose |
|----------|-----------|---------|
| `/health/live` | Liveness Probe | Is the process alive? Always returns `200` unless deadlocked. |
| `/health/ready` | Readiness Probe | Is the service ready to accept traffic? Checks DB, Kafka, MQ connectivity. |
| `/health/startup` | Startup Probe | Has the service completed initialization? |

### 5.2 Health Check Registration

```csharp
builder.Services.AddHealthChecks()
    .AddNpgSql(connectionString, name: "postgresql",
        failureStatus: HealthStatus.Unhealthy,
        tags: ["ready", "db"])
    .AddKafka(kafkaConfig, name: "kafka",
        failureStatus: HealthStatus.Degraded,
        tags: ["ready", "messaging"])
    .AddCheck<IbmMqHealthCheck>("ibm-mq",
        failureStatus: HealthStatus.Degraded,
        tags: ["ready", "messaging"])
    .AddCheck<AccountValidationHealthCheck>("account-validation",
        failureStatus: HealthStatus.Degraded,
        tags: ["ready", "external"]);
```

### 5.3 Kubernetes Probe Configuration

```yaml
# Deployment spec probes
containers:
  - name: order-api
    livenessProbe:
      httpGet:
        path: /health/live
        port: 8080
      initialDelaySeconds: 10
      periodSeconds: 15
      failureThreshold: 3
    readinessProbe:
      httpGet:
        path: /health/ready
        port: 8080
      initialDelaySeconds: 5
      periodSeconds: 10
      failureThreshold: 3
    startupProbe:
      httpGet:
        path: /health/startup
        port: 8080
      initialDelaySeconds: 5
      periodSeconds: 5
      failureThreshold: 30    # Allow up to 150s for startup
```

---

## 6. Resilience Patterns

### 6.1 Pattern Summary

| Dependency | Pattern | Library | Configuration |
|-----------|---------|---------|---------------|
| **Account Validation Service** | Retry + Circuit Breaker + Timeout | `Microsoft.Extensions.Http.Resilience` | See [06-validation-service-integration.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/06-validation-service-integration.md) |
| **IBM MQ** | Retry + Circuit Breaker | Custom (Polly) | 3 retries, 30s circuit break |
| **Kafka Producer** | Built-in retries | Confluent.Kafka | `EnableIdempotence=true`, 3 retries |
| **Kafka Consumer** | Manual retry → DLT | Custom | 3 in-process + 3 retry topic attempts |
| **Webhook Dispatch** | Retry with backoff | Custom | 8 attempts over 20+ hours |
| **PostgreSQL** | Connection pool + transient retry | Npgsql + EF Core | Retry on transient failures |

### 6.2 Bulkhead Isolation

```
┌────────────────────────────────────────────────────┐
│  Order Service Process                              │
│                                                      │
│  ┌──────────────────┐  ┌──────────────────┐        │
│  │  API Thread Pool  │  │  Worker Threads   │        │
│  │  (HTTP handling)  │  │  (Kafka + MQ)     │        │
│  │  Max: 200 threads │  │  Max: 50 threads  │        │
│  └──────────────────┘  └──────────────────┘        │
│                                                      │
│  ┌──────────────────┐  ┌──────────────────┐        │
│  │  Validation HTTP  │  │  Webhook HTTP    │        │
│  │  Client Pool      │  │  Client Pool     │        │
│  │  Max: 20 conn     │  │  Max: 30 conn    │        │
│  └──────────────────┘  └──────────────────┘        │
│                                                      │
│  ┌──────────────────┐                               │
│  │  MQ Connection   │                               │
│  │  Pool             │                               │
│  │  Max: 5 conn      │                               │
│  └──────────────────┘                               │
└────────────────────────────────────────────────────┘
```

### 6.3 Graceful Shutdown

```csharp
// Graceful shutdown ensures no data loss

var lifetime = app.Services.GetRequiredService<IHostApplicationLifetime>();

lifetime.ApplicationStopping.Register(() =>
{
    // 1. Stop accepting new HTTP requests (readiness probe fails)
    // 2. Complete in-flight HTTP requests (drain timeout: 30s)
    // 3. Commit final Kafka consumer offsets
    // 4. Close IBM MQ connections gracefully
    // 5. Flush OpenTelemetry buffers
    // 6. Drain Serilog sinks
});
```

---

## 7. Alerting Rules

| Alert | Severity | Condition | Action |
|-------|----------|-----------|--------|
| **High Error Rate** | Critical | `orders.mq_failed.total / orders.validated.total > 5%` for 5 min | Page on-call |
| **Validation Circuit Open** | Critical | Circuit breaker state = `Open` | Page on-call |
| **MQ Circuit Open** | Critical | MQ circuit breaker state = `Open` | Page on-call |
| **High Kafka Lag** | Warning | Consumer lag > 5,000 for > 5 min | Notify team |
| **DLQ Messages** | High | Any message in `icg.orders.dlq` | Notify team + create incident |
| **Webhook Delivery Failure** | Warning | Webhook failure rate > 20% | Notify team |
| **Pod Restart** | Warning | Pod restart count > 3 in 30 min | Investigate |
| **P95 Latency** | Warning | `orders.processing.duration_ms` P95 > 5,000 ms | Notify team |
