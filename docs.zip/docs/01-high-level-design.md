# 01 — High-Level Design (HLD)

> **Ingram Content Group — Order Service**
> .NET 10 · Kubernetes · PostgreSQL · Apache Kafka · IBM MQ

---

## 1. Executive Summary

The Order Service is a cloud-native, event-driven application responsible for receiving, validating, tracking, and forwarding purchase orders (POs) within Ingram Content Group's fulfillment ecosystem. It replaces or modernizes portions of the existing EDI 850/855 order processing pipeline with a RESTful API façade, enabling modern integrations while preserving downstream connectivity to legacy IBM MQ-based systems.

---

## 2. System Context (C4 — Level 1)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                            EXTERNAL CONSUMERS                               │
│     Retailers · Libraries · E-Commerce Platforms · Internal Systems          │
└──────────────────────┬───────────────────────────────────────────────────────┘
                       │ HTTPS (TLS 1.3)
                       ▼
              ┌─────────────────┐
              │  Imperva WAF    │  ← DDoS protection, bot mitigation,
              │  (Cloud WAF)    │    OWASP Top-10 rule sets
              └────────┬────────┘
                       │
                       ▼
              ┌─────────────────┐
              │  API Management │  ← OAuth 2.0 / API-Key validation,
              │  (APIM Gateway) │    rate limiting, request routing,
              └────────┬────────┘    payload transformation
                       │
                       ▼
    ┌──────────────────────────────────────────────────────────────────────┐
    │                    KUBERNETES CLUSTER                                │
    │                                                                      │
    │  ┌────────────────┐      ┌──────────────────────────────────────┐   │
    │  │  K8s Ingress   │─────▶│   Order Service (Modular Monolith)  │   │
    │  │  Controller    │      │                                      │   │
    │  └────────────────┘      │  ┌─────────────┐  ┌──────────────┐  │   │
    │                          │  │  API Module  │  │ Worker Module│  │   │
    │                          │  │  (HTTP in)   │  │ (Kafka out)  │  │   │
    │                          │  └──────┬───────┘  └──────┬───────┘  │   │
    │                          └─────────┼─────────────────┼──────────┘   │
    │                                    │                 │              │
    │                    ┌───────────────┼─────────────────┼──────┐      │
    │                    ▼               ▼                 ▼      │      │
    │             ┌────────────┐  ┌───────────┐  ┌────────────┐  │      │
    │             │ PostgreSQL │  │   Kafka   │  │  IBM MQ    │  │      │
    │             │  (Primary) │  │  Cluster  │  │  Gateway   │  │      │
    │             └────────────┘  └───────────┘  └────────────┘  │      │
    │                    │                                        │      │
    │                    ▼                                        │      │
    │             ┌────────────┐                                  │      │
    │             │ Account    │  (External Validation Service)   │      │
    │             │ Validation │                                  │      │
    │             │ Service    │                                  │      │
    │             └────────────┘                                  │      │
    └─────────────────────────────────────────────────────────────┘      │
                                                                         │
    ┌────────────────────────────────────────────────────────────────────┘
    │                DOWNSTREAM / LEGACY SYSTEMS
    │
    │  ┌────────────────────┐     ┌──────────────────────────┐
    │  │  IBM MQ Queue Mgr  │────▶│  Mainframe / Legacy ERP  │
    │  │  (ORDER.VALIDATED)  │     │  (Fulfillment Engine)    │
    │  └────────────────────┘     └──────────────────────────┘
    │
    │  ┌────────────────────────────┐
    │  │  Webhook Callback Clients  │  ← POA notifications
    │  └────────────────────────────┘
    └
```

---

## 3. End-to-End Request Flow

### 3.1 Happy Path — Order Submission

```
  Step │ Component              │ Action
  ─────┼────────────────────────┼───────────────────────────────────────────
   1   │ Client                 │ POST /api/v1/orders (PO JSON payload)
   2   │ Imperva WAF            │ Inspect request; pass if clean
   3   │ APIM Gateway           │ Authenticate (OAuth 2.0 / API-Key),
       │                        │ rate-limit, route to K8s Ingress
   4   │ K8s Ingress            │ TLS termination, forward to Service
   5   │ API Module             │ a. Generate trackingId (UUIDv7)
       │                        │ b. Store raw PO payload as JSONB
       │                        │ c. Set status → Received
       │                        │ d. Return 202 Accepted + trackingId
   6   │ API Module             │ Call Account Validation Service
       │                        │ (accountNumber, billToAccount,
       │                        │  shipToAccount, accountPassword)
   7   │ API Module             │ On success: status → Validated
       │                        │ Publish OrderValidated event to Kafka
   8   │ Kafka                  │ Persist event to topic:
       │                        │ icg.orders.validated
   9   │ Worker Module          │ Consume OrderValidated event
       │                        │ Transform to IBM MQ message format
  10   │ Worker Module          │ Post to IBM MQ queue:
       │                        │ ORDER.VALIDATED.QUEUE
       │                        │ status → PostedToMQ
  11   │ Worker Module          │ (Async) Receive POA from downstream
       │                        │ status → Acknowledged
       │                        │ Fire webhook if subscribed
```

### 3.2 Failure Path — Validation Failure

```
  Step │ Component              │ Action
  ─────┼────────────────────────┼───────────────────────────────────────────
   6a  │ API Module             │ Validation service returns failure
   6b  │ API Module             │ status → ValidationFailed
       │                        │ Publish OrderValidationFailed event
       │                        │ Store failure reason in audit log
       │                        │ Fire webhook if subscribed
```

### 3.3 Failure Path — IBM MQ Delivery Failure

```
  Step │ Component              │ Action
  ─────┼────────────────────────┼───────────────────────────────────────────
  10a  │ Worker Module          │ IBM MQ connection/write failure
  10b  │ Worker Module          │ Retry with exponential backoff (3x)
  10c  │ Worker Module          │ On exhaustion: publish to
       │                        │ icg.orders.dlq (dead-letter topic)
       │                        │ status → FailedToPostMQ
       │                        │ Alert via observability pipeline
```

---

## 4. Technology Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| **Runtime** | .NET | 10 (LTS) | Application framework |
| **API Framework** | ASP.NET Core Minimal APIs | 10.x | HTTP endpoint layer |
| **ORM** | Entity Framework Core | 10.x | PostgreSQL data access |
| **Database** | PostgreSQL | 16+ | Primary data store (JSONB) |
| **Messaging** | Apache Kafka | 3.7+ | Event streaming backbone |
| **Kafka Client** | Confluent.Kafka | latest | .NET Kafka producer/consumer |
| **Legacy MQ** | IBM MQ | 9.3+ | Downstream order delivery |
| **MQ Client** | IBMMQDotnetClient | latest | .NET IBM MQ connectivity |
| **State Machine** | Stateless | 5.x | Order lifecycle transitions |
| **Resilience** | Microsoft.Extensions.Http.Resilience | 10.x | Circuit breaker, retry, timeout |
| **Observability** | OpenTelemetry .NET | 1.x | Traces, metrics, logs |
| **Serialization** | System.Text.Json | 10.x | JSON serialization |
| **Validation** | FluentValidation | 11.x | Request model validation |
| **Container Runtime** | Kubernetes | 1.30+ | Container orchestration |
| **Ingress** | NGINX Ingress Controller | latest | K8s traffic routing |
| **WAF** | Imperva Cloud WAF | — | Edge security |
| **API Gateway** | APIM (vendor-specific) | — | Authentication, rate limiting |

---

## 5. Kubernetes Deployment Topology

```yaml
# Logical Deployment Model
Namespace: icg-order-service

Deployments:
  ┌─────────────────────────────────────────────────┐
  │  order-service (replicas: 3–10, HPA)            │
  │  ├── Container: order-api       (port 8080)     │
  │  │   └── Serves HTTP API endpoints              │
  │  └── Container: order-worker    (no port)       │
  │      └── Kafka consumer, IBM MQ producer        │
  │      └── Background hosted service              │
  └─────────────────────────────────────────────────┘

Services:
  ├── order-service-api    (ClusterIP → port 8080)
  └── order-service-api    (referenced by Ingress)

Ingress:
  └── orders.icg.internal → order-service-api:8080

ConfigMaps:
  ├── order-service-config  (Kafka brokers, MQ host, feature flags)
  └── order-service-topics  (topic names, consumer groups)

Secrets:
  ├── order-service-db      (PostgreSQL connection string)
  ├── order-service-kafka   (SASL credentials, TLS certs)
  ├── order-service-mq      (IBM MQ credentials)
  └── order-service-webhook (HMAC signing key)

HPA (Horizontal Pod Autoscaler):
  └── CPU target: 70% | Memory target: 80%
      Min replicas: 3 | Max replicas: 10

PDB (Pod Disruption Budget):
  └── minAvailable: 2
```

---

## 6. Data Flow Diagram

```
                     ┌─────────────┐
                     │   Client    │
                     └──────┬──────┘
                            │ POST /api/v1/orders
                            ▼
                     ┌─────────────┐
                     │  API Module │
                     └──┬──┬──┬────┘
                        │  │  │
          ┌─────────────┘  │  └─────────────────────┐
          ▼                ▼                         ▼
   ┌────────────┐  ┌──────────────┐         ┌──────────────┐
   │ PostgreSQL │  │  Validation  │         │    Kafka     │
   │            │  │  Service     │         │  (Producer)  │
   │ • orders   │  │  (External)  │         │              │
   │ • raw JSONB│  └──────────────┘         └──────┬───────┘
   │ • audit    │                                   │
   │ • webhooks │                                   ▼
   └────────────┘                           ┌──────────────┐
                                            │ Worker Module│
                                            │  (Consumer)  │
                                            └──────┬───────┘
                                                   │
                                    ┌──────────────┼──────────────┐
                                    ▼              ▼              ▼
                             ┌──────────┐  ┌────────────┐  ┌──────────┐
                             │  IBM MQ  │  │ PostgreSQL │  │ Webhook  │
                             │  Queue   │  │ (Status    │  │ Callback │
                             │          │  │  Update)   │  │          │
                             └──────────┘  └────────────┘  └──────────┘
```

---

## 7. Module Boundary Summary

| Module | Responsibility | Exposes | Consumes |
|--------|---------------|---------|----------|
| **API Module** | HTTP ingress, validation orchestration, raw storage, Kafka producing | REST endpoints, Kafka events | PostgreSQL, Validation Service |
| **Worker Module** | Event processing, IBM MQ delivery, webhook dispatch | Kafka consumer, MQ messages, webhook calls | Kafka topics, PostgreSQL, IBM MQ |
| **Shared Kernel** | Domain models, state machine, value objects, contracts | In-process references | — |

> **Note:** Both modules share the same deployment unit (modular monolith) but maintain strict internal boundaries via separate .NET projects and `internal` access modifiers. See [02-deployment-pattern-decision.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/02-deployment-pattern-decision.md) for full rationale.

---

## 8. Cross-Cutting Concerns

| Concern | Strategy | Document |
|---------|----------|----------|
| **Authentication** | OAuth 2.0 / API-Key at APIM layer | [12-security-design.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/12-security-design.md) |
| **Observability** | OpenTelemetry (W3C Trace Context propagated through Kafka headers) | [11-observability-and-resilience.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/11-observability-and-resilience.md) |
| **Resilience** | Circuit breaker (validation svc), retry (MQ), DLQ (Kafka) | [11-observability-and-resilience.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/11-observability-and-resilience.md) |
| **Idempotency** | Client-provided `Idempotency-Key` header, server-side dedup table | [03-api-specification.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/03-api-specification.md) |
| **Audit** | PostgreSQL trigger-based audit log + JSONB raw payload | [04-data-model-and-persistence.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/04-data-model-and-persistence.md) |
| **State Tracking** | `Stateless` library with DB-persisted state | [08-order-lifecycle-state-machine.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/08-order-lifecycle-state-machine.md) |

---

## 9. Non-Functional Requirements

| Attribute | Target | Mechanism |
|-----------|--------|-----------|
| **Availability** | 99.9% (3-nines) | Multi-replica K8s deployment, PDB, health probes |
| **Latency (P95)** | < 200ms for `POST /orders` | Async processing via Kafka after initial persist |
| **Throughput** | 500+ orders/sec sustained | HPA scaling, Kafka partitioning |
| **Data Durability** | Zero data loss | PostgreSQL WAL, Kafka replication factor 3 |
| **Recovery (RTO)** | < 15 minutes | Kubernetes self-healing, PDB |
| **Recovery (RPO)** | 0 (zero data loss) | Synchronous DB write before Kafka publish |
| **Auditability** | Full order lifecycle | JSONB raw payload + state history table |
| **Replayability** | Re-process from any state | Kafka topic retention + raw payload storage |
