# 03 — API Specification

> **Ingram Content Group — Order Service API**
> Version: `v1` · Protocol: HTTPS · Format: JSON · Auth: OAuth 2.0 / API-Key

---

## 1. API Design Principles

| Principle | Implementation |
|-----------|---------------|
| **RESTful** | Resource-oriented URLs, standard HTTP verbs |
| **Async-First** | `POST /orders` returns `202 Accepted` (not `201 Created`) because processing is asynchronous |
| **Idempotent** | Client-provided `Idempotency-Key` header prevents duplicate submissions |
| **Versioned** | URL-based versioning (`/api/v1/`) for explicit contract control |
| **Standardized Errors** | RFC 9457 Problem Details for all error responses |
| **Correlated** | `X-Correlation-Id` header propagated through all systems for tracing |

---

## 2. Base URL

```
Production:  https://orders.api.ingramcontent.com/api/v1
Staging:     https://orders.staging.api.ingramcontent.com/api/v1
```

---

## 3. Authentication

All requests must include one of:

| Method | Header | Description |
|--------|--------|-------------|
| **OAuth 2.0 Bearer Token** | `Authorization: Bearer <token>` | Preferred. Token obtained from APIM's OAuth endpoint. |
| **API Key** | `X-API-Key: <key>` | Legacy support. Key provisioned per trading partner in APIM. |

> Authentication is enforced at the **APIM Gateway** layer. The Order Service API itself receives pre-authenticated requests with the caller identity injected via `X-Client-Id` and `X-Client-Scope` headers.

---

## 4. Common Headers

### Request Headers

| Header | Required | Description |
|--------|----------|-------------|
| `Content-Type` | Yes | `application/json` |
| `Authorization` | Yes | OAuth 2.0 bearer token |
| `Idempotency-Key` | Yes (for POST) | Client-generated UUID. Prevents duplicate order submission. |
| `X-Correlation-Id` | No | Client-provided trace ID. If absent, server generates one. |
| `Accept` | No | `application/json` (default) |

### Response Headers

| Header | Description |
|--------|-------------|
| `X-Correlation-Id` | Echoed or server-generated correlation ID |
| `X-Request-Id` | Server-generated unique request identifier |
| `Location` | (On `202`) URL to poll for status: `/api/v1/orders/{trackingId}/status` |
| `Retry-After` | (On `429`) Seconds to wait before retrying |

---

## 5. Endpoints

### 5.1 Submit Purchase Order

```
POST /api/v1/orders
```

Receives a raw Purchase Order payload, stores it, initiates async validation and processing.

**Request Body:** Raw PO JSON (see [05-domain-models.md](file:///Users/krishnachougule/Downloads/OrderResearch/docs/05-domain-models.md) for schema)

**Response:** `202 Accepted`

```json
{
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "poNumber": "CUST-PO-001",
  "status": "Received",
  "statusMessage": "Order received and queued for validation.",
  "receivedAt": "2026-07-26T14:30:00.000Z",
  "links": {
    "self": "/api/v1/orders/0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "status": "/api/v1/orders/0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b/status"
  }
}
```

**Error Responses:**

| Status | Condition |
|--------|-----------|
| `400 Bad Request` | Malformed JSON or missing required fields |
| `409 Conflict` | Duplicate `Idempotency-Key` (returns original response) |
| `422 Unprocessable Entity` | Structurally valid JSON but fails business validation (e.g., empty `lineItems`) |
| `429 Too Many Requests` | Rate limit exceeded |
| `500 Internal Server Error` | Unexpected server failure |

---

### 5.2 Get Order Status

```
GET /api/v1/orders/{trackingId}/status
```

Returns the current lifecycle status and full history for a tracked order.

**Path Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `trackingId` | `UUID` | The tracking ID returned from `POST /orders` |

**Response:** `200 OK`

```json
{
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "poNumber": "CUST-PO-001",
  "accountNumber": "20BE991",
  "currentStatus": "SubmittedForFulfillment",
  "currentStatusMessage": "Order posted to fulfillment system.",
  "lastUpdatedAt": "2026-07-26T14:31:05.000Z",
  "statusHistory": [
    {
      "status": "Received",
      "message": "Order received and stored.",
      "occurredAt": "2026-07-26T14:30:00.000Z"
    },
    {
      "status": "Validating",
      "message": "Account validation in progress.",
      "occurredAt": "2026-07-26T14:30:01.000Z"
    },
    {
      "status": "Validated",
      "message": "Account validation successful.",
      "occurredAt": "2026-07-26T14:30:03.000Z"
    },
    {
      "status": "Processing",
      "message": "Order transformation and delivery in progress.",
      "occurredAt": "2026-07-26T14:30:45.000Z"
    },
    {
      "status": "SubmittedForFulfillment",
      "message": "Order posted to fulfillment system.",
      "occurredAt": "2026-07-26T14:31:05.000Z"
    }
  ],
  "links": {
    "self": "/api/v1/orders/0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b/status",
    "order": "/api/v1/orders/0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b"
  }
}
```

**Error Responses:**

| Status | Condition |
|--------|-----------|
| `404 Not Found` | No order exists with the given `trackingId` |

---

### 5.3 Get Order Detail

```
GET /api/v1/orders/{trackingId}
```

Returns the full order record including parsed header, line items, and current status.

**Response:** `200 OK`

```json
{
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "poNumber": "CUST-PO-001",
  "accountNumber": "20BE991",
  "currentStatus": "Validated",
  "orderHeader": { "..." },
  "lineItems": [ "..." ],
  "receivedAt": "2026-07-26T14:30:00.000Z",
  "lastUpdatedAt": "2026-07-26T14:30:03.000Z"
}
```

---

### 5.4 Register Webhook Subscription

```
POST /api/v1/webhooks
```

Registers a callback URL to receive order status change notifications.

**Request Body:**

```json
{
  "callbackUrl": "https://partner.example.com/webhooks/orders",
  "events": [
    "order.validated",
    "order.submitted_for_fulfillment",
    "order.acknowledged",
    "order.failed"
  ],
  "secret": "whsec_partner_provided_secret_key"
}
```

**Response:** `201 Created`

```json
{
  "webhookId": "wh_0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "callbackUrl": "https://partner.example.com/webhooks/orders",
  "events": ["order.validated", "order.submitted_for_fulfillment", "order.acknowledged", "order.failed"],
  "status": "active",
  "createdAt": "2026-07-26T14:00:00.000Z"
}
```

---

### 5.5 List Webhook Subscriptions

```
GET /api/v1/webhooks
```

Returns all webhook subscriptions for the authenticated client.

**Response:** `200 OK`

```json
{
  "webhooks": [
    {
      "webhookId": "wh_0192f8a0-...",
      "callbackUrl": "https://partner.example.com/webhooks/orders",
      "events": ["order.validated", "order.submitted_for_fulfillment"],
      "status": "active"
    }
  ]
}
```

---

### 5.6 Delete Webhook Subscription

```
DELETE /api/v1/webhooks/{webhookId}
```

Deactivates and removes a webhook subscription.

**Response:** `204 No Content`

---

### 5.7 Replay Failed Order (Admin)

```
POST /api/v1/admin/orders/{trackingId}/replay
```

Re-triggers processing for a failed order from its last successful state. Uses the stored raw JSONB payload for replayability.

**Response:** `202 Accepted`

```json
{
  "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "replayedFromStatus": "Validated",
  "newStatus": "Processing",
  "message": "Order replayed from Validated state."
}
```

> [!IMPORTANT]
> This endpoint requires the `admin` scope in the OAuth token. It is not available to trading partners.

---

## 6. Error Response Format (RFC 9457)

All error responses follow the [RFC 9457 Problem Details](https://www.rfc-editor.org/rfc/rfc9457) specification:

```json
{
  "type": "https://orders.api.ingramcontent.com/errors/validation-failed",
  "title": "Validation Failed",
  "status": 422,
  "detail": "The 'accountNumber' field is required and was not provided.",
  "instance": "/api/v1/orders",
  "traceId": "00-abc123def456-789ghi-01",
  "errors": {
    "orderHeader.accountNumber": ["The AccountNumber field is required."]
  }
}
```

---

## 7. Idempotency Implementation

### Flow

```
Client sends POST /orders with Idempotency-Key: "abc-123"
  │
  ├─ Key NOT in idempotency store → Process request normally
  │   └─ Store response keyed by "abc-123" (TTL: 24 hours)
  │
  └─ Key EXISTS in idempotency store
      ├─ Processing complete → Return cached response with 200 OK
      └─ Processing in-flight → Return 409 Conflict
```

### Database Table

```sql
CREATE TABLE idempotency_keys (
    key           VARCHAR(128)  PRIMARY KEY,
    client_id     VARCHAR(64)   NOT NULL,
    response_code INTEGER       NOT NULL,
    response_body JSONB         NOT NULL,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    expires_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW() + INTERVAL '24 hours'
);

CREATE INDEX idx_idempotency_expires ON idempotency_keys (expires_at);
```

---

## 8. Rate Limiting

| Scope | Limit | Window | Response |
|-------|-------|--------|----------|
| Per API-Key | 100 requests | 1 minute | `429` with `Retry-After` header |
| Per IP | 500 requests | 1 minute | `429` with `Retry-After` header |
| Burst | 20 requests | 1 second | `429` with `Retry-After` header |

> Rate limiting is enforced at the **APIM Gateway** layer. The Order Service trusts the gateway to have already enforced these limits.

---

## 9. API Versioning Strategy

| Strategy | Details |
|----------|---------|
| **Method** | URL path prefix (`/api/v1/`, `/api/v2/`) |
| **Deprecation** | Minimum 6-month notice. `Sunset` header added to deprecated versions. |
| **Compatibility** | Additive changes (new fields) are non-breaking within a version. Removing or renaming fields requires a new version. |
