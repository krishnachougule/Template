# 06 — Validation Service Integration

> **External Account Validation Service**
> Synchronous REST · Circuit breaker · Retry policies · Failure handling

---

## 1. Overview

The Order Service integrates with an **existing, external Account Validation Service** that validates the following fields from the incoming Purchase Order:

| Field | Source Path | Purpose |
|-------|-----------|---------|
| `accountNumber` | `orderHeader.accountNumber` | Primary trading partner account |
| `billToAccount` | `orderHeader.billToAccount` | Billing account reference |
| `shipToAccount` | `orderHeader.shipToAccount` | Shipping destination account |
| `accountPassword` | `orderHeader.accountPassword` | Account credential verification |

---

## 2. Integration Architecture

```
┌──────────────────────┐          ┌──────────────────────────┐
│  Order Service       │  HTTPS   │  Account Validation      │
│  (API Module)        │─────────▶│  Service (External)      │
│                      │          │                          │
│  • IAccountValidator │◄─────────│  • Validates credentials │
│  • Circuit Breaker   │  200/4xx │  • Returns pass/fail     │
│  • Retry Policy      │          │  • Provides error detail │
└──────────────────────┘          └──────────────────────────┘
```

### Assumed Protocol: Synchronous REST over HTTPS

> **Assumption:** The validation service exposes a REST API. If it uses gRPC or messaging, the `IAccountValidationClient` interface remains the same; only the implementation changes.

---

## 3. Integration Contract

### 3.1 Validation Request

```
POST https://validation-service.internal/api/v1/accounts/validate
Content-Type: application/json
X-Correlation-Id: {correlationId}
Authorization: Bearer {service-to-service-token}
```

```json
{
  "accountNumber": "20BE991",
  "billToAccount": "7654321",
  "shipToAccount": "1234567",
  "accountPassword": "Xyz@123"
}
```

### 3.2 Validation Response — Success

```
HTTP/1.1 200 OK
```

```json
{
  "isValid": true,
  "accountNumber": "20BE991",
  "accountStatus": "Active",
  "billToStatus": "Active",
  "shipToStatus": "Active",
  "validatedAt": "2026-07-26T14:30:02.000Z"
}
```

### 3.3 Validation Response — Failure

```
HTTP/1.1 200 OK  (business-level failure, not HTTP error)
```

```json
{
  "isValid": false,
  "accountNumber": "20BE991",
  "errors": [
    {
      "field": "accountPassword",
      "code": "INVALID_CREDENTIALS",
      "message": "Account password does not match."
    },
    {
      "field": "shipToAccount",
      "code": "ACCOUNT_SUSPENDED",
      "message": "Ship-to account 1234567 is suspended."
    }
  ],
  "validatedAt": "2026-07-26T14:30:02.000Z"
}
```

### 3.4 HTTP-Level Errors

| HTTP Status | Meaning | Order Service Action |
|-------------|---------|---------------------|
| `200` | Validation completed (check `isValid`) | Process result |
| `400` | Malformed validation request | Mark as `ValidationFailed`, log error |
| `401/403` | Service auth failure | Circuit break, alert ops team |
| `404` | Account not found | Mark as `ValidationFailed` |
| `429` | Rate limited | Retry with backoff |
| `500/502/503` | Service unavailable | Retry → circuit break → `ValidationFailed` |

---

## 4. .NET Interface & Models

### 4.1 Port Interface (Domain Layer)

```csharp
namespace OrderService.Domain.Contracts;

/// <summary>
/// Port interface for account validation.
/// Implementation lives in Infrastructure layer.
/// </summary>
public interface IAccountValidationClient
{
    /// <summary>
    /// Validates account credentials against the external service.
    /// </summary>
    /// <param name="request">Account validation request.</param>
    /// <param name="correlationId">Trace correlation ID.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Validation result with detailed error information if failed.</returns>
    Task<AccountValidationResult> ValidateAsync(
        AccountValidationRequest request,
        string correlationId,
        CancellationToken cancellationToken = default);
}
```

### 4.2 Request / Response Models

```csharp
namespace OrderService.Domain.Contracts;

public sealed record AccountValidationRequest
{
    public required string AccountNumber { get; init; }
    public required string BillToAccountNumber { get; init; }
    public required string ShipToAccountNumber { get; init; }
    public required string AccountPassword { get; init; }
}

public sealed record AccountValidationResult
{
    public required bool IsValid { get; init; }
    public string? AccountStatus { get; init; }
    public string? BillToStatus { get; init; }
    public string? ShipToStatus { get; init; }
    public IReadOnlyList<ValidationError>? Errors { get; init; }
    public DateTimeOffset ValidatedAt { get; init; }
}

public sealed record ValidationError
{
    public required string Field { get; init; }
    public required string Code { get; init; }
    public required string Message { get; init; }
}
```

---

## 5. Resilience Configuration

### 5.1 Resilience Pipeline

```
Request
  │
  ├─► Timeout (10s per attempt)
  │
  ├─► Retry (3 attempts, exponential backoff)
  │     ├── Delay: 1s → 2s → 4s (with jitter)
  │     └── Retries on: 429, 500, 502, 503, 504, TimeoutException
  │
  ├─► Circuit Breaker
  │     ├── Failure ratio: 50% over 30s sampling window
  │     ├── Minimum throughput: 10 requests
  │     ├── Break duration: 30 seconds
  │     └── On break: fail fast with CircuitBrokenException
  │
  └─► Total Timeout (30s end-to-end including retries)
```

### 5.2 Configuration Values

```csharp
// Microsoft.Extensions.Http.Resilience pipeline configuration
builder.Services
    .AddHttpClient<IAccountValidationClient, AccountValidationHttpClient>(client =>
    {
        client.BaseAddress = new Uri(config["ValidationService:BaseUrl"]!);
    })
    .AddStandardResilienceHandler(options =>
    {
        // Per-attempt timeout
        options.AttemptTimeout.Timeout = TimeSpan.FromSeconds(10);

        // Retry
        options.Retry.MaxRetryAttempts = 3;
        options.Retry.Delay = TimeSpan.FromSeconds(1);
        options.Retry.BackoffType = DelayBackoffType.Exponential;
        options.Retry.UseJitter = true;
        options.Retry.ShouldHandle = args => ValueTask.FromResult(
            args.Outcome.Result?.StatusCode is 
                HttpStatusCode.TooManyRequests or
                HttpStatusCode.InternalServerError or
                HttpStatusCode.BadGateway or
                HttpStatusCode.ServiceUnavailable or
                HttpStatusCode.GatewayTimeout
            || args.Outcome.Exception is TimeoutException or HttpRequestException
        );

        // Circuit breaker
        options.CircuitBreaker.FailureRatio = 0.5;
        options.CircuitBreaker.SamplingDuration = TimeSpan.FromSeconds(30);
        options.CircuitBreaker.MinimumThroughput = 10;
        options.CircuitBreaker.BreakDuration = TimeSpan.FromSeconds(30);

        // Total pipeline timeout
        options.TotalRequestTimeout.Timeout = TimeSpan.FromSeconds(30);
    });
```

---

## 6. Validation Flow in Order Processing

```
POST /api/v1/orders
  │
  ▼
Store raw payload → status: Received
  │
  ▼
status: Validating
  │
  ├─── Call IAccountValidationClient.ValidateAsync()
  │
  ├─── SUCCESS (isValid = true)
  │     ├── Store validation result in orders.validation_result
  │     ├── status: Validated
  │     └── Publish OrderValidated event to Kafka
  │
  ├─── BUSINESS FAILURE (isValid = false)
  │     ├── Store errors in orders.error_details
  │     ├── status: ValidationFailed
  │     ├── Publish OrderValidationFailed event to Kafka
  │     └── Fire webhook (if subscribed to "order.failed")
  │
  └─── INFRASTRUCTURE FAILURE (timeout/circuit break)
        ├── Store exception details in orders.error_details
        ├── status: ValidationFailed
        ├── Log error with correlation ID
        └── Alert ops team via observability pipeline
```

---

## 7. Security Considerations

| Concern | Mitigation |
|---------|-----------|
| **Credential Exposure** | `accountPassword` is NEVER logged. Masked in all structured log output. |
| **Service-to-Service Auth** | mTLS or OAuth 2.0 client credentials flow for service-to-service calls. |
| **Network Isolation** | Validation service accessible only within the Kubernetes cluster network (ClusterIP or internal ingress). |
| **Audit Trail** | Validation request/response (with password masked) stored in `orders.validation_result` JSONB column. |

---

## 8. Monitoring & Alerts

| Metric | Threshold | Action |
|--------|-----------|--------|
| `validation.request.duration_ms` (P95) | > 5,000 ms | Warning alert |
| `validation.request.duration_ms` (P99) | > 10,000 ms | Critical alert |
| `validation.circuit_breaker.state` | `Open` | Critical alert + page on-call |
| `validation.failure_rate` | > 10% over 5 min | Warning alert |
| `validation.error.count` (5xx) | > 50 in 5 min | Critical alert |
