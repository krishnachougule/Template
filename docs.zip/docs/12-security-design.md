# 12 — Security Design

> **End-to-End Security Architecture**
> Imperva WAF · APIM Policies · mTLS · Secret Management · RBAC

---

## 1. Security Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         SECURITY LAYERS                                 │
│                                                                          │
│  Layer 1: Edge Security                                                  │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  Imperva Cloud WAF                                               │    │
│  │  • DDoS protection       • Bot mitigation                       │    │
│  │  • OWASP Top-10 rules    • IP reputation filtering              │    │
│  │  • Request size limits   • Geo-blocking (optional)              │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  Layer 2: API Gateway Security                                           │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  APIM Gateway                                                    │    │
│  │  • OAuth 2.0 token validation   • API-Key authentication        │    │
│  │  • Rate limiting                 • Request throttling            │    │
│  │  • Payload size enforcement     • CORS policy                   │    │
│  │  • Request/response logging     • JWT claim extraction          │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  Layer 3: Transport Security                                             │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  TLS 1.3 (external)  •  mTLS (internal service-to-service)     │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  Layer 4: Application Security                                           │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  • Input validation (FluentValidation)                          │    │
│  │  • Parameterized queries (EF Core)                              │    │
│  │  • Sensitive data masking in logs                                │    │
│  │  • RBAC authorization (admin vs. partner)                       │    │
│  │  • Idempotency key enforcement                                  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  Layer 5: Data Security                                                  │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  • PostgreSQL TLS connections                                    │    │
│  │  • Encryption at rest (PostgreSQL TDE or disk-level)            │    │
│  │  • Kubernetes Secrets / Vault for credentials                    │    │
│  │  • Password hashing for webhook secrets                          │    │
│  └─────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Imperva WAF Integration

### 2.1 Configuration

| Setting | Value | Purpose |
|---------|-------|---------|
| **Protection Mode** | Active (blocking) | Block malicious requests |
| **OWASP Rules** | Top 10 2021 | SQL injection, XSS, SSRF, etc. |
| **DDoS Protection** | Layer 3/4 + Layer 7 | Volumetric and application DDoS |
| **Bot Management** | Challenge suspicious clients | Prevent automated abuse |
| **IP Reputation** | Block known-bad IPs | Threat intelligence |
| **Request Size** | Max 5 MB | Prevent oversized payloads |
| **Rate Limiting** | 1,000 req/sec per IP | Layer-1 rate limiting |

### 2.2 WAF → APIM Integration

```
Client ──► Imperva WAF ──► APIM Gateway
                │
                └── Imperva adds headers:
                    X-Imperva-Client-IP: {real_client_ip}
                    X-Imperva-Session-Id: {session_id}
                    X-Imperva-Threat-Score: {score}
```

> APIM trusts `X-Imperva-Client-IP` for rate limiting (not `X-Forwarded-For`, which can be spoofed).

---

## 3. APIM Gateway Policies

### 3.1 Authentication Policy

```
Inbound Policy:
  1. Check for Authorization header (Bearer token)
     └── Validate JWT: issuer, audience, expiry, signature
     └── Extract claims: client_id, scope, roles
  
  2. OR check for X-API-Key header
     └── Validate against registered API keys
     └── Map to client_id and scope

  3. Inject downstream headers:
     └── X-Client-Id: {resolved_client_id}
     └── X-Client-Scope: {resolved_scope}  (e.g., "orders:write", "admin")
     └── X-Client-Name: {partner_name}
```

### 3.2 Rate Limiting Policy

```
Rate Limiting Rules:
  ├── Per API-Key:   100 requests / 1 minute
  ├── Per Client-IP: 500 requests / 1 minute
  ├── Burst:         20 requests / 1 second
  │
  └── On exceeded:
      HTTP 429 Too Many Requests
      Retry-After: {seconds}
      {
        "type": "https://orders.api.ingramcontent.com/errors/rate-limit-exceeded",
        "title": "Rate Limit Exceeded",
        "status": 429,
        "detail": "You have exceeded the rate limit of 100 requests per minute."
      }
```

### 3.3 Request Validation Policy

```
Inbound Validation:
  ├── Content-Type must be application/json
  ├── Content-Length must be ≤ 1 MB
  ├── Reject requests with disallowed headers
  └── Strip unknown query parameters
```

---

## 4. Transport Security

### 4.1 External TLS

| Setting | Value |
|---------|-------|
| **Protocol** | TLS 1.3 (minimum TLS 1.2) |
| **Cipher Suites** | `TLS_AES_256_GCM_SHA384`, `TLS_CHACHA20_POLY1305_SHA256` |
| **Certificate** | Managed by Imperva / APIM |
| **HSTS** | `Strict-Transport-Security: max-age=31536000; includeSubDomains` |

### 4.2 Internal mTLS (Service-to-Service)

```
┌──────────────────┐   mTLS   ┌──────────────────────┐
│  Order Service   │ ◄──────► │ Account Validation    │
│  (API Module)    │          │ Service               │
└──────────────────┘          └──────────────────────┘

Implementation:
  ├── Kubernetes Service Mesh (Istio/Linkerd) → automatic mTLS
  └── OR: Manual cert management with cert-manager
```

### 4.3 Database Connection Security

```
PostgreSQL Connection:
  ├── SSL Mode: verify-full
  ├── Server certificate validated against CA
  ├── Client certificate (optional, for mutual TLS)
  └── Connection string: Host=...;SslMode=VerifyFull;RootCertificate=...
```

---

## 5. Secret Management

### 5.1 Secrets Inventory

| Secret | Storage | Rotation Frequency |
|--------|---------|-------------------|
| PostgreSQL connection string | K8s Secret / Vault | 90 days |
| Kafka SASL credentials | K8s Secret / Vault | 90 days |
| IBM MQ credentials | K8s Secret / Vault | 90 days |
| OAuth client secret (for validation svc) | K8s Secret / Vault | 90 days |
| Webhook HMAC signing key | K8s Secret / Vault | On subscriber request |
| APIM API keys (for clients) | APIM Portal | On client request |

### 5.2 Kubernetes Secrets Configuration

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: order-service-db
  namespace: icg-order-service
type: Opaque
data:
  connection-string: <base64-encoded>

---
apiVersion: v1
kind: Secret
metadata:
  name: order-service-kafka
  namespace: icg-order-service
type: Opaque
data:
  sasl-username: <base64-encoded>
  sasl-password: <base64-encoded>
  ssl-ca-cert: <base64-encoded>

---
apiVersion: v1
kind: Secret
metadata:
  name: order-service-mq
  namespace: icg-order-service
type: Opaque
data:
  username: <base64-encoded>
  password: <base64-encoded>
  tls-cert: <base64-encoded>
```

### 5.3 HashiCorp Vault (Recommended for Production)

```
Vault Integration:
  ├── Use vault-injector sidecar in K8s pods
  ├── Dynamic secrets for PostgreSQL (auto-rotated credentials)
  ├── Transit engine for encryption of sensitive JSONB fields
  └── Audit logging for all secret access
```

---

## 6. Authorization (RBAC)

### 6.1 Roles & Scopes

| Role | Scope | Permissions |
|------|-------|-------------|
| **Trading Partner** | `orders:write` | `POST /orders`, `GET /orders/{id}`, `GET /orders/{id}/status` |
| **Trading Partner** | `webhooks:manage` | `POST /webhooks`, `GET /webhooks`, `DELETE /webhooks/{id}` |
| **Internal Admin** | `admin` | All above + `POST /admin/orders/{id}/replay`, access to DLQ management |
| **Read-Only Viewer** | `orders:read` | `GET /orders/{id}`, `GET /orders/{id}/status` only |
| **Service Account** | `service:internal` | Internal service-to-service calls (validation, webhook) |

### 6.2 Authorization Middleware

```csharp
// Authorization policies

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("OrderWrite", policy =>
        policy.RequireClaim("scope", "orders:write"))
    .AddPolicy("OrderRead", policy =>
        policy.RequireAssertion(context =>
            context.User.HasClaim("scope", "orders:read") ||
            context.User.HasClaim("scope", "orders:write") ||
            context.User.HasClaim("scope", "admin")))
    .AddPolicy("WebhookManage", policy =>
        policy.RequireClaim("scope", "webhooks:manage"))
    .AddPolicy("Admin", policy =>
        policy.RequireClaim("scope", "admin"));
```

### 6.3 Data Isolation

```
Trading partners can ONLY access their own orders:

Query filter:
  WHERE orders.account_number = @callerAccountNumber

This is enforced at the repository level, not just the API layer,
to prevent data leakage in all access paths.
```

---

## 7. Input Validation & Injection Prevention

### 7.1 FluentValidation Rules

```csharp
public sealed class PurchaseOrderRequestValidator 
    : AbstractValidator<PurchaseOrderRequest>
{
    public PurchaseOrderRequestValidator()
    {
        RuleFor(x => x.OrderHeader).NotNull();
        RuleFor(x => x.OrderHeader.AccountNumber)
            .NotEmpty().MaximumLength(20)
            .Matches("^[A-Z0-9]+$")  // Alphanumeric only
            .WithMessage("AccountNumber must be alphanumeric");
        RuleFor(x => x.OrderHeader.PurchaseOrderNumber)
            .NotEmpty().MaximumLength(50);
        RuleFor(x => x.LineItems)
            .NotEmpty()
            .WithMessage("At least one line item is required");
        RuleForEach(x => x.LineItems).ChildRules(lineItem =>
        {
            lineItem.RuleFor(li => li.LineItem.ItemNumber)
                .NotEmpty().MaximumLength(20)
                .Matches("^[0-9]+$")  // ISBN is numeric
                .WithMessage("ItemNumber must be numeric (ISBN/EAN)");
        });
    }
}
```

### 7.2 SQL Injection Prevention

| Method | Status |
|--------|--------|
| **Parameterized queries** | ✅ Enforced by EF Core (all queries are parameterized) |
| **Raw SQL** | ⚠️ Prohibited unless via `FromSqlInterpolated()` with parameters |
| **JSONB queries** | ✅ Use EF Core JSONB operators, never string concatenation |
| **Dynamic ordering** | ✅ Whitelist-based column names, never user-supplied SQL |

---

## 8. Security Headers

```csharp
// Security headers middleware
app.Use(async (context, next) =>
{
    context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
    context.Response.Headers.Append("X-Frame-Options", "DENY");
    context.Response.Headers.Append("X-XSS-Protection", "0");  // Rely on CSP instead
    context.Response.Headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");
    context.Response.Headers.Append("Cache-Control", "no-store");
    context.Response.Headers.Append("Pragma", "no-cache");
    
    await next();
});
```

---

## 9. Kubernetes Network Policies

```yaml
# Allow only APIM ingress to reach the Order Service API
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: order-service-ingress
  namespace: icg-order-service
spec:
  podSelector:
    matchLabels:
      app: order-service
  policyTypes:
    - Ingress
    - Egress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              name: apim-gateway
      ports:
        - protocol: TCP
          port: 8080
  egress:
    # PostgreSQL
    - to:
        - namespaceSelector:
            matchLabels:
              name: databases
      ports:
        - protocol: TCP
          port: 5432
    # Kafka
    - to:
        - namespaceSelector:
            matchLabels:
              name: kafka
      ports:
        - protocol: TCP
          port: 9093
    # IBM MQ
    - to:
        - ipBlock:
            cidr: 10.0.0.0/8  # Internal MQ network
      ports:
        - protocol: TCP
          port: 1414
    # Account Validation Service
    - to:
        - namespaceSelector:
            matchLabels:
              name: validation-services
      ports:
        - protocol: TCP
          port: 443
    # Webhook callbacks (external)
    - to:
        - ipBlock:
            cidr: 0.0.0.0/0
            except:
              - 10.0.0.0/8
              - 172.16.0.0/12
              - 192.168.0.0/16
      ports:
        - protocol: TCP
          port: 443
    # DNS
    - to: []
      ports:
        - protocol: UDP
          port: 53
        - protocol: TCP
          port: 53
```

---

## 10. Security Checklist

| # | Control | Status | Owner |
|---|---------|--------|-------|
| 1 | Imperva WAF active with OWASP Top-10 rules | ☐ | Infrastructure |
| 2 | APIM enforces OAuth 2.0 / API-Key on all endpoints | ☐ | Platform |
| 3 | TLS 1.3 for all external connections | ☐ | Infrastructure |
| 4 | mTLS for internal service-to-service calls | ☐ | Platform |
| 5 | All secrets in Kubernetes Secrets or Vault | ☐ | DevOps |
| 6 | Secret rotation policy (90-day cycle) | ☐ | Security |
| 7 | Sensitive data masking in logs (passwords, keys) | ☐ | Development |
| 8 | RBAC policies enforced (admin vs. partner scopes) | ☐ | Development |
| 9 | Data isolation (partner sees only their orders) | ☐ | Development |
| 10 | Input validation on all endpoints (FluentValidation) | ☐ | Development |
| 11 | SQL injection prevention (EF Core parameterized) | ☐ | Development |
| 12 | Network policies restricting pod communication | ☐ | Infrastructure |
| 13 | Webhook HMAC signature verification documented | ☐ | Development |
| 14 | Security headers on all responses | ☐ | Development |
| 15 | PostgreSQL connections use SSL verify-full | ☐ | DevOps |
