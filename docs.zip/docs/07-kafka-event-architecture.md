# 07 — Kafka Event Architecture

> **Apache Kafka — Event-Driven Processing Design**
> Topics · Schemas · Producer/Consumer · Partitioning · Dead Letter Topics

---

## 1. Overview

Kafka serves as the **event streaming backbone** between the API Module (producer) and the Worker Module (consumer). It provides:

- **Temporal decoupling:** The API returns `202 Accepted` immediately; the Worker processes asynchronously.
- **Load buffering:** Kafka absorbs traffic bursts without overwhelming downstream systems.
- **Replayability:** Events can be replayed from any offset for failure recovery.
- **Auditability:** Event log provides an immutable record of all order processing decisions.

---

## 2. Topic Design

### 2.1 Topic Naming Convention

```
{organization}.{domain}.{event-name}

Examples:
  icg.orders.validated
  icg.orders.validation-failed
  icg.orders.submitted-for-fulfillment
  icg.orders.acknowledged
  icg.orders.dlq                   ← Dead Letter Topic
  icg.orders.retry                 ← Retry Topic
```

### 2.2 Topic Inventory

| Topic Name | Producer | Consumer | Purpose | Partitions | Retention |
|------------|----------|----------|---------|------------|-----------|
| `icg.orders.validated` | API Module | Worker Module | Order passed validation, ready for MQ delivery | 12 | 7 days |
| `icg.orders.validation-failed` | API Module | Worker Module | Order failed validation | 6 | 7 days |
| `icg.orders.submitted-for-fulfillment` | Worker Module | Worker Module (webhooks) | Order submitted to fulfillment system | 6 | 7 days |
| `icg.orders.acknowledged` | Worker Module | Worker Module (webhooks) | POA received from downstream | 6 | 7 days |
| `icg.orders.status-changed` | Both modules | Worker Module (webhooks) | Generic status change event for webhook dispatch | 6 | 3 days |
| `icg.orders.retry` | Worker Module | Worker Module | Failed events awaiting retry | 3 | 3 days |
| `icg.orders.dlq` | Worker Module | Ops/Manual | Dead letter — events that exceeded max retries | 3 | 30 days |

### 2.3 Partitioning Strategy

| Topic | Partition Key | Rationale |
|-------|--------------|-----------|
| `icg.orders.validated` | `trackingId` | Ensures all events for the same order land on the same partition, preserving ordering within an order |
| `icg.orders.validation-failed` | `trackingId` | Same-order ordering |
| `icg.orders.submitted-for-fulfillment` | `trackingId` | Same-order ordering |
| `icg.orders.acknowledged` | `trackingId` | Same-order ordering |
| `icg.orders.dlq` | `trackingId` | Same-order grouping for troubleshooting |

> **12 partitions** for the main `validated` topic enables up to 12 concurrent consumer instances for horizontal scaling.

---

## 3. Event Schema (CloudEvents Format)

All events follow the [CloudEvents v1.0](https://cloudevents.io/) specification for interoperability.

### 3.1 Envelope Structure

```json
{
  "specversion": "1.0",
  "id": "evt_0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "source": "urn:icg:order-service:api",
  "type": "icg.orders.validated.v1",
  "subject": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "time": "2026-07-26T14:30:03.000Z",
  "datacontenttype": "application/json",
  "correlationid": "corr-abc123-def456",
  "data": {
    // Event-specific payload
  }
}
```

### 3.2 Event: `icg.orders.validated.v1`

Produced by the **API Module** after successful account validation.

```json
{
  "specversion": "1.0",
  "id": "evt_550e8400-e29b-41d4-a716-446655440001",
  "source": "urn:icg:order-service:api",
  "type": "icg.orders.validated.v1",
  "subject": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
  "time": "2026-07-26T14:30:03.000Z",
  "datacontenttype": "application/json",
  "correlationid": "corr-abc123",
  "data": {
    "trackingId": "0192f8a0-7b3c-7def-8a1b-4c5d6e7f8a9b",
    "orderId": "a1b2c3d4-...",
    "purchaseOrderNumber": "CUST-PO-001",
    "accountNumber": "20BE991",
    "shipToAccountNumber": "1234567",
    "billToAccountNumber": "7654321",
    "lineItemCount": 2,
    "validatedAt": "2026-07-26T14:30:03.000Z",
    "previousStatus": "Validating",
    "currentStatus": "Validated"
  }
}
```

### 3.3 Event: `icg.orders.validation-failed.v1`

```json
{
  "type": "icg.orders.validation-failed.v1",
  "data": {
    "trackingId": "0192f8a0-...",
    "orderId": "a1b2c3d4-...",
    "purchaseOrderNumber": "CUST-PO-001",
    "accountNumber": "20BE991",
    "failureReason": "INVALID_CREDENTIALS",
    "validationErrors": [
      {
        "field": "accountPassword",
        "code": "INVALID_CREDENTIALS",
        "message": "Account password does not match."
      }
    ],
    "failedAt": "2026-07-26T14:30:02.500Z"
  }
}
```

### 3.4 Event: `icg.orders.submitted-for-fulfillment.v1`

```json
{
  "type": "icg.orders.submitted-for-fulfillment.v1",
  "data": {
    "trackingId": "0192f8a0-...",
    "orderId": "a1b2c3d4-...",
    "purchaseOrderNumber": "CUST-PO-001",
    "mqMessageId": "AMQ_MSG_001",
    "mqQueueName": "ORDER.VALIDATED.QUEUE",
    "postedAt": "2026-07-26T14:31:05.000Z",
    "previousStatus": "Processing",
    "currentStatus": "SubmittedForFulfillment"
  }
}
```

### 3.5 Event: `icg.orders.acknowledged.v1`

```json
{
  "type": "icg.orders.acknowledged.v1",
  "data": {
    "trackingId": "0192f8a0-...",
    "orderId": "a1b2c3d4-...",
    "purchaseOrderNumber": "CUST-PO-001",
    "acknowledgementType": "full confirmation",
    "acknowledgementStatus": "Acknowledged",
    "acknowledgedAt": "2026-07-26T15:00:00.000Z",
    "lineItemSummary": {
      "total": 2,
      "acknowledged": 2,
      "backordered": 0,
      "rejected": 0
    }
  }
}
```

---

## 4. Producer Configuration (API Module)

```csharp
// Producer wrapper for Kafka event publishing

namespace OrderService.Infrastructure.Kafka;

public sealed class OrderEventProducer : IOrderEventProducer, IDisposable
{
    private readonly IProducer<string, string> _producer;
    private readonly ILogger<OrderEventProducer> _logger;

    public OrderEventProducer(IConfiguration config, ILogger<OrderEventProducer> logger)
    {
        _logger = logger;
        _producer = new ProducerBuilder<string, string>(new ProducerConfig
        {
            BootstrapServers = config["Kafka:BootstrapServers"],
            SecurityProtocol = SecurityProtocol.SaslSsl,
            SaslMechanism = SaslMechanism.Plain,
            SaslUsername = config["Kafka:SaslUsername"],
            SaslPassword = config["Kafka:SaslPassword"],
            
            // Reliability settings
            Acks = Acks.All,                          // Wait for all ISR replicas
            EnableIdempotence = true,                 // Exactly-once semantics
            MaxInFlight = 5,                          // Max in-flight per partition
            MessageSendMaxRetries = 3,
            RetryBackoffMs = 100,
            
            // Performance
            LingerMs = 5,                             // Batch for 5ms
            BatchSize = 16384,                        // 16KB batch size
            CompressionType = CompressionType.Lz4,    // LZ4 compression
        }).Build();
    }

    public async Task PublishAsync<T>(string topic, string key, T eventData, 
        string correlationId, CancellationToken ct = default)
    {
        var cloudEvent = CloudEventEnvelope.Create(eventData, topic, key, correlationId);
        var serialized = JsonSerializer.Serialize(cloudEvent);

        var message = new Message<string, string>
        {
            Key = key,
            Value = serialized,
            Headers = new Headers
            {
                { "ce-type", Encoding.UTF8.GetBytes(cloudEvent.Type) },
                { "ce-source", Encoding.UTF8.GetBytes(cloudEvent.Source) },
                { "ce-correlationid", Encoding.UTF8.GetBytes(correlationId) },
                { "traceparent", Encoding.UTF8.GetBytes(Activity.Current?.Id ?? "") }
            }
        };

        var result = await _producer.ProduceAsync(topic, message, ct);
        _logger.LogInformation(
            "Published {EventType} to {Topic}/{Partition}@{Offset} for tracking {TrackingId}",
            cloudEvent.Type, result.Topic, result.Partition.Value, 
            result.Offset.Value, key);
    }
}
```

---

## 5. Consumer Configuration (Worker Module)

```csharp
// Consumer hosted service for Kafka event processing

namespace OrderService.Worker.Consumers;

public sealed class OrderValidatedConsumer : BackgroundService
{
    private readonly IConsumer<string, string> _consumer;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<OrderValidatedConsumer> _logger;

    // Consumer configuration
    private static ConsumerConfig CreateConfig(IConfiguration config) => new()
    {
        BootstrapServers = config["Kafka:BootstrapServers"],
        GroupId = "icg-order-worker",
        AutoOffsetReset = AutoOffsetReset.Earliest,
        EnableAutoCommit = false,              // Manual commit for at-least-once
        EnableAutoOffsetStore = false,
        MaxPollIntervalMs = 300000,            // 5 min max processing time
        SessionTimeoutMs = 45000,
        HeartbeatIntervalMs = 3000,
        
        SecurityProtocol = SecurityProtocol.SaslSsl,
        SaslMechanism = SaslMechanism.Plain,
        SaslUsername = config["Kafka:SaslUsername"],
        SaslPassword = config["Kafka:SaslPassword"],
    };

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _consumer.Subscribe("icg.orders.validated");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var result = _consumer.Consume(stoppingToken);
                
                using var scope = _scopeFactory.CreateScope();
                var handler = scope.ServiceProvider
                    .GetRequiredService<IOrderValidatedHandler>();
                
                await handler.HandleAsync(result.Message.Value, stoppingToken);
                
                _consumer.Commit(result);       // Commit only on success
            }
            catch (ConsumeException ex)
            {
                _logger.LogError(ex, "Kafka consume error");
                // Continue consuming — don't crash the service
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Processing error — sending to retry topic");
                // Publish to retry topic (see section 6)
            }
        }
    }
}
```

---

## 6. Error Handling & Dead Letter Strategy

### 6.1 Retry Topology

```
icg.orders.validated (main topic)
  │
  ├── Consumer processes successfully ──► Commit offset
  │
  └── Consumer processing fails
        │
        ├── Attempt 1: Immediate retry (in-process)
        ├── Attempt 2: 30-second delay
        ├── Attempt 3: 2-minute delay
        │
        └── All retries exhausted
              │
              ▼
        icg.orders.retry (retry topic)
              │
              ├── Retry consumer picks up after delay
              ├── Re-attempts processing (3 more attempts)
              │
              └── Still failing
                    │
                    ▼
              icg.orders.dlq (dead letter topic)
                    │
                    └── Manual intervention required
                        Alert sent to ops team
```

### 6.2 Retry Event Envelope

```json
{
  "originalEvent": { /* original CloudEvent */ },
  "retryMetadata": {
    "originalTopic": "icg.orders.validated",
    "attemptNumber": 4,
    "maxAttempts": 6,
    "firstFailedAt": "2026-07-26T14:31:05.000Z",
    "lastError": "IBM MQ connection refused: MQRC_Q_MGR_NOT_AVAILABLE",
    "nextRetryAt": "2026-07-26T14:35:05.000Z"
  }
}
```

### 6.3 DLQ Alert Payload

When an event lands in the DLQ, an alert is fired:

```json
{
  "alertType": "ORDER_DLQ",
  "severity": "HIGH",
  "trackingId": "0192f8a0-...",
  "purchaseOrderNumber": "CUST-PO-001",
  "failedTopic": "icg.orders.validated",
  "totalAttempts": 6,
  "lastError": "IBM MQ connection refused after 6 attempts",
  "firstFailedAt": "2026-07-26T14:31:05.000Z",
  "dlqEntryAt": "2026-07-26T14:45:05.000Z"
}
```

---

## 7. Consumer Group Design

| Consumer Group | Topics Consumed | Max Instances | Purpose |
|----------------|----------------|---------------|---------|
| `icg-order-worker` | `icg.orders.validated` | 12 (= partition count) | Main order processing → IBM MQ |
| `icg-order-webhook` | `icg.orders.status-changed` | 6 | Webhook dispatch |
| `icg-order-retry` | `icg.orders.retry` | 3 | Retry processing |

---

## 8. Schema Registry (Optional but Recommended)

| Setting | Value |
|---------|-------|
| **Registry** | Confluent Schema Registry or Apicurio |
| **Format** | JSON Schema (aligns with REST payload format) |
| **Compatibility** | `BACKWARD` — consumers must handle old schemas |
| **Validation** | Producer validates against registered schema before publishing |

### Example Schema Registration

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "icg.orders.validated.v1",
  "title": "OrderValidatedEvent",
  "type": "object",
  "required": ["trackingId", "orderId", "purchaseOrderNumber", "currentStatus"],
  "properties": {
    "trackingId": { "type": "string", "format": "uuid" },
    "orderId": { "type": "string", "format": "uuid" },
    "purchaseOrderNumber": { "type": "string", "maxLength": 50 },
    "accountNumber": { "type": "string", "maxLength": 20 },
    "currentStatus": { "type": "string", "enum": ["Validated"] },
    "lineItemCount": { "type": "integer", "minimum": 1 },
    "validatedAt": { "type": "string", "format": "date-time" }
  }
}
```

---

## 9. Kafka Cluster Configuration Recommendations

| Setting | Value | Rationale |
|---------|-------|-----------|
| `replication.factor` | 3 | Data durability across broker failures |
| `min.insync.replicas` | 2 | Write quorum for `acks=all` |
| `log.retention.hours` | 168 (7 days) | Main topics; 720 (30 days) for DLQ |
| `log.segment.bytes` | 1 GB | Segment size for log compaction |
| `num.partitions` (default) | 12 | Sufficient for initial scaling needs |
| `message.max.bytes` | 1 MB | PO payloads are typically < 50 KB |

---

## 10. Observability

### Kafka-Specific Metrics to Monitor

| Metric | Source | Alert Threshold |
|--------|--------|----------------|
| **Consumer lag** | `kafka_consumer_group_lag` | > 1000 messages for > 5 min |
| **Producer errors/sec** | `kafka_producer_record_error_total` | > 0 sustained for > 1 min |
| **Rebalance events** | `kafka_consumer_coordinator_rebalance_total` | > 3 in 10 min |
| **DLQ message count** | `kafka_topic_partition_offset` on DLQ | Any new messages |
| **Consumer commit latency** | `kafka_consumer_commit_latency_avg` | > 500 ms |

### Trace Propagation

W3C `traceparent` is propagated via Kafka message headers, enabling end-to-end distributed tracing:

```
HTTP Request → API Module → Kafka Header → Worker Module → IBM MQ
    └── traceparent: 00-{traceId}-{spanId}-01
```
