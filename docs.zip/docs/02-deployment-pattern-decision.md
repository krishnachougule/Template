# 02 — Deployment Pattern Decision Record

> **ADR-001:** Frontend API & Backend Worker — Modular Monolith vs. Independent Microservices

---

## Status

**ACCEPTED** — Modular Monolith with documented extraction path.

---

## Context

The Order Service comprises two logical components:

1. **API Module (Frontend):** Receives HTTP requests, stores raw PO payloads, orchestrates account validation, and publishes events to Kafka.
2. **Worker Module (Backend):** Consumes Kafka events, transforms orders, posts to IBM MQ, dispatches webhook callbacks.

The question is whether these should be deployed as a **single application** (modular monolith) or **two independent microservices**.

---

## Decision

**We recommend a Modular Monolith** — a single deployable unit with strict internal module boundaries.

---

## Evaluation Matrix

| Criterion | Modular Monolith | Independent Microservices | Winner |
|-----------|-----------------|--------------------------|--------|
| **Shared Domain Model** | Direct in-process reference to `PurchaseOrder`, `OrderStatus`, state machine. No serialization overhead. | Must duplicate models or maintain a shared NuGet package. Schema drift risk. | 🏆 Monolith |
| **Database Access** | Single EF Core `DbContext`. Transactional consistency for write + status update. | Each service needs its own DB or shared DB (anti-pattern). Eventual consistency required. | 🏆 Monolith |
| **Deployment Complexity** | 1 Helm chart, 1 CI/CD pipeline, 1 Docker image. | 2 Helm charts, 2 pipelines, 2 images, versioned API contracts between them. | 🏆 Monolith |
| **Operational Overhead** | Single set of health checks, logs, and metrics. One pod to debug. | Distributed tracing required even for internal communication. More K8s resources. | 🏆 Monolith |
| **Development Velocity** | Single solution, shared tests, refactor-friendly. Feature changes touch one repo. | Cross-service changes require coordinated releases. Integration test complexity. | 🏆 Monolith |
| **Independent Scaling** | Both modules scale together (HPA on CPU/memory). Worker cannot scale independently of API. | API and Worker scale independently based on their own metrics (HTTP latency vs. Kafka lag). | 🏆 Microservices |
| **Fault Isolation** | A crash in the Worker (e.g., IBM MQ connection leak) can take down the API. Must use `BackgroundService` isolation. | Complete process isolation. Worker crash does not affect API availability. | 🏆 Microservices |
| **Technology Flexibility** | Both modules must use the same runtime (.NET 10). | Worker could theoretically be written in a different language (e.g., Java for Kafka). | 🏆 Microservices |
| **Team Autonomy** | Single team owns both. Fine for teams < 15 engineers. | Different teams can own API vs. Worker independently. Better for 15+ engineer teams. | 🏆 Microservices |

**Score: Modular Monolith 5 — Microservices 4**

---

## Detailed Justification

### Why Modular Monolith Wins

1. **Shared Domain is the Strongest Signal.**
   The API and Worker operate on the *same* domain entity (`PurchaseOrder`) and share the *same* state machine (`OrderStatus`). In a microservices split, you would need to either:
   - Duplicate the domain model (schema drift risk), or
   - Maintain a shared NuGet package (versioning and diamond dependency risk).
   
   A modular monolith eliminates this entirely with in-process references.

2. **Transactional Consistency Matters Here.**
   The API module must atomically:
   - Write the raw PO to PostgreSQL
   - Set the initial status to `Received`
   - Return a `trackingId`
   
   Later, the Worker must atomically:
   - Update the status to `PostedToMQ`
   - Record the MQ message ID
   
   With a shared database and `DbContext`, these are simple transactions. Splitting into microservices forces eventual consistency patterns (Outbox, Saga) that add complexity disproportionate to the benefit.

3. **Kafka Already Provides Decoupling.**
   The API and Worker are *already* decoupled via Kafka. The API produces events; the Worker consumes them. This provides:
   - Temporal decoupling (Worker processes at its own pace)
   - Load buffering (Kafka absorbs bursts)
   - Replayability (Kafka retention)
   
   Deploying them as separate services adds *network-level* decoupling on top of *event-level* decoupling, which provides diminishing returns.

4. **Kubernetes Handles the "Single Point of Failure" Risk.**
   The concern about Worker crashes affecting the API is mitigated by:
   - Running the Worker as a `BackgroundService` with independent error handling
   - Kubernetes health probes that restart unhealthy pods
   - Multiple replicas ensuring availability during restarts

### When to Extract to Microservices

The monolith should be split **only when** one of these conditions becomes true:

| Trigger | Extraction Target |
|---------|------------------|
| Worker scaling needs diverge significantly from API (e.g., 10x Kafka consumers needed, but API load is flat) | Extract Worker into a separate Deployment with independent HPA |
| A separate team takes ownership of the IBM MQ integration | Extract Worker into its own repository and CI/CD pipeline |
| Worker needs a different runtime (e.g., Java for a Kafka Streams topology) | Extract Worker as a new service in the target language |
| Regulatory or security requirements mandate process isolation | Deploy API and Worker as separate pods with network policies |

---

## Module Boundary Enforcement

Even within a monolith, strict boundaries prevent the "big ball of mud" anti-pattern:

```
OrderService.sln
├── src/
│   ├── OrderService.Api/              ← API Module (ASP.NET Core)
│   │   ├── Endpoints/                 ← Minimal API endpoint groups
│   │   ├── Middleware/                ← Correlation ID, error handling
│   │   └── Program.cs                ← HTTP host configuration
│   │
│   ├── OrderService.Worker/           ← Worker Module (BackgroundService)
│   │   ├── Consumers/                 ← Kafka consumer handlers
│   │   ├── Producers/                 ← IBM MQ message producers
│   │   └── Dispatchers/              ← Webhook dispatch logic
│   │
│   ├── OrderService.Domain/           ← Shared Kernel
│   │   ├── Models/                    ← PurchaseOrder, POA, ValueObjects
│   │   ├── StateMachine/             ← OrderLifecycleStateMachine
│   │   ├── Events/                    ← Domain events (OrderValidated, etc.)
│   │   └── Contracts/                 ← Interfaces for ports
│   │
│   ├── OrderService.Infrastructure/   ← Infrastructure Concerns
│   │   ├── Persistence/              ← EF Core DbContext, Repositories
│   │   ├── Kafka/                     ← Producer/Consumer wrappers
│   │   ├── Mq/                        ← IBM MQ client wrapper
│   │   ├── Validation/               ← Account Validation HTTP client
│   │   └── Webhooks/                  ← Webhook HTTP client
│   │
│   └── OrderService.Contracts/        ← API Contracts (DTOs, shared enums)
│       ├── Requests/
│       ├── Responses/
│       └── Events/
│
└── tests/
    ├── OrderService.UnitTests/
    ├── OrderService.IntegrationTests/
    └── OrderService.ArchTests/        ← ArchUnit tests for boundary enforcement
```

### Boundary Rules

| Rule | Enforcement |
|------|-------------|
| `Api` project cannot reference `Worker` project | `.csproj` dependency direction |
| `Worker` project cannot reference `Api` project | `.csproj` dependency direction |
| `Domain` has zero infrastructure dependencies | ArchUnit test: `Domain` → no references to `EF Core`, `Kafka`, `IBM MQ` |
| `Infrastructure` depends on `Domain` (not reverse) | `.csproj` dependency direction |
| Cross-module communication only via domain events | ArchUnit test: no direct method calls between `Api` and `Worker` |

---

## Consequences

### Positive
- Simpler operations (one deployment, one pipeline)
- Shared domain model with zero duplication
- Transactional consistency without Outbox/Saga patterns
- Faster development cycle for a single team

### Negative
- Cannot scale API and Worker independently (mitigated by Kafka buffering)
- Worker failure could theoretically impact API (mitigated by `BackgroundService` isolation and K8s probes)
- Both modules must upgrade to new .NET versions together

### Risks
- **Risk:** Module boundaries erode over time → **Mitigation:** ArchUnit tests in CI/CD that fail the build if boundaries are violated
- **Risk:** Monolith grows too large → **Mitigation:** Documented extraction triggers (table above) and clean module boundaries that make extraction straightforward

---

## Future State Architecture (If Extraction Is Needed)

```
  ┌──────────────────┐          ┌──────────────────┐
  │  order-api       │          │  order-worker     │
  │  (Deployment)    │          │  (Deployment)     │
  │                  │          │                   │
  │  • HTTP endpoints│          │  • Kafka consumer │
  │  • DB writes     │──Kafka──▶│  • IBM MQ sink    │
  │  • Kafka producer│          │  • Webhook sender │
  └──────────────────┘          └──────────────────┘
         │                              │
         ▼                              ▼
  ┌──────────────────┐          ┌──────────────────┐
  │  PostgreSQL      │          │  PostgreSQL       │
  │  (API schema)    │          │  (Worker schema)  │
  └──────────────────┘          └──────────────────┘
```

> **Key:** If extracted, the Worker would get its own database schema (or a separate database), and the shared domain model would move to a versioned NuGet package (`OrderService.Contracts`).
