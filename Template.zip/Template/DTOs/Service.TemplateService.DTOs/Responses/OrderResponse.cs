namespace ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

/// <summary>
/// Order response DTO for API responses.
/// </summary>
public record OrderResponse
{
    public int Id { get; init; }
    public string OrderNumber { get; init; } = string.Empty;
    public string CustomerId { get; init; } = string.Empty;
    public string CustomerName { get; init; } = string.Empty;
    public string? CustomerPoRef { get; init; }
    public string OrderType { get; init; } = string.Empty;
    public string Channel { get; init; } = string.Empty;
    public string? SalesRepId { get; init; }
    public decimal SubtotalAmount { get; init; }
    public decimal DiscountAmount { get; init; }
    public decimal TaxAmount { get; init; }
    public decimal TotalAmount { get; init; }
    public string Currency { get; init; } = "USD";
    public string Status { get; init; } = string.Empty;
    public string? CancellationReason { get; init; }
    public string CreditStatus { get; init; } = string.Empty;
    public DateTime? CreditCheckedAt { get; init; }
    public DateTime? RequestedShipDate { get; init; }
    public DateTime? ConfirmedShipDate { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime UpdatedAt { get; init; }
    public string CreatedBy { get; init; } = string.Empty;
    public string UpdatedBy { get; init; } = string.Empty;
    public int RowVersion { get; init; }
}
