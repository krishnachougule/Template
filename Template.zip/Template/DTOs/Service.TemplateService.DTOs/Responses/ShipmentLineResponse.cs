namespace ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

/// <summary>
/// ShipmentLine response DTO for API responses.
/// </summary>
public record ShipmentLineResponse
{
    public int Id { get; init; }
    public int ShipmentId { get; init; }
    public string ShipmentNumber { get; init; } = string.Empty;
    public int OrderId { get; init; }
    public string OrderNumber { get; init; } = string.Empty;
    public short LineNumber { get; init; }
    public string OrderLineRef { get; init; } = string.Empty;
    public string Sku { get; init; } = string.Empty;
    public string ProductName { get; init; } = string.Empty;
    public string ProductCategory { get; init; } = string.Empty;
    public int QuantityOrdered { get; init; }
    public int QuantityShipped { get; init; }
    public int QuantityBackordered { get; init; }
    public string UnitOfMeasure { get; init; } = string.Empty;
    public decimal UnitPrice { get; init; }
    public decimal LineDiscount { get; init; }
    public decimal LineTotal { get; init; }
    public string Currency { get; init; } = "USD";
    public string WarehouseBin { get; init; } = string.Empty;
    public string? LotNumber { get; init; }
    public string? SerialNumber { get; init; }
    public string Status { get; init; } = string.Empty;
    public string? BackorderReason { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime UpdatedAt { get; init; }
    public string CreatedBy { get; init; } = string.Empty;
    public string UpdatedBy { get; init; } = string.Empty;
    public int RowVersion { get; init; }
}
