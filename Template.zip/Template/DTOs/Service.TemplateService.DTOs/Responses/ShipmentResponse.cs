namespace ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

/// <summary>
/// Shipment response DTO for API responses.
/// </summary>
public record ShipmentResponse
{
    public int Id { get; init; }
    public int OrderId { get; init; }
    public string OrderNumber { get; init; } = string.Empty;
    public string ShipmentNumber { get; init; } = string.Empty;
    public short ShipmentSequence { get; init; }
    public string CarrierCode { get; init; } = string.Empty;
    public string ServiceLevel { get; init; } = string.Empty;
    public string? TrackingNumber { get; init; }
    public string WarehouseCode { get; init; } = string.Empty;
    public string ShipToName { get; init; } = string.Empty;
    public string ShipToAddress1 { get; init; } = string.Empty;
    public string? ShipToAddress2 { get; init; }
    public string ShipToCity { get; init; } = string.Empty;
    public string ShipToState { get; init; } = string.Empty;
    public string ShipToZip { get; init; } = string.Empty;
    public string ShipToCountry { get; init; } = "US";
    public short TotalPackages { get; init; }
    public decimal TotalWeightKg { get; init; }
    public decimal ShippingCost { get; init; }
    public string Status { get; init; } = string.Empty;
    public string? FailureReason { get; init; }
    public DateTime? EstimatedDelivery { get; init; }
    public DateTime? DispatchedAt { get; init; }
    public DateTime? DeliveredAt { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime UpdatedAt { get; init; }
    public string CreatedBy { get; init; } = string.Empty;
    public string UpdatedBy { get; init; } = string.Empty;
    public int RowVersion { get; init; }
}
