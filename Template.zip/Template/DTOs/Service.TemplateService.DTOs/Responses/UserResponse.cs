namespace ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

/// <summary>
/// Response DTO for a JSONPlaceholder user.
/// </summary>
public record UserResponse
{
    public int Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public string Username { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string Phone { get; init; } = string.Empty;
    public string Website { get; init; } = string.Empty;
}
