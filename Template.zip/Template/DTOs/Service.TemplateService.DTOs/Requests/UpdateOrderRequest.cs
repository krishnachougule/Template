using System.ComponentModel.DataAnnotations;

namespace ICG.Fulfillment.Service.TemplateService.DTOs.Requests;

/// <summary>
/// Request DTO for updating an existing order.
/// </summary>
public record UpdateOrderRequest
{
    [Required]
    public int Id { get; init; }
    
    [Required]
    public string OrderNumber { get; init; } = string.Empty;
    
    [Required]
    public string CustomerId { get; init; } = string.Empty;
    
    [Required]
    public string CustomerName { get; init; } = string.Empty;
    
    public string? CustomerPoRef { get; init; }
    
    [Required]
    public string OrderType { get; init; } = string.Empty;
    
    [Required]
    public string Channel { get; init; } = string.Empty;
    
    public string? SalesRepId { get; init; }
    
    [Required]
    public decimal SubtotalAmount { get; init; }
    
    public decimal DiscountAmount { get; init; }
    
    public decimal TaxAmount { get; init; }
    
    [Required]
    public decimal TotalAmount { get; init; }
    
    public string Currency { get; init; } = "USD";
    
    [Required]
    public string Status { get; init; } = string.Empty;
    
    public string? CancellationReason { get; init; }
    
    [Required]
    public string CreditStatus { get; init; } = string.Empty;
    
    public DateTime? CreditCheckedAt { get; init; }
    
    public DateTime? RequestedShipDate { get; init; }
    
    public DateTime? ConfirmedShipDate { get; init; }
    
    [Required]
    public string UpdatedBy { get; init; } = string.Empty;
    
    [Required]
    public int RowVersion { get; init; }
}
