using System.ComponentModel.DataAnnotations;

namespace ICG.Fulfillment.Service.TemplateService.DTOs.Requests;

/// <summary>
/// Request DTO for updating an existing shipment.
/// </summary>
public record UpdateShipmentRequest
{
    [Required]
    public int Id { get; init; }
    
    [Required]
    public string ShipmentNumber { get; init; } = string.Empty;
    
    [Required]
    public string CarrierCode { get; init; } = string.Empty;
    
    [Required]
    public string ServiceLevel { get; init; } = string.Empty;
    
    public string? TrackingNumber { get; init; }
    
    [Required]
    public string Status { get; init; } = string.Empty;
    
    public string? FailureReason { get; init; }
    
    public DateTime? EstimatedDelivery { get; init; }
    
    public DateTime? DispatchedAt { get; init; }
    
    public DateTime? DeliveredAt { get; init; }
    
    [Required]
    public string UpdatedBy { get; init; } = string.Empty;
    
    [Required]
    public int RowVersion { get; init; }
}
