using System.ComponentModel.DataAnnotations;

namespace ICG.Fulfillment.Service.TemplateService.DTOs.Requests;

/// <summary>
/// Request DTO for creating a new shipment.
/// </summary>
public record CreateShipmentRequest
{
    [Required]
    public int OrderId { get; init; }
    
    [Required]
    public string OrderNumber { get; init; } = string.Empty;
    
    [Required]
    public string ShipmentNumber { get; init; } = string.Empty;
    
    [Required]
    public short ShipmentSequence { get; init; }
    
    [Required]
    public string CarrierCode { get; init; } = string.Empty;
    
    [Required]
    public string ServiceLevel { get; init; } = string.Empty;
    
    public string? TrackingNumber { get; init; }
    
    [Required]
    public string WarehouseCode { get; init; } = string.Empty;
    
    [Required]
    public string ShipToName { get; init; } = string.Empty;
    
    [Required]
    public string ShipToAddress1 { get; init; } = string.Empty;
    
    public string? ShipToAddress2 { get; init; }
    
    [Required]
    public string ShipToCity { get; init; } = string.Empty;
    
    [Required]
    public string ShipToState { get; init; } = string.Empty;
    
    [Required]
    public string ShipToZip { get; init; } = string.Empty;
    
    public string ShipToCountry { get; init; } = "US";
    
    [Required]
    public short TotalPackages { get; init; }
    
    [Required]
    public decimal TotalWeightKg { get; init; }
    
    [Required]
    public decimal ShippingCost { get; init; }
    
    [Required]
    public string Status { get; init; } = string.Empty;
    
    public string? FailureReason { get; init; }
    
    public DateTime? EstimatedDelivery { get; init; }
    
    public DateTime? DispatchedAt { get; init; }
    
    public DateTime? DeliveredAt { get; init; }
    
    [Required]
    public string CreatedBy { get; init; } = string.Empty;
}
