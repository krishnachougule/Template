﻿using IGC.Fulfillment.Shared.Translator.Constants;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using IGC.Fulfillment.Shared.Translator.Mappers;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading;

namespace IGC.Fulfillment.Shared.Translator
{
    public class TranslatorService : ITranslatorService
    {
        private readonly ConcurrentDictionary<(Type Target, Type Source), IBaseTranslator> _translators = new();
        private readonly ConcurrentDictionary<(Type Source, Type Target), object> _autoMapperCache = new();

        private static readonly JsonSerializerOptions _caseInsensitiveOptions = new() { PropertyNameCaseInsensitive = true };
        private static readonly JsonSerializerOptions _caseSensitiveOptions   = new() { PropertyNameCaseInsensitive = false };
        private static readonly Lazy<IReadOnlyList<Type>> _translatorTypes = new(DiscoverTranslatorTypes);

        public TranslatorService() { }

        public TranslatorService(IServiceProvider provider)
        {
            RegisterAllTranslators(provider);
        }

        public Boolean CanTranslate(Type targetType, Type sourceType)
        {
            if (targetType == null)
                throw new ArgumentNullException(nameof(targetType), TypeConstants.Exceptions.TargetTypeNull);
            if (sourceType == null)
                throw new ArgumentNullException(nameof(sourceType), TypeConstants.Exceptions.SourceTypeNull);

            return FindTranslator(targetType, sourceType) != null;
        }

        public Boolean CanTranslate<TSource, TTarget>()
            => CanTranslate(typeof(TSource), typeof(TTarget));

        public void RegisterTranslator(IBaseTranslator translator)
        {
            if (translator == null)
                throw new ArgumentException(TypeConstants.Exceptions.RegisterTranslatorNull);

            var type = translator.GetType();

            // First try the base class (works for BaseTranslator<TEntity, TDto>)
            var args = type.BaseType?.GetGenericArguments();

            // Fallback: check the type itself if it's a closed generic (works for AutoTranslator<TSource, TTarget>)
            if (args?.Length != 2 && type.IsGenericType)
            {
                args = type.GetGenericArguments();
            }

            if (args?.Length == 2)
            {
                _translators.TryAdd((args[0], args[1]), translator);
                _translators.TryAdd((args[1], args[0]), translator);
            }
            else
            {
                _translators.TryAdd((type, type), translator);
            }
        }

        public void RemoveTranslator(IBaseTranslator translator)
        {
            if (translator == null)
                throw new ArgumentException(TypeConstants.Exceptions.RemoveTranslatorNull);

            foreach (var key in _translators.Where(kv => kv.Value == translator).Select(kv => kv.Key).ToList())
                _translators.TryRemove(key, out _);
        }

        public void RegisterAutoTranslator<TSource, TTarget>()
            where TSource : class, new()
            where TTarget : class, new()
        {
            var translator = new AutoTranslator<TSource, TTarget>();
            _translators.TryAdd((typeof(TTarget), typeof(TSource)), translator);
            _translators.TryAdd((typeof(TSource), typeof(TTarget)), translator);
        }

        public Object Translate(Object target, Object source)
        {
            if (target == null) throw new ArgumentNullException(nameof(target));
            if (source == null) throw new ArgumentNullException(nameof(source));

            Type targetType = target.GetType();
            Type sourceType = source.GetType();
            IBaseTranslator translator = FindTranslator(targetType, sourceType);
            if (translator != null)
                return translator.Translate(targetType, target, source);

            throw new TranslatorException(TypeConstants.Exceptions.TranslatorNotFound);
        }

        public TType Translate<TType>(Object source) where TType : new()
            => (TType)Translate(new TType(), source);

        public TType Translate<TType>(Object target, Object source)
            => (TType)Translate(target, source);

        public TType TranslateDefault<TType>(Object source, bool ignoreCase = true) where TType : new()
        {
            var options = ignoreCase ? _caseInsensitiveOptions : _caseSensitiveOptions;
            var element = JsonSerializer.SerializeToElement(source);
            return element.Deserialize<TType>(options)!;
        }

        public IEnumerable<TType> TranslateRange<TType>(IEnumerable<Object> target, IEnumerable<Object> source)
            => source.Zip(target, (s, t) => (TType)Translate(t, s));

        public IEnumerable<TType> TranslateRange<TType>(IEnumerable<Object> source) where TType : new()
            => source.Select(o => (TType)Translate(new TType(), o));

        public IEnumerable<TType> TranslateRangeDefault<TType>(IEnumerable<Object> source, bool ignoreCase = true) where TType : new()
            => source.Select(o => TranslateDefault<TType>(o, ignoreCase));

        public TTarget Translate<TTarget, TSource>(TTarget target, IEnumerable<Object> source) where TTarget : new()
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            foreach (var item in source)
                Translate(target, item);

            return target;
        }

        public TTarget Map<TSource, TTarget>(TSource source)
            where TSource : class
            where TTarget : class, new()
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var translator = FindTranslator(typeof(TTarget), typeof(TSource));
            if (translator != null)
                return (TTarget)translator.Translate(typeof(TTarget), new TTarget(), source);

            return GetOrCreateAutoMapper<TSource, TTarget>().Map(source);
        }

        public TTarget Map<TTarget>(object source) where TTarget : class, new()
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            Type sourceType = source.GetType();
            var translator = FindTranslator(typeof(TTarget), sourceType);
            if (translator != null)
                return (TTarget)translator.Translate(typeof(TTarget), new TTarget(), source);

            throw new TranslatorException($"No translator registered from {sourceType.Name} to {typeof(TTarget).Name}.");
        }

        public TTarget Map<TSource, TTarget>(TSource source, TTarget target)
            where TSource : class
            where TTarget : class
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (target == null) throw new ArgumentNullException(nameof(target));

            var translator = FindTranslator(typeof(TTarget), typeof(TSource));
            if (translator != null)
                return (TTarget)translator.Translate(typeof(TTarget), target, source);

            return GetOrCreateAutoMapper<TSource, TTarget>().Map(source, target);
        }

        public IEnumerable<TTarget> MapRange<TSource, TTarget>(IEnumerable<TSource> source)
            where TSource : class
            where TTarget : class, new()
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var translator = FindTranslator(typeof(TTarget), typeof(TSource));
            if (translator != null)
                return source.Select(s => (TTarget)translator.Translate(typeof(TTarget), new TTarget(), s)).ToList();

            var mapper = GetOrCreateAutoMapper<TSource, TTarget>();
            return source.Select(s => mapper.Map(s)).ToList();
        }

        public IEnumerable<TTarget> MapRange<TTarget>(IEnumerable<object> source) where TTarget : class, new()
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            Type sourceType = source.GetType();
            var translator = FindTranslator(typeof(TTarget), sourceType);
            if (translator != null)
                return source.Select(s => (TTarget)translator.Translate(typeof(TTarget), new TTarget(), s)).ToList();

            throw new TranslatorException($"No translator registered from {sourceType.Name} to {typeof(TTarget).Name}.");
        }

        private IPropertyMapper<TSource, TTarget> GetOrCreateAutoMapper<TSource, TTarget>()
            where TSource : class
            where TTarget : class
        {
            var key = (typeof(TSource), typeof(TTarget));
            if (_autoMapperCache.TryGetValue(key, out var cached))
                return (IPropertyMapper<TSource, TTarget>)cached;

            var mapper = CompiledPropertyMapper<TSource, TTarget>.Create();
            _autoMapperCache.TryAdd(key, mapper);
            return mapper;
        }

        private IBaseTranslator FindTranslator(Type targetType, Type sourceType)
        {
            var key = (targetType, sourceType);
            if (_translators.TryGetValue(key, out var translator))
                return translator;

            // Linear scan fallback — cache the result to avoid repeated scans
            translator = _translators.Values.FirstOrDefault(t => t.CanTranslate(targetType, sourceType));
            if (translator != null)
            {
                _translators.TryAdd(key, translator);
            }

            return translator;
        }

        private static IReadOnlyList<Type> DiscoverTranslatorTypes()
        {
            Type baseTranslator = typeof(IBaseTranslator);
            return AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(assembly =>
                {
                    try { return assembly.GetTypes(); }
                    catch { return Array.Empty<Type>(); }
                })
                .Where(type => !type.IsInterface
                    && !type.IsAbstract
                    && !type.IsGenericTypeDefinition
                    && baseTranslator.IsAssignableFrom(type))
                .ToList();
        }

        private void RegisterAllTranslators(IServiceProvider services)
        {
            foreach (Type type in _translatorTypes.Value)
            {
                try
                {
                    ConstructorInfo[] constructors = type.GetConstructors();
                    if (constructors.Any(ctor => ctor.GetParameters().Any()))
                    {
                        var parameters = constructors
                            .OrderByDescending(ctor => ctor.GetParameters().Length)
                            .First()
                            .GetParameters();

                        var args = new List<Object>();
                        foreach (ParameterInfo param in parameters)
                        {
                            args.Add(param.ParameterType == typeof(ITranslatorService)
                                ? this
                                : services.GetRequiredService(param.ParameterType));
                        }

                        RegisterTranslator((IBaseTranslator)Activator.CreateInstance(type, args.ToArray()));
                    }
                    else
                    {
                        RegisterTranslator((IBaseTranslator)Activator.CreateInstance(type));
                    }
                }
                catch (Exception)
                {
                    // Skip translators whose dependencies can't be resolved —
                    // don't let one bad registration prevent all others from loading.
                    // The Map<,>() fallback to CompiledPropertyMapper will handle
                    // unregistered pairs automatically.
                }
            }
        }
    }
}