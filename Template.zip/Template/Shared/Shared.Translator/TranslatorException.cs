﻿using System;

namespace IGC.Fulfillment.Shared.Translator
{
    public class TranslatorException : Exception
    {
        public TranslatorException() : base() { }
        public TranslatorException(String message) : base(message) { }
        public TranslatorException(String message, System.Exception innerException) : base(message, innerException) { }
    }
}
