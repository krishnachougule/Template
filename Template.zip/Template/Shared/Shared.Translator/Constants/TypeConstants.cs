﻿
namespace IGC.Fulfillment.Shared.Translator.Constants
{
    public static class TypeConstants
    {
        public static class Exceptions
        {
            public const string TargetTypeNull         = "Cannot translate an Object to a null type.";
            public const string SourceTypeNull         = "Cannot translate an Object of null type to a target type.";
            public const string RegisterTranslatorNull = "The translator being registered is not available.";
            public const string RemoveTranslatorNull   = "The translator being removed is not available.";
            public const string TranslatorNotFound     = "There are no register translators for the target and source type provided.";
            public const string InvalidType            = "Invalid type passed to Translator";
        }
    }
}
