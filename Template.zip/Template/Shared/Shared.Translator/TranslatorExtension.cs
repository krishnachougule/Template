﻿using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace IGC.Fulfillment.Shared.Translator
{
    public static class TranslatorExtension
    {
        public static void AddTranslatorService(this IServiceCollection services)
        {
            services.AddScoped<ITranslatorService>(provider => new TranslatorService(provider));
        }
    }
}