using System;

namespace IGC.Fulfillment.Shared.Translator.Mappers
{
    public interface IPropertyMapper<TSource, TTarget>
    {
        TTarget Map(TSource source);
        TTarget Map(TSource source, TTarget target);
    }
}
