using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;

namespace IGC.Fulfillment.Shared.Translator.Mappers
{
    public class CompiledPropertyMapper<TSource, TTarget> : IPropertyMapper<TSource, TTarget>
        where TSource : class
        where TTarget : class
    {
        private readonly Func<TSource, TTarget> _mapFunc;
        private readonly Action<TSource, TTarget> _mapToExistingFunc;

        // Bug 4 fix: static field on a generic class is already per-closed-type (CompiledPropertyMapper<A,B>
        // and CompiledPropertyMapper<C,D> are different types with different statics).
        // The ConcurrentDictionary key was always identical to the type params � a dictionary of one entry.
        // Use a plain nullable static field instead � O(1) read, zero allocation, correct semantics.
        private static CompiledPropertyMapper<TSource, TTarget>? _instance;

        private CompiledPropertyMapper(Func<TSource, TTarget> mapFunc, Action<TSource, TTarget> mapToExistingFunc)
        {
            _mapFunc = mapFunc;
            _mapToExistingFunc = mapToExistingFunc;
        }

        public TTarget Map(TSource source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            return _mapFunc(source);
        }

        public TTarget Map(TSource source, TTarget target)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (target == null) throw new ArgumentNullException(nameof(target));
            _mapToExistingFunc(source, target);
            return target;
        }

        public static CompiledPropertyMapper<TSource, TTarget> Create()
        {
            if (_instance is not null)
                return _instance;

            var mapper = new CompiledPropertyMapper<TSource, TTarget>(
                BuildMapExpression(),
                BuildMapToExistingExpression()
            );

            Interlocked.CompareExchange(ref _instance, mapper, null);
            return _instance!;
        }

        private static Func<TSource, TTarget> BuildMapExpression()
        {
            var sourceParam = Expression.Parameter(typeof(TSource), "source");
            var targetVar   = Expression.Variable(typeof(TTarget), "target");

            var sourceProps = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanRead)
                .ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);

            var targetProps = typeof(TTarget).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanWrite);

            var targetCtor = typeof(TTarget).GetConstructor(Type.EmptyTypes)
                ?? throw new InvalidOperationException($"Type {typeof(TTarget).Name} must have a parameterless constructor.");

            var assignments = new List<Expression> { Expression.Assign(targetVar, Expression.New(targetCtor)) };

            foreach (var targetProp in targetProps)
            {
                if (!sourceProps.TryGetValue(targetProp.Name, out var sourceProp)) continue;
                if (!AreTypesCompatible(sourceProp.PropertyType, targetProp.PropertyType)) continue;

                var sourceValue    = Expression.Property(sourceParam, sourceProp);
                var convertedValue = BuildConversion(sourceValue, sourceProp.PropertyType, targetProp.PropertyType);
                if (convertedValue == null) continue;

                assignments.Add(Expression.Assign(Expression.Property(targetVar, targetProp), convertedValue));
            }

            assignments.Add(targetVar);

            return Expression.Lambda<Func<TSource, TTarget>>(
                Expression.Block(new[] { targetVar }, assignments), sourceParam).Compile();
        }

        private static Action<TSource, TTarget> BuildMapToExistingExpression()
        {
            var sourceParam = Expression.Parameter(typeof(TSource), "source");
            var targetParam = Expression.Parameter(typeof(TTarget), "target");

            var sourceProps = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanRead)
                .ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);

            var targetProps = typeof(TTarget).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanWrite);

            var assignments = new List<Expression>();

            foreach (var targetProp in targetProps)
            {
                if (!sourceProps.TryGetValue(targetProp.Name, out var sourceProp)) continue;
                if (!AreTypesCompatible(sourceProp.PropertyType, targetProp.PropertyType)) continue;

                var sourceValue    = Expression.Property(sourceParam, sourceProp);
                var convertedValue = BuildConversion(sourceValue, sourceProp.PropertyType, targetProp.PropertyType);
                if (convertedValue == null) continue;

                assignments.Add(Expression.Assign(Expression.Property(targetParam, targetProp), convertedValue));
            }

            Expression body = assignments.Count > 0
                ? Expression.Block(assignments)
                : Expression.Empty();

            return Expression.Lambda<Action<TSource, TTarget>>(body, sourceParam, targetParam).Compile();
        }

        private static Expression? BuildConversion(Expression sourceValue, Type sourceType, Type targetType)
        {
            if (sourceType == targetType) return sourceValue;
            if (targetType.IsAssignableFrom(sourceType)) return Expression.Convert(sourceValue, targetType);
            if (IsNullableType(targetType) && Nullable.GetUnderlyingType(targetType) == sourceType)
                return Expression.Convert(sourceValue, targetType);
            if (IsNullableType(sourceType) && Nullable.GetUnderlyingType(sourceType) == targetType)
                return Expression.Condition(
                    Expression.Property(sourceValue, "HasValue"),
                    Expression.Property(sourceValue, "Value"),
                    Expression.Default(targetType));

            return null;
        }

        private static bool AreTypesCompatible(Type sourceType, Type targetType)
        {
            if (sourceType == targetType) return true;
            if (targetType.IsAssignableFrom(sourceType)) return true;

            var srcUnderlying = Nullable.GetUnderlyingType(sourceType);
            var tgtUnderlying = Nullable.GetUnderlyingType(targetType);

            if (srcUnderlying != null && tgtUnderlying != null) return srcUnderlying == tgtUnderlying;
            if (srcUnderlying != null && targetType == srcUnderlying) return true;
            if (tgtUnderlying != null && sourceType == tgtUnderlying) return true;

            return false;
        }

        private static bool IsNullableType(Type type)
            => type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>);
    }
}
