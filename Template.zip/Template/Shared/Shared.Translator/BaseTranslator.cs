﻿using System;
using System.Collections.Generic;
using System.Linq;
using IGC.Fulfillment.Shared.Translator.Constants;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using IGC.Fulfillment.Shared.Translator.Mappers;

namespace IGC.Fulfillment.Shared.Translator
{
    public abstract class BaseTranslator<TEntity, TDto> : IBaseTranslator
        where TEntity : class, new()
        where TDto : class, new()
    {
        // Bug 3 fix: PublicationOnly avoids holding a lock during factory execution
        // Safe here because CompiledPropertyMapper.Create() is idempotent
        private readonly Lazy<IPropertyMapper<TEntity, TDto>> _entityToDtoMapper =
            new(() => CompiledPropertyMapper<TEntity, TDto>.Create(), LazyThreadSafetyMode.PublicationOnly);

        private readonly Lazy<IPropertyMapper<TDto, TEntity>> _dtoToEntityMapper =
            new(() => CompiledPropertyMapper<TDto, TEntity>.Create(), LazyThreadSafetyMode.PublicationOnly);

        public bool CanTranslate(Type targetType, Type sourceType)
        {
            return (targetType == typeof(TEntity) && sourceType == typeof(TDto)) ||
                   (targetType == typeof(TDto) && sourceType == typeof(TEntity));
        }

        public object Translate(Type targetType, object target, object source)
        {
            if (targetType == typeof(TEntity))
            {
                if (source is not TDto dtoSource)
                    throw new TranslatorException(
                        $"Expected source of type {typeof(TDto).Name} but received {source?.GetType().Name}");
                return DtoToEntity(target as TEntity ?? new TEntity(), dtoSource);
            }

            if (targetType == typeof(TDto))
            {
                if (source is not TEntity entitySource)
                    throw new TranslatorException(
                        $"Expected source of type {typeof(TEntity).Name} but received {source?.GetType().Name}");
                return EntityToDto(target as TDto ?? new TDto(), entitySource);
            }

            throw new ArgumentException(TypeConstants.Exceptions.InvalidType, nameof(targetType));
        }

        public TType Translate<TType>(object target, object source)
            => (TType)Translate(typeof(TType), target, source);

        protected virtual TDto EntityToDto(TDto dto, TEntity entity)
            => _entityToDtoMapper.Value.Map(entity, dto);

        protected virtual TEntity DtoToEntity(TEntity entity, TDto dto)
            => _dtoToEntityMapper.Value.Map(dto, entity);

        protected IEnumerable<TDto> MapRange(IEnumerable<TEntity> entities)
            => entities?.Select(e => _entityToDtoMapper.Value.Map(e)) ?? Enumerable.Empty<TDto>();

        protected IEnumerable<TEntity> MapRange(IEnumerable<TDto> dtos)
            => dtos?.Select(d => _dtoToEntityMapper.Value.Map(d)) ?? Enumerable.Empty<TEntity>();
    }
}
