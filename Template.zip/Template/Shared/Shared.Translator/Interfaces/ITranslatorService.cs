﻿using System;
using System.Collections.Generic;

namespace IGC.Fulfillment.Shared.Translator.Interfaces
{
    public interface ITranslatorService
    {
        Boolean CanTranslate(Type targetType, Type sourceType);

        Boolean CanTranslate<TSource, TTarget>();

        Object Translate(Object target, Object source);
        TType Translate<TType>(Object source) where TType : new();
        TType Translate<TType>(Object target, Object source);
        TType TranslateDefault<TType>(Object source, bool ignoreCase = true) where TType : new();
        IEnumerable<TType> TranslateRange<TType>(IEnumerable<Object> target, IEnumerable<Object> source);
        IEnumerable<TType> TranslateRange<TType>(IEnumerable<Object> source) where TType : new();
        IEnumerable<TType> TranslateRangeDefault<TType>(IEnumerable<Object> source, bool ignoreCase = true) where TType : new();
        TTarget Translate<TTarget, TSource>(TTarget target, IEnumerable<Object> source) where TTarget : new();

        void RegisterTranslator(IBaseTranslator translator);
        void RemoveTranslator(IBaseTranslator translator);

        TTarget Map<TSource, TTarget>(TSource source) where TSource : class where TTarget : class, new();
        TTarget Map<TSource, TTarget>(TSource source, TTarget target) where TSource : class where TTarget : class;
        TTarget Map<TTarget>(object source) where TTarget : class, new();
        IEnumerable<TTarget> MapRange<TSource, TTarget>(IEnumerable<TSource> source) where TSource : class where TTarget : class, new();
        IEnumerable<TTarget> MapRange<TTarget>(IEnumerable<object> source) where TTarget : class, new();
        void RegisterAutoTranslator<TSource, TTarget>() where TSource : class, new() where TTarget : class, new();
    }
}