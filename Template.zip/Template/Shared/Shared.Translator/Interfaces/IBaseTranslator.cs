﻿using System;

namespace IGC.Fulfillment.Shared.Translator.Interfaces
{
    public interface IBaseTranslator
    {
        Boolean CanTranslate(Type targetType, Type sourceType);
        object Translate(Type targetType, object target, object source);
        TType Translate<TType>(object target, object source);
    }
}
