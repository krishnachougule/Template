# Shared.Translator � Object Translation & Mapping for IGC.Fulfillment

Provides a convention-based object translation engine with **compiled expression trees** for high-performance property mapping. Supports auto-mapping by default, with optional override methods for custom logic � all registered via a single `AddTranslatorService()` call.

---

## Quick Start

### 1. Register in `Program.cs`

```csharp
builder.Services.AddTranslatorService();
```

This registers `ITranslatorService` as a scoped service. On first resolve it auto-discovers all `IBaseTranslator` implementations across loaded assemblies.

### 2. Inject and use

```csharp
public class OrderFacade : BaseFacade<OrderBusinessEntity, OrderEntity>
{
    private readonly IOrderRepository _repository;

    public OrderFacade(IOrderRepository repository, ITranslatorService translator)
        : base(translator)
    {
        _repository = repository;
    }

    public async Task<OrderBusinessEntity?> GetOrderByIdAsync(int id, CancellationToken ct)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = _repository.GetById(id);
            return MapToBusinessEntity(domainEntity); // uses Translator.Map<,>() internally
        }, ct);
    }
}
```

---

## Architecture

```
???????????????????????????????????????????????????????????
?                    ITranslatorService                    ?
?         (scoped � one instance per HTTP request)         ?
???????????????????????????????????????????????????????????
                        ?
        ?????????????????????????????????
        ?                               ?
  ???????????????               ?????????????????
  ? BaseTranslator?               ? AutoTranslator?
  ? (auto-map +  ?               ? (zero-config  ?
  ?  overrides)  ?               ?  runtime)     ?
  ???????????????               ?????????????????
        ?                               ?
        ?????????????????????????????????
                        ?
              ???????????????????????
              ?  CompiledProperty   ?
              ?  Mapper (cached     ?
              ?  expression tree)   ?
              ???????????????????????
```

---

## Translator Types

### `BaseTranslator<TEntity, TDto>` � Auto-Map with Optional Overrides

The single base class for all translators. Matching properties (case-insensitive) are auto-mapped via compiled expression trees. Override `EntityToDto` or `DtoToEntity` only when you need custom logic � calling `base` first applies the auto-mapping.

```csharp
// Zero-config: all matching properties auto-mapped
public class OrderBusinessEntityToResponseTranslator : BaseTranslator<OrderBusinessEntity, OrderResponse>
{
}

// With overrides for custom logic (e.g., snake_case domain ? PascalCase business)
public class OrderEntityToBusinessEntityTranslator : BaseTranslator<OrderEntity, OrderBusinessEntity>
{
    protected override OrderBusinessEntity EntityToDto(OrderBusinessEntity business, OrderEntity domain)
    {
        business.Id = domain.id;
        business.OrderNumber = domain.order_number;
        business.TotalAmount = domain.total_amount;
        // ... remaining properties
        return business;
    }

    protected override OrderEntity DtoToEntity(OrderEntity domain, OrderBusinessEntity business)
    {
        domain.id = business.Id;
        domain.order_number = business.OrderNumber;
        domain.total_amount = business.TotalAmount;
        // ... remaining properties
        return domain;
    }
}

// Override only one direction, keep auto-map for the other
public class ShipmentBusinessEntityToResponseTranslator : BaseTranslator<ShipmentBusinessEntity, ShipmentResponse>
{
    protected override ShipmentResponse EntityToDto(ShipmentResponse dto, ShipmentBusinessEntity entity)
    {
        var result = base.EntityToDto(dto, entity); // auto-map matching properties first
        result.DisplayName = $"{entity.ShipmentNumber} � {entity.CarrierCode}"; // custom field
        return result;
    }
}
```

### `AutoTranslator<TSource, TTarget>` � Fully Automatic (Runtime)

Registered at runtime for pairs that need zero-config bidirectional mapping without a class file.

```csharp
translator.RegisterAutoTranslator<ProductEntity, ProductDto>();
```

---

## Translator Naming Convention

Translator classes are named `{Source}To{Target}Translator`, making the mapping direction immediately clear:

| Layer | Example |
|-------|---------|
| Facade (Entity ? Business) | `OrderEntityToBusinessEntityTranslator` |
| Adapter (Request ? Business) | `CreateOrderRequestToBusinessEntityTranslator` |
| Adapter (Business ? Response) | `OrderBusinessEntityToResponseTranslator` |

---

## API Reference

### `ITranslatorService`

| Method | Description |
|--------|-------------|
| `Translate<TType>(source)` | Translate using a registered translator |
| `Translate<TType>(target, source)` | Translate into an existing target instance |
| `TranslateDefault<TType>(source, ignoreCase)` | JSON round-trip fallback (no translator needed) |
| `TranslateRange<TType>(source)` | Translate a collection |
| `Map<TSource, TTarget>(source)` | Auto-map with compiled property mapper |
| `Map<TSource, TTarget>(source, target)` | Auto-map into existing target |
| `MapRange<TSource, TTarget>(source)` | Auto-map a collection |
| `CanTranslate<TTarget, TSource>()` | Check if a translator is registered |
| `RegisterTranslator(translator)` | Register a translator manually |
| `RegisterAutoTranslator<TSource, TTarget>()` | Register a runtime auto-translator |

### Extension Methods (`TranslatorServiceExtensions`)

Fluent extension methods on any object:

```csharp
using IGC.Fulfillment.Shared.Translator.Extensions;

var response = businessEntity.MapTo<OrderBusinessEntity, OrderResponse>(translator);
var entities = businessEntities.MapToRange<OrderBusinessEntity, OrderResponse>(translator);
```

---

## How Translation Resolution Works

When `Translate()` or `Map()` is called, the service resolves in this order:

1. **Registered translators** � scans `_translators` list for a matching `IBaseTranslator`
2. **Auto-mapper cache** � falls back to `CompiledPropertyMapper` (expression tree, cached per type pair)

```
Translate<OrderBusinessEntity>(domainEntity)
  ?
  ?? 1. Found OrderEntityToBusinessEntityTranslator? ? use it
  ?
  ?? 2. No translator? ? CompiledPropertyMapper (match by name, case-insensitive)
```

---

## Compiled Property Mapper

The `CompiledPropertyMapper<TSource, TTarget>` is the performance engine:

- **Expression tree compilation** � generates IL at runtime for direct property assignment
- **Cached per type pair** � `ConcurrentDictionary<(Type, Type), mapper>` ensures one-time compilation
- **Case-insensitive matching** � source `OrderNumber` matches target `orderNumber`
- **Nullable handling** � `int` ? `int?`, `DateTime` ? `DateTime?` conversions
- **Type compatibility** � assignable types and implicit conversions

Performance is equivalent to hand-written property assignments after first invocation.

---

## Auto-Discovery

On construction, `TranslatorService` scans all loaded assemblies for classes implementing `IBaseTranslator`:

- Non-abstract, non-interface, non-open-generic classes
- Constructor injection supported (resolves from `IServiceProvider`)
- `ITranslatorService` self-injection supported (circular reference handled)

```
AppDomain.CurrentDomain.GetAssemblies()
  ? FindAll(IBaseTranslator implementations)
  ? Resolve constructor parameters from IServiceProvider
  ? RegisterTranslator(instance)
```

No manual registration needed for translator classes � just create the class and it's automatically picked up.

---

## Project Structure

```
Shared.Translator/
??? Constants/
?   ??? TypeConstants.cs              # Exception message constants
??? Extensions/
?   ??? TranslatorServiceExtensions.cs # Fluent .MapTo<>() extension methods
??? Interfaces/
?   ??? IBaseTranslator.cs            # Base translator contract
?   ??? ITranslatorService.cs         # Service contract (DI entry point)
??? Mappers/
?   ??? IPropertyMapper.cs            # Mapper interface
?   ??? CompiledPropertyMapper.cs     # Expression-tree compiled mapper
??? AutoTranslator.cs                 # Runtime auto-translator
??? BaseTranslator.cs                 # Abstract base with auto-map + optional overrides
??? TranslatorException.cs            # Domain exception
??? TranslatorExtension.cs            # AddTranslatorService() DI registration
??? TranslatorService.cs              # Core service implementation
```

---

## Usage in the Solution Layers

### Facade Layer (Domain Entity ? Business Entity)

```csharp
// BaseFacade provides MapToBusinessEntity / MapToDomainEntity helpers
public class OrderFacade : BaseFacade<OrderBusinessEntity, OrderEntity>, IOrderFacade
{
    public async Task<OrderBusinessEntity?> GetOrderByIdAsync(int id, CancellationToken ct)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = _repository.GetById(id);
            return MapToBusinessEntity(domainEntity);  // Translator.Map<TDomain, TBusiness>()
        }, ct);
    }
}
```

### Adapter Layer (Business Entity ? DTO)

```csharp
// BaseAdapter provides MapToResponse / MapToBusinessEntity helpers
public class OrderAdapter : BaseAdapter<OrderBusinessEntity>, IOrderAdapter
{
    public async Task<OrderResponse?> GetOrderByIdAsync(int id, CancellationToken ct)
    {
        var businessEntity = await _facade.GetOrderByIdAsync(id, ct);
        return MapToResponse<OrderResponse>(businessEntity);  // Translator.Map<TBusiness, TResponse>()
    }
}
```

### Translation Flow

```
Controller ? Adapter ? Facade ? Repository
               ?          ?
    DTO ? BusinessEntity  BusinessEntity ? DomainEntity
    (BaseTranslator)      (BaseTranslator � explicit overrides)
```

---

## Dependencies

| Package | Purpose |
|---------|---------|
| `Microsoft.AspNetCore.Hosting` | `IServiceProvider` for auto-discovery |

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Expression trees over reflection | ~100x faster after first compilation |
| Per-request scoped lifetime | Translators resolved once per HTTP request |
| Auto-discovery via assembly scan | Zero-config for new translator classes |
| Single `BaseTranslator` with virtual overrides | Auto-maps by default; only override what differs |
| `{Source}To{Target}Translator` naming | Mapping direction is self-documenting |
| `ConcurrentDictionary` cache | Thread-safe mapper caching across requests |
