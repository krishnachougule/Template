using System;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using IGC.Fulfillment.Shared.Translator.Mappers;

namespace IGC.Fulfillment.Shared.Translator
{
    public class AutoTranslator<TSource, TTarget> : IBaseTranslator
        where TSource : class, new()
        where TTarget : class, new()
    {
        // PublicationOnly � factory is idempotent, no lock needed during execution
        private readonly Lazy<IPropertyMapper<TSource, TTarget>> _sourceToTargetMapper =
            new(() => CompiledPropertyMapper<TSource, TTarget>.Create(), LazyThreadSafetyMode.PublicationOnly);

        private readonly Lazy<IPropertyMapper<TTarget, TSource>> _targetToSourceMapper =
            new(() => CompiledPropertyMapper<TTarget, TSource>.Create(), LazyThreadSafetyMode.PublicationOnly);

        public bool CanTranslate(Type targetType, Type sourceType)
        {
            return (targetType == typeof(TSource) && sourceType == typeof(TTarget)) ||
                   (targetType == typeof(TTarget) && sourceType == typeof(TSource));
        }

        public object Translate(Type targetType, object target, object source)
        {
            if (targetType == typeof(TTarget) && source is TSource sourceTyped)
            {
                return target is TTarget targetTyped
                    ? _sourceToTargetMapper.Value.Map(sourceTyped, targetTyped)
                    : _sourceToTargetMapper.Value.Map(sourceTyped);
            }

            if (targetType == typeof(TSource) && source is TTarget targetAsSource)
            {
                return target is TSource targetTyped
                    ? _targetToSourceMapper.Value.Map(targetAsSource, targetTyped)
                    : _targetToSourceMapper.Value.Map(targetAsSource);
            }

            throw new TranslatorException($"Cannot translate from {source?.GetType().Name} to {targetType.Name}");
        }

        public TType Translate<TType>(object target, object source)
            => (TType)Translate(typeof(TType), target, source);
    }
}
