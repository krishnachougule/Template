# Shared.DataProxy - Multi-Database Support

The `Shared.DataProxy` library now supports both **SQL Server** and **MySQL** database connections with easy configuration.

## Supported Database Providers

- **SQL Server** (Microsoft SQL Server)
- **MySQL** (including MariaDB)

## Quick Start

### 1. Configure Database Provider in `appsettings.json`

The easiest way to configure your database is through the `appsettings.json` file:

```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=mydb;User=myuser;Password=mypassword;"
  }
}
```

**Supported Provider Names** (case-insensitive):
- SQL Server: `"sqlserver"`, `"sql"`, `"mssql"`, `"microsoft"`
- MySQL: `"mysql"`, `"mariadb"`

### 2. Register in `Program.cs`

The default registration automatically reads from configuration:

```csharp
// Reads "DatabaseProvider" and "DefaultConnection" from configuration
builder.Services.AddDataServices(builder.Configuration);
```

## Configuration Options

### Option 1: Auto-Configuration (Recommended)

```csharp
// Reads DatabaseProvider from appsettings.json
builder.Services.AddDataServices(builder.Configuration);
```

**appsettings.json:**
```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=mydb;User=user;Password=pass;"
  }
}
```

### Option 2: Explicit Provider Type

```csharp
using IGC.Fulfillment.Shared.DataProxy.Enums;

builder.Services.AddDataServices(
    builder.Configuration, 
    DatabaseProvider.MySql
);
```

### Option 3: Direct Connection String

```csharp
builder.Services.AddDataServices(
    providerName: "mysql",
    connectionString: "Server=localhost;Database=mydb;User=user;Password=pass;"
);
```

## Connection String Examples

### SQL Server

```json
{
  "DatabaseProvider": "sqlserver",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=MyDatabase;User Id=sa;Password=YourPassword;TrustServerCertificate=True;"
  }
}
```

Or with Windows Authentication:
```json
{
  "DatabaseProvider": "sqlserver",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=MyDatabase;Integrated Security=True;TrustServerCertificate=True;"
  }
}
```

### MySQL

```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Port=3306;Database=MyDatabase;User=root;Password=YourPassword;"
  }
}
```

Or with SSL:
```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Port=3306;Database=MyDatabase;User=root;Password=YourPassword;SslMode=Required;"
  }
}
```

## Usage in Repositories

Your repositories don't need to change! They work transparently with either database:

```csharp
public class ProductRepository : IProductRepository
{
    private readonly IDataService _dataService;

    public ProductRepository(IDataService dataService)
    {
        _dataService = dataService;
    }

    public async Task<Product> GetByIdAsync(int id)
    {
        var sql = "SELECT * FROM Products WHERE Id = @Id";
        return await _dataService.Connection.QueryFirstOrDefaultAsync<Product>(
            sql, 
            new { Id = id },
            _dataService.Transaction
        );
    }
}
```

## Advanced: Using DatabaseOptions

For strongly-typed configuration:

```csharp
using IGC.Fulfillment.Shared.DataProxy.Configuration;

// In Program.cs
var dbOptions = builder.Configuration.GetSection(DatabaseOptions.SectionName)
    .Get<DatabaseOptions>();

builder.Services.AddDataServices(
    dbOptions.Provider,
    dbOptions.ConnectionString
);
```

**appsettings.json:**
```json
{
  "Database": {
    "Provider": "mysql",
    "ConnectionString": "Server=localhost;Database=mydb;User=user;Password=pass;"
  }
}
```

## Switching Between Databases

To switch from SQL Server to MySQL (or vice versa):

1. Update `appsettings.json`:
   ```json
   "DatabaseProvider": "mysql"  // Change from "sqlserver" to "mysql"
   ```

2. Update connection string to match the new provider's format

3. No code changes required! ?

## Environment-Specific Configuration

Use different databases per environment:

**appsettings.Development.json:**
```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=DevDB;User=dev;Password=dev;"
  }
}
```

**appsettings.Production.json:**
```json
{
  "DatabaseProvider": "sqlserver",
  "ConnectionStrings": {
    "DefaultConnection": "Server=prod-server;Database=ProdDB;Integrated Security=True;"
  }
}
```

## API Reference

### DatabaseProvider Enum

```csharp
namespace IGC.Fulfillment.Shared.DataProxy.Enums;

public enum DatabaseProvider
{
    SqlServer,
    MySql
}
```

### DbConnectionFactory

```csharp
namespace IGC.Fulfillment.Shared.DataProxy.Factories;

public static class DbConnectionFactory
{
    // Create connection with enum
    public static IDbConnection CreateConnection(
        DatabaseProvider provider, 
        string connectionString);

    // Create connection with provider name string
    public static IDbConnection CreateConnection(
        string providerName, 
        string connectionString);

    // Parse provider name to enum
    public static DatabaseProvider ParseProvider(string providerName);
}
```

### DataService Constructors

```csharp
// Using DatabaseProvider enum
public DataService(DatabaseProvider provider, string connectionString);

// Using provider name string
public DataService(string providerName, string connectionString);
```

## Migration Notes

### From Old Single-Database Setup

If you were previously using the old DataService with only SQL Server support:

**Old Code:**
```csharp
services.AddScoped<IDataService>(sp => new DataService(connectionString));
```

**New Code (Backward Compatible):**
```csharp
// Option 1: Let it read from config (defaults to SqlServer if not specified)
builder.Services.AddDataServices(builder.Configuration);

// Option 2: Explicit SqlServer
builder.Services.AddDataServices(builder.Configuration, DatabaseProvider.SqlServer);
```

Add to `appsettings.json`:
```json
{
  "DatabaseProvider": "sqlserver"  // Add this line
}
```

## Troubleshooting

### "Database provider 'xyz' is not recognized"

Make sure you're using one of the supported provider names:
- SQL Server: `sqlserver`, `sql`, `mssql`, `microsoft`
- MySQL: `mysql`, `mariadb`

### Connection Fails

1. Verify connection string format matches your database provider
2. Ensure the database server is accessible
3. Check firewall rules and network connectivity
4. Verify credentials are correct

### NuGet Packages

The following packages are automatically included:
- `Microsoft.Data.SqlClient` - for SQL Server support
- `MySql.Data` - for MySQL support
- `Dapper` - for data access

## Example: Complete Setup

**appsettings.json:**
```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost:3306;Database=productdb;User=appuser;Password=MySecurePassword123;"
  }
}
```

**Program.cs:**
```csharp
using ICG.Fulfillment.Service.TemplateService.Data;

var builder = WebApplication.CreateBuilder(args);

// Register Data Services - automatically uses MySQL from config
builder.Services.AddDataServices(builder.Configuration);

// ... rest of your setup
```

**Repository:**
```csharp
public class ProductRepository : IProductRepository
{
    private readonly IDataService _dataService;

    public ProductRepository(IDataService dataService)
    {
        _dataService = dataService;
    }

    public async Task<Product> CreateAsync(Product product)
    {
        _dataService.BeginTransaction();
        try
        {
            var sql = @"INSERT INTO Products (Name, Price) 
                       VALUES (@Name, @Price);
                       SELECT LAST_INSERT_ID();";
            
            var id = await _dataService.Connection.ExecuteScalarAsync<int>(
                sql, 
                product,
                _dataService.Transaction
            );
            
            _dataService.Commit();
            return product with { Id = id };
        }
        catch
        {
            _dataService.Rollback();
            throw;
        }
    }
}
```

## Summary

? **Easy to use** - Just set `DatabaseProvider` in appsettings.json  
? **Flexible** - Multiple configuration options  
? **No code changes** - Switch databases by changing config  
? **Type-safe** - Strong typing with `DatabaseProvider` enum  
? **Environment-aware** - Different databases per environment  

Need help? Check the code examples above or contact the development team.
