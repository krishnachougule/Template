﻿using System;
using System.Data;

namespace IGC.Fulfillment.Shared.DataProxy.Interfaces
{
    public interface IDataService : IDisposable
    {
        IDbTransaction? Transaction { get; }
        IDbConnection? Connection { get; }

        void BeginTransaction();
        void Commit();
        void Rollback();
    }
}
