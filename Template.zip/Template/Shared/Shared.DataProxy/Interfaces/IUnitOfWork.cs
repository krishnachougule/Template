﻿using System;

namespace IGC.Fulfillment.Shared.DataProxy.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
    }
}
