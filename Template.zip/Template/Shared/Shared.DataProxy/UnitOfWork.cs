﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace IGC.Fulfillment.Shared.DataProxy
{
    public abstract class UnitOfWork : IUnitOfWork
    {
        private bool _disposed;

        protected IDbTransaction Transaction { get; private set; }
        protected IDbConnection Connection { get; private set; }

        public UnitOfWork(string connectionString)
        {
            Connection = new SqlConnection(connectionString);
            Connection.Open();
            Transaction = Connection.BeginTransaction();
        }

        public void Commit()
        {
            try
            {
                Transaction.Commit();
            }
            catch
            {
                Transaction.Rollback();
                throw;
            }
            finally
            {
                Transaction.Dispose();
                Transaction = Connection.BeginTransaction();
                ResetRepositories();
            }
        }

        protected virtual void ResetRepositories()
        {
        }

        public void Dispose()
        {
            InternalDispose(true);
            GC.SuppressFinalize(this);
        }

        private void InternalDispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (Transaction != null)
                    {
                        Transaction.Dispose();
                        Transaction = null;
                    }
                    if (Connection != null)
                    {
                        Connection.Dispose();
                        Connection = null;
                    }
                }
                _disposed = true;
            }
        }

        ~UnitOfWork()
        {
            InternalDispose(false);
        }
    }
}
