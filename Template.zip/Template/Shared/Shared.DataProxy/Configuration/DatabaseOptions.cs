using IGC.Fulfillment.Shared.DataProxy.Enums;

namespace IGC.Fulfillment.Shared.DataProxy.Configuration;

/// <summary>
/// Configuration options for database connection
/// </summary>
public class DatabaseOptions
{
    /// <summary>
    /// Configuration section name
    /// </summary>
    public const string SectionName = "Database";

    /// <summary>
    /// Database provider type (SqlServer, MySql)
    /// </summary>
    public string Provider { get; set; } = "SqlServer";

    /// <summary>
    /// Connection string
    /// </summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>
    /// Gets the parsed database provider enum
    /// </summary>
    public DatabaseProvider GetProvider()
    {
        return Factories.DbConnectionFactory.ParseProvider(Provider);
    }
}
