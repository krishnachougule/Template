﻿using Dapper;
using System.Collections.Generic;
using System.Data;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace IGC.Fulfillment.Shared.DataProxy
{
    public abstract class Repository
    {
        private readonly IDataService _dataService;

        protected IDbConnection Connection => _dataService.Connection ?? throw new InvalidOperationException("Connection is not available.");
        protected IDbTransaction? Transaction => _dataService.Transaction;

        protected Repository(IDataService dataService)
        {
            _dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
        }

        protected void Execute(string sql, object? param = null)
        {
            Connection.Execute(
                sql,
                param: param,
                transaction: Transaction,
                commandType: CommandType.StoredProcedure
            );
        }

        protected T ExecuteScalar<T>(string sql, object? param = null)
        {
            return Connection.ExecuteScalar<T>(
                sql,
                param: param,
                transaction: Transaction,
                commandType: CommandType.StoredProcedure
            );
        }

        protected IEnumerable<T> Query<T>(string sql, object? param = null)
        {
            return Connection.Query<T>(
                sql,
                param: param,
                transaction: Transaction,
                commandType: CommandType.StoredProcedure
            );
        }

        protected T? QueryFirstOrDefault<T>(string sql, object? param = null)
        {
            return Connection.QueryFirstOrDefault<T>(
                sql,
                param: param,
                transaction: Transaction,
                commandType: CommandType.StoredProcedure
            );
        }

        protected T QueryFirst<T>(string sql, object? param = null)
        {
            return Connection.QueryFirst<T>(
                sql,
                param: param,
                transaction: Transaction,
                commandType: CommandType.StoredProcedure
            );
        }
    }
}
