using System.Data;
using Microsoft.Data.SqlClient;
using MySql.Data.MySqlClient;
using IGC.Fulfillment.Shared.DataProxy.Enums;

namespace IGC.Fulfillment.Shared.DataProxy.Factories;

/// <summary>
/// Factory for creating database connections based on the provider type
/// </summary>
public static class DbConnectionFactory
{
    /// <summary>
    /// Creates a database connection based on the specified provider
    /// </summary>
    /// <param name="provider">The database provider type</param>
    /// <param name="connectionString">The connection string</param>
    /// <returns>An opened IDbConnection</returns>
    /// <exception cref="ArgumentException">Thrown when connection string is null or empty</exception>
    /// <exception cref="NotSupportedException">Thrown when database provider is not supported</exception>
    public static IDbConnection CreateConnection(DatabaseProvider provider, string connectionString)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(connectionString, nameof(connectionString));

        IDbConnection connection = provider switch
        {
            DatabaseProvider.SqlServer => new SqlConnection(connectionString),
            DatabaseProvider.MySql => new MySqlConnection(connectionString),
            _ => throw new NotSupportedException($"Database provider '{provider}' is not supported.")
        };

        connection.Open();
        return connection;
    }

    /// <summary>
    /// Creates a database connection from a provider name string (case-insensitive)
    /// </summary>
    /// <param name="providerName">Provider name (e.g., "SqlServer", "MySQL", "sql", "mysql")</param>
    /// <param name="connectionString">The connection string</param>
    /// <returns>An opened IDbConnection</returns>
    public static IDbConnection CreateConnection(string providerName, string connectionString)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(providerName, nameof(providerName));
        
        var provider = ParseProvider(providerName);
        return CreateConnection(provider, connectionString);
    }

    /// <summary>
    /// Parses a provider name string to DatabaseProvider enum
    /// </summary>
    public static DatabaseProvider ParseProvider(string providerName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(providerName, nameof(providerName));

        return providerName.ToLowerInvariant() switch
        {
            "sqlserver" or "sql" or "mssql" or "microsoft" => DatabaseProvider.SqlServer,
            "mysql" or "mariadb" => DatabaseProvider.MySql,
            _ => throw new NotSupportedException($"Database provider name '{providerName}' is not recognized. Supported values: SqlServer, MySql")
        };
    }
}
