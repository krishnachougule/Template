﻿using System;
using System.Data;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;
using IGC.Fulfillment.Shared.DataProxy.Enums;
using IGC.Fulfillment.Shared.DataProxy.Factories;

namespace IGC.Fulfillment.Shared.DataProxy
{
    public sealed class DataService : IDataService
    {
        private bool _disposed;
        private IDbTransaction? _transaction;
        private readonly IDbConnection _connection;

        public IDbTransaction? Transaction => _transaction;
        public IDbConnection Connection => _connection;

        /// <summary>
        /// Creates a DataService with the specified database provider and connection string
        /// </summary>
        /// <param name="provider">The database provider type</param>
        /// <param name="connectionString">The connection string</param>
        public DataService(DatabaseProvider provider, string connectionString)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(connectionString);
            _connection = DbConnectionFactory.CreateConnection(provider, connectionString);
        }

        /// <summary>
        /// Creates a DataService with the specified provider name and connection string
        /// </summary>
        /// <param name="providerName">Provider name (e.g., "SqlServer", "MySql")</param>
        /// <param name="connectionString">The connection string</param>
        public DataService(string providerName, string connectionString)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(connectionString);
            ArgumentException.ThrowIfNullOrWhiteSpace(providerName);
            _connection = DbConnectionFactory.CreateConnection(providerName, connectionString);
        }

        public void BeginTransaction()
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            
            if (_transaction != null)
            {
                throw new InvalidOperationException("Transaction already in progress.");
            }

            _transaction = _connection.BeginTransaction();
        }

        public void Commit()
        {
            ObjectDisposedException.ThrowIf(_disposed, this);

            if (_transaction == null)
            {
                throw new InvalidOperationException("No active transaction to commit.");
            }

            try
            {
                _transaction.Commit();
            }
            catch
            {
                _transaction.Rollback();
                throw;
            }
            finally
            {
                _transaction.Dispose();
                _transaction = null;
            }
        }

        public void Rollback()
        {
            ObjectDisposedException.ThrowIf(_disposed, this);

            if (_transaction == null)
            {
                throw new InvalidOperationException("No active transaction to rollback.");
            }

            try
            {
                _transaction.Rollback();
            }
            finally
            {
                _transaction.Dispose();
                _transaction = null;
            }
        }

        public void Dispose()
        {
            if (_disposed) return;

            _transaction?.Dispose();
            _connection?.Dispose();

            _disposed = true;
        }
    }
}
