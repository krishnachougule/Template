namespace IGC.Fulfillment.Shared.DataProxy.Enums;

/// <summary>
/// Supported database providers
/// </summary>
public enum DatabaseProvider
{
    SqlServer,
    MySql
}
