# Quick Reference: Multi-Database Support

## ? Quick Setup

### 1. Add to `appsettings.json`:
```json
{
  "DatabaseProvider": "mysql",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=mydb;User=user;Password=pass;"
  }
}
```

### 2. Register in `Program.cs`:
```csharp
builder.Services.AddDataServices(builder.Configuration);
```

### 3. Use in Repository:
```csharp
public class MyRepository
{
    private readonly IDataService _dataService;
    
    public MyRepository(IDataService dataService)
    {
        _dataService = dataService;
    }
    
    // Works with both SQL Server and MySQL!
    public async Task<T> GetByIdAsync(int id)
    {
        var sql = "SELECT * FROM MyTable WHERE Id = @Id";
        return await _dataService.Connection.QueryFirstOrDefaultAsync<T>(
            sql, new { Id = id }, _dataService.Transaction);
    }
}
```

## ?? Supported Providers

| Database | Provider Names (case-insensitive) |
|----------|-----------------------------------|
| SQL Server | `sqlserver`, `sql`, `mssql`, `microsoft` |
| MySQL | `mysql`, `mariadb` |

## ?? Connection String Examples

### SQL Server
```json
"Server=localhost;Database=MyDB;User Id=sa;Password=Pass123;TrustServerCertificate=True;"
```

### MySQL
```json
"Server=localhost;Port=3306;Database=MyDB;User=root;Password=Pass123;"
```

## ?? Switching Databases

Just change `DatabaseProvider` in appsettings.json:
```json
"DatabaseProvider": "sqlserver"  // or "mysql"
```

No code changes needed! ?

## ?? See Full Documentation

For advanced scenarios, see [README.md](./README.md)
