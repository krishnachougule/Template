using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace IGC.Fulfillment.Shared.ServiceProxy;

/// <summary>
/// DI registration for typed service proxies.
/// </summary>
public static class ServiceProxyExtensions
{
    /// <summary>
    /// Registers a typed HttpClient for the given proxy, bound from the named
    /// configuration section "ServiceProxies:{configSection}".
    /// </summary>
    public static IHttpClientBuilder AddServiceProxy<TProxy>(
        this IServiceCollection services,
        IConfiguration configuration,
        string configSection)
        where TProxy : BaseServiceProxy
    {
        var options = configuration
            .GetSection($"ServiceProxies:{configSection}")
            .Get<ServiceProxyOptions>() ?? new ServiceProxyOptions();

        return services.AddHttpClient<TProxy>(client =>
        {
            if (!string.IsNullOrWhiteSpace(options.BaseUrl))
                client.BaseAddress = new Uri(options.BaseUrl);

            client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
        });
    }
}
