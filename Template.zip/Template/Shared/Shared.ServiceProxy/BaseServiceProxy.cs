using System.Net;
using System.Net.Http.Json;

namespace IGC.Fulfillment.Shared.ServiceProxy;

/// <summary>
/// Base class for all external service proxies.
/// Mirrors the role of Repository (Shared.DataProxy) but over HTTP.
/// Inject a typed HttpClient via DI � wire up with AddServiceProxy&lt;T&gt;().
/// </summary>
public abstract class BaseServiceProxy
{
    protected readonly HttpClient HttpClient;

    protected BaseServiceProxy(HttpClient httpClient)
    {
        HttpClient = httpClient;
    }

    protected async Task<T?> GetAsync<T>(string path, CancellationToken ct = default)
    {
        var response = await HttpClient.GetAsync(path, ct);
        if (response.StatusCode == HttpStatusCode.NotFound)
            return default;
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct);
    }

    protected async Task<IEnumerable<T>> GetManyAsync<T>(string path, CancellationToken ct = default)
    {
        var response = await HttpClient.GetAsync(path, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<IEnumerable<T>>(cancellationToken: ct)
               ?? Enumerable.Empty<T>();
    }

    protected async Task<T> PostAsync<TRequest, T>(string path, TRequest body, CancellationToken ct = default)
    {
        var response = await HttpClient.PostAsJsonAsync(path, body, ct);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct))!;
    }

    protected async Task<T> PutAsync<TRequest, T>(string path, TRequest body, CancellationToken ct = default)
    {
        var response = await HttpClient.PutAsJsonAsync(path, body, ct);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct))!;
    }

    protected async Task DeleteAsync(string path, CancellationToken ct = default)
    {
        var response = await HttpClient.DeleteAsync(path, ct);
        response.EnsureSuccessStatusCode();
    }
}
