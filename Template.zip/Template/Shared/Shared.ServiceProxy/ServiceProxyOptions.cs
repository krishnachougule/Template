namespace IGC.Fulfillment.Shared.ServiceProxy;

/// <summary>
/// Configuration for an external service proxy � BaseUrl, timeout, retry.
/// Bind from appsettings: "ServiceProxies:{Name}".
/// </summary>
public class ServiceProxyOptions
{
    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 30;
    public int RetryCount { get; set; } = 3;
    public int RetryDelayMs { get; set; } = 500;
}
