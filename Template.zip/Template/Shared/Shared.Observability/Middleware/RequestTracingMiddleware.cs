using System.Diagnostics;
using IGC.Fulfillment.Shared.Observability.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;

namespace IGC.Fulfillment.Shared.Observability.Middleware;

/// <summary>
/// Middleware that creates a tracing span for each HTTP request and emits request-level metrics.
/// Exception recording is delegated to GlobalExceptionMiddleware to avoid double-counting.
/// </summary>
public sealed class RequestTracingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestTracingMiddleware> _logger;

    // Compile-time source-generated delegates � zero allocation when level is disabled
    private static readonly Action<ILogger, string, string, int, double, Exception?> _logRequest =
        LoggerMessage.Define<string, string, int, double>(
            LogLevel.Information,
            new EventId(1, "HttpRequest"),
            "HTTP {Method} {Path} responded {StatusCode} in {ElapsedMs:F1}ms");

    public RequestTracingMiddleware(RequestDelegate next, ILogger<RequestTracingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var method = context.Request.Method;
        var path = context.Request.Path.Value ?? "/";

        using var activity = ObservabilityDefaults.ActivitySource.HasListeners()
            ? ObservabilityDefaults.ActivitySource.StartActivity($"HTTP {method} {path}", ActivityKind.Server)
            : null;

        var correlationId = context.Items["CorrelationId"]?.ToString()
                            ?? context.Request.Headers["X-Correlation-ID"].FirstOrDefault();

        if (correlationId is not null)
            activity?.SetTag("correlation.id", correlationId);

        activity?.SetTag("http.method", method);
        activity?.SetTag("http.url", path);
        activity?.SetTag("http.host", context.Request.Host.ToString());

        var startTimestamp = Stopwatch.GetTimestamp();

        try
        {
            await _next(context);
        }
        finally
        {
            // Always runs � captures the final status code whether the request succeeded,
            // was handled by GlobalExceptionMiddleware (4xx/5xx), or was cancelled.
            var elapsedMs = (Stopwatch.GetTimestamp() - startTimestamp) * 1000d / Stopwatch.Frequency;
            var statusCode = context.Response.StatusCode;

            activity?.SetTag("http.status_code", statusCode);

            if (statusCode >= 500)
                activity?.SetStatus(ActivityStatusCode.Error, $"HTTP {statusCode}");

            if (ObservabilityDefaults.RequestCounter.Enabled)
            {
                ObservabilityDefaults.RequestCounter.Add(1,
                    new KeyValuePair<string, object?>("http.method", method),
                    new KeyValuePair<string, object?>("http.status_code", statusCode),
                    new KeyValuePair<string, object?>("http.route", path));
            }

            if (ObservabilityDefaults.RequestDuration.Enabled)
            {
                ObservabilityDefaults.RequestDuration.Record(elapsedMs,
                    new KeyValuePair<string, object?>("http.method", method),
                    new KeyValuePair<string, object?>("http.route", path));
            }

            _logRequest(_logger, method, path, statusCode, elapsedMs, null);
        }
    }
}
