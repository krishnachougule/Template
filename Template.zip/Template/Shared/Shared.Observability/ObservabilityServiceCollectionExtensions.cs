﻿using IGC.Fulfillment.Shared.Observability.Configuration;
using IGC.Fulfillment.Shared.Observability.Diagnostics;
using IGC.Fulfillment.Shared.Observability.Exporters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OpenTelemetry;
using OpenTelemetry.Exporter;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace IGC.Fulfillment.Shared.Observability;

/// <summary>
/// Single entry point — AddObservability() — wires up OpenTelemetry
/// for Logs, Traces, and Metrics based on the "Observability" configuration section.
/// AddOpenTelemetry() is called exactly once; tracing and metrics are chained on
/// the same builder to avoid duplicate provider registrations.
/// </summary>
public static class ObservabilityServiceCollectionExtensions
{
    public static IServiceCollection AddObservability(
        this IServiceCollection services,
        IConfiguration configuration,
        string? environmentName = null)
    {
        var options = new ObservabilityOptions();
        configuration.GetSection(ObservabilityOptions.SectionName).Bind(options);

        if (!string.IsNullOrEmpty(environmentName) && string.IsNullOrEmpty(options.Environment))
            options.Environment = environmentName;

        services.Configure<ObservabilityOptions>(configuration.GetSection(ObservabilityOptions.SectionName));

        // Build the resource once and share the immutable result — ResourceBuilder
        // is not safe to mutate concurrently across multiple provider configurations.
        var resourceBuilder = ResourceBuilder.CreateDefault()
            .AddService(
                serviceName: options.ServiceName,
                serviceVersion: options.ServiceVersion)
            .AddAttributes(new Dictionary<string, object>
            {
                ["deployment.environment"] = options.Environment ?? "Unknown",
                ["service.namespace"] = "IGC.Fulfillment"
            });

        // ── Logging ───────────────────────────────────────────────────────────
        if (options.Logging.Enabled)
        {
            services.AddLogging(logging =>
            {
                logging.ClearProviders();
                logging.AddOpenTelemetry(otelLogging =>
                {
                    otelLogging.SetResourceBuilder(resourceBuilder);
                    otelLogging.IncludeFormattedMessage = options.Logging.IncludeFormattedMessage;
                    otelLogging.IncludeScopes = options.Logging.IncludeScopes;
                    ConfigureLogExporter(otelLogging, options.Logging.Destination, services);
                });

                // Only add console fallback when the destination is not already an
                // external backend — avoids doubling every log line to stdout in production.
                if (options.Logging.Destination.Type is ExporterType.Otlp
                    or ExporterType.Datadog
                    or ExporterType.Splunk)
                {
                    logging.AddConsole();
                }
            });
        }

        // ── Tracing + Metrics — single OpenTelemetryBuilder ───────────────────
        // AddOpenTelemetry() must be called exactly once. Both signals are chained
        // on the same builder; each is only configured when its Enabled flag is true.
        if (options.Tracing.Enabled || options.Metrics.Enabled)
        {
            var otelBuilder = services.AddOpenTelemetry();

            if (options.Tracing.Enabled)
            {
                otelBuilder.WithTracing(tracing =>
                {
                    tracing.SetResourceBuilder(resourceBuilder);
                    tracing.AddSource(ObservabilityDefaults.ActivitySourceName);

                    foreach (var source in options.Tracing.AdditionalSources)
                        tracing.AddSource(source);

                    if (options.Tracing.InstrumentAspNetCore)
                        tracing.AddAspNetCoreInstrumentation(a => a.RecordException = true);

                    if (options.Tracing.InstrumentHttpClient)
                        tracing.AddHttpClientInstrumentation(h => h.RecordException = true);

                    if (options.Tracing.InstrumentSqlClient)
                        tracing.AddSqlClientInstrumentation(sql =>
                        {
                            sql.SetDbStatementForText = options.Tracing.RecordSqlCommandText;
                            sql.RecordException = true;
                        });

                    if (options.Tracing.SamplingRatio < 1.0)
                        tracing.SetSampler(new TraceIdRatioBasedSampler(options.Tracing.SamplingRatio));

                    ConfigureTraceExporter(tracing, options.Tracing.Destination);
                });
            }

            if (options.Metrics.Enabled)
            {
                otelBuilder.WithMetrics(metrics =>
                {
                    metrics.SetResourceBuilder(resourceBuilder);
                    metrics.AddMeter(ObservabilityDefaults.MeterName);

                    foreach (var meter in options.Metrics.AdditionalMeters)
                        metrics.AddMeter(meter);

                    if (options.Metrics.InstrumentAspNetCore)
                        metrics.AddAspNetCoreInstrumentation();

                    if (options.Metrics.InstrumentHttpClient)
                        metrics.AddHttpClientInstrumentation();

                    if (options.Metrics.InstrumentRuntime)
                        metrics.AddRuntimeInstrumentation();

                    if (options.Metrics.InstrumentProcess)
                        metrics.AddProcessInstrumentation();

                    ConfigureMetricExporter(metrics, options.Metrics);
                });
            }
        }

        return services;
    }

    private static void ConfigureLogExporter(
        OpenTelemetryLoggerOptions logging,
        ExportDestination destination,
        IServiceCollection services)
    {
        switch (destination.Type)
        {
            case ExporterType.Console:
                logging.AddConsoleExporter();
                break;

            case ExporterType.File:
                // Resolve path via IHostEnvironment at runtime, not at registration time,
                // so ContentRootPath is stable (avoids CWD-relative path issues in containers).
                logging.AddProcessor(sp =>
                {
                    var env = sp.GetRequiredService<IHostEnvironment>();
                    var filePath = string.IsNullOrWhiteSpace(destination.FilePath)
                        ? Path.Combine(env.ContentRootPath, "logs", "app.log")
                        : Path.IsPathRooted(destination.FilePath)
                            ? destination.FilePath
                            : Path.Combine(env.ContentRootPath, destination.FilePath);

                    return new SimpleLogRecordExportProcessor(
                        new FileLogExporter(filePath, destination.MaxFileSizeMb));
                });
                break;

            case ExporterType.Otlp:
            case ExporterType.Datadog:
            case ExporterType.Splunk:
                logging.AddOtlpExporter(otlp => ConfigureOtlpExporter(otlp, destination));
                break;
        }
    }

    private static void ConfigureTraceExporter(TracerProviderBuilder tracing, ExportDestination destination)
    {
        switch (destination.Type)
        {
            case ExporterType.Console:
            case ExporterType.File:
                tracing.AddConsoleExporter();
                break;
            case ExporterType.Otlp:
            case ExporterType.Datadog:
            case ExporterType.Splunk:
                tracing.AddOtlpExporter(otlp => ConfigureOtlpExporter(otlp, destination));
                break;
        }
    }

    private static void ConfigureMetricExporter(MeterProviderBuilder metrics, MetricsOptions metricsOptions)
    {
        var destination = metricsOptions.Destination;
        switch (destination.Type)
        {
            case ExporterType.Console:
            case ExporterType.File:
                metrics.AddConsoleExporter((_, reader) =>
                    reader.PeriodicExportingMetricReaderOptions.ExportIntervalMilliseconds = metricsOptions.ExportIntervalMs);
                break;
            case ExporterType.Otlp:
            case ExporterType.Datadog:
            case ExporterType.Splunk:
                metrics.AddOtlpExporter((otlp, reader) =>
                {
                    ConfigureOtlpExporter(otlp, destination);
                    reader.PeriodicExportingMetricReaderOptions.ExportIntervalMilliseconds = metricsOptions.ExportIntervalMs;
                });
                break;
        }
    }

    private static void ConfigureOtlpExporter(OtlpExporterOptions otlp, ExportDestination destination)
    {
        var endpoint = destination.Endpoint ?? "http://localhost:4317";
        otlp.Endpoint = new Uri(endpoint);
        otlp.Protocol = destination.Protocol.ToLowerInvariant() switch
        {
            "httpprotobuf" or "http" => OtlpExportProtocol.HttpProtobuf,
            _ => OtlpExportProtocol.Grpc
        };
        if (!string.IsNullOrEmpty(destination.Headers))
            otlp.Headers = destination.Headers;
    }
}
