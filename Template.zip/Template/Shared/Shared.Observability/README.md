# Shared.Observability � OpenTelemetry for IGC.Fulfillment

Provides a single `AddObservability()` call that configures **Logs**, **Traces**, and **Metrics** via OpenTelemetry, fully driven by `appsettings.json`.

---

## Quick Start

### 1. Register in `Program.cs`

```csharp
builder.Services.AddObservability(builder.Configuration, builder.Environment.EnvironmentName);
```

### 2. Add middleware in pipeline (already done by `UsePlatform()`)

The `UsePlatform()` call in `Shared.Bootstrap` automatically invokes `UseObservability()` which adds the `RequestTracingMiddleware`.

### 3. Configure in `appsettings.json`

```json
{
  "Observability": {
    "ServiceName": "ICG.TemplateService",
    "ServiceVersion": "1.0.0",
    "Logging": {
      "Enabled": true,
      "IncludeFormattedMessage": true,
      "IncludeScopes": true,
      "Destination": {
        "Type": "Console"
      }
    },
    "Tracing": {
      "Enabled": true,
      "InstrumentAspNetCore": true,
      "InstrumentHttpClient": true,
      "InstrumentSqlClient": true,
      "RecordSqlCommandText": false,
      "SamplingRatio": 1.0,
      "Destination": {
        "Type": "Console"
      }
    },
    "Metrics": {
      "Enabled": true,
      "InstrumentAspNetCore": true,
      "InstrumentHttpClient": true,
      "InstrumentRuntime": true,
      "InstrumentProcess": true,
      "ExportIntervalMs": 60000,
      "Destination": {
        "Type": "Console"
      }
    }
  }
}
```

---

## Configuration Reference

### `Observability` Section

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `ServiceName` | `string` | `"UnknownService"` | Logical name attached to all telemetry |
| `ServiceVersion` | `string` | `"1.0.0"` | Service version in resource attributes |
| `Environment` | `string?` | Auto-detected | Deployment environment name |

### `Logging`

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `Enabled` | `bool` | `true` | Master on/off switch for OTel logging |
| `IncludeFormattedMessage` | `bool` | `true` | Include rendered message in log records |
| `IncludeScopes` | `bool` | `true` | Include logging scopes |
| `Destination` | `ExportDestination` | Console | Where logs are sent |

### `Tracing`

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `Enabled` | `bool` | `true` | Master on/off switch for distributed tracing |
| `InstrumentAspNetCore` | `bool` | `true` | Auto-instrument incoming HTTP requests |
| `InstrumentHttpClient` | `bool` | `true` | Auto-instrument outgoing HTTP calls |
| `InstrumentSqlClient` | `bool` | `true` | Auto-instrument SQL database calls |
| `RecordSqlCommandText` | `bool` | `false` | Capture SQL text in spans (?? may contain PII) |
| `AdditionalSources` | `string[]` | `[]` | Extra `ActivitySource` names to listen on |
| `SamplingRatio` | `double` | `1.0` | 0.0�1.0 sampling rate for traces |
| `Destination` | `ExportDestination` | Console | Where traces are sent |

### `Metrics`

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `Enabled` | `bool` | `true` | Master on/off switch for metrics |
| `InstrumentAspNetCore` | `bool` | `true` | HTTP server metrics |
| `InstrumentHttpClient` | `bool` | `true` | HTTP client metrics |
| `InstrumentRuntime` | `bool` | `true` | GC, thread pool, etc. |
| `InstrumentProcess` | `bool` | `true` | CPU, memory |
| `AdditionalMeters` | `string[]` | `[]` | Extra `Meter` names to listen on |
| `ExportIntervalMs` | `int` | `60000` | Periodic metric export interval (ms) |
| `Destination` | `ExportDestination` | Console | Where metrics are sent |

### `ExportDestination`

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `Type` | `ExporterType` | `Console` | `Console`, `File`, `Otlp`, `Datadog`, `Splunk` |
| `Endpoint` | `string?` | `null` | OTLP endpoint (auto-defaults per provider) |
| `Protocol` | `string` | `"grpc"` | `"grpc"` or `"httpprotobuf"` |
| `Headers` | `string?` | `null` | Extra headers: `"key1=value1,key2=value2"` |
| `FilePath` | `string?` | `"logs/app.log"` | File path (File exporter only, logs only) |
| `MaxFileSizeMb` | `int` | `100` | Max file size before rolling (File exporter) |

---

## Destination Examples

### Console (Development)

```json
"Destination": {
  "Type": "Console"
}
```

### Physical File (Logs only)

```json
"Destination": {
  "Type": "File",
  "FilePath": "C:/logs/templateservice/app.log",
  "MaxFileSizeMb": 200
}
```

### Datadog (via Datadog Agent OTLP ingestion)

Requires [Datadog Agent configured for OTLP](https://docs.datadoghq.com/opentelemetry/otlp_ingest_in_the_agent/).

```json
"Destination": {
  "Type": "Datadog",
  "Endpoint": "http://localhost:4317",
  "Protocol": "grpc"
}
```

### Splunk (via Splunk OTel Collector)

Requires [Splunk OpenTelemetry Collector](https://docs.splunk.com/observability/en/gdi/opentelemetry/opentelemetry.html).

```json
"Destination": {
  "Type": "Splunk",
  "Endpoint": "http://localhost:4317",
  "Protocol": "grpc",
  "Headers": "X-SF-TOKEN=your-splunk-access-token"
}
```

### Generic OTLP Backend (Jaeger, Grafana Tempo, Azure Monitor, etc.)

```json
"Destination": {
  "Type": "Otlp",
  "Endpoint": "http://otel-collector.internal:4317",
  "Protocol": "grpc",
  "Headers": "Authorization=Bearer your-api-key"
}
```

### OTLP over HTTP (e.g., behind a reverse proxy)

```json
"Destination": {
  "Type": "Otlp",
  "Endpoint": "https://otel-gateway.example.com:4318",
  "Protocol": "httpprotobuf",
  "Headers": "api-key=your-key"
}
```

---

## Turning Off Individual Pillars

Disable any pillar by setting `Enabled: false`:

```json
{
  "Observability": {
    "ServiceName": "ICG.TemplateService",
    "Logging": { "Enabled": true,  "Destination": { "Type": "File", "FilePath": "logs/app.log" } },
    "Tracing": { "Enabled": false },
    "Metrics": { "Enabled": false }
  }
}
```

---

## Custom Instrumentation

### Custom Trace Spans

```csharp
using IGC.Fulfillment.Shared.Observability.Diagnostics;

public async Task<Order> ProcessOrder(int orderId, CancellationToken ct)
{
    using var activity = ObservabilityDefaults.ActivitySource.StartActivity("ProcessOrder");
    activity?.SetTag("order.id", orderId);

    // ... your logic ...

    return order;
}
```

### Custom Metrics

```csharp
using IGC.Fulfillment.Shared.Observability.Diagnostics;

// Use pre-built instruments
ObservabilityDefaults.FacadeOperationCounter.Add(1,
    new KeyValuePair<string, object?>("facade", "OrderFacade"));

ObservabilityDefaults.FacadeOperationDuration.Record(elapsed,
    new KeyValuePair<string, object?>("facade", "OrderFacade"));

// Or create your own from the shared Meter
var myCounter = ObservabilityDefaults.Meter.CreateCounter<long>("my.custom.counter");
myCounter.Add(1);
```

### Register Additional Sources/Meters

```json
{
  "Observability": {
    "Tracing": {
      "AdditionalSources": ["MyService.CustomSource"]
    },
    "Metrics": {
      "AdditionalMeters": ["MyService.CustomMeter"]
    }
  }
}
```

---

## Architecture

```
???????????????????????????????????????????????????
?                 appsettings.json                ?
?              "Observability" section             ?
???????????????????????????????????????????????????
                       ?
              AddObservability()
                       ?
         ?????????????????????????????
         ?             ?             ?
    ???????????  ????????????? ???????????
    ? Logging ?  ?  Tracing  ? ? Metrics ?
    ? (OTel)  ?  ?  (OTel)   ? ? (OTel)  ?
    ???????????  ????????????? ???????????
         ?             ?             ?
         ?????????????????????????????
                ?             ?
         ??????????????? ????????????????
         ?   Console   ? ?   OTLP       ?
         ?   File      ? ? (Datadog,    ?
         ?             ? ?  Splunk,     ?
         ?             ? ?  Jaeger,     ?
         ?             ? ?  Tempo, ...) ?
         ??????????????? ????????????????
```

---

## Pre-Built Instruments

| Instrument | Type | Name | Unit |
|-----------|------|------|------|
| Request Counter | Counter | `igc.http.requests.total` | requests |
| Request Duration | Histogram | `igc.http.request.duration` | ms |
| Exception Counter | Counter | `igc.exceptions.total` | exceptions |
| Facade Op Counter | Counter | `igc.facade.operations.total` | operations |
| Facade Op Duration | Histogram | `igc.facade.operation.duration` | ms |

---

## Middleware Pipeline Order

```
1. Swagger (Development)
2. Security Headers
3. CorrelationIdMiddleware
4. RequestTracingMiddleware  ? NEW (Observability)
5. GlobalExceptionMiddleware
6. HTTPS Redirection
7. CORS
8. Rate Limiting
9. Authorization
10. Controllers
11. Health Checks
```
