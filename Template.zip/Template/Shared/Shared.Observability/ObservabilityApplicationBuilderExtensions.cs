using IGC.Fulfillment.Shared.Observability.Configuration;
using IGC.Fulfillment.Shared.Observability.Middleware;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace IGC.Fulfillment.Shared.Observability;

/// <summary>
/// Extension to register the observability middleware in the HTTP pipeline.
/// </summary>
public static class ObservabilityApplicationBuilderExtensions
{
    /// <summary>
    /// Adds the request tracing middleware if tracing is enabled in configuration.
    /// Call this early in the pipeline (after CorrelationIdMiddleware, before exception handling).
    /// </summary>
    public static IApplicationBuilder UseObservability(this IApplicationBuilder app)
    {
        var options = app.ApplicationServices.GetRequiredService<IOptions<ObservabilityOptions>>().Value;

        if (options.Tracing.Enabled)
        {
            app.UseMiddleware<RequestTracingMiddleware>();
        }

        return app;
    }
}
