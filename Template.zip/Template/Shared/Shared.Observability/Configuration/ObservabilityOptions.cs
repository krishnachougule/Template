namespace IGC.Fulfillment.Shared.Observability.Configuration;

/// <summary>
/// Root configuration for the observability stack.
/// Bind from "Observability" section in appsettings.json.
/// </summary>
public sealed class ObservabilityOptions
{
    public const string SectionName = "Observability";

    /// <summary>
    /// Logical service name used in all telemetry signals.
    /// </summary>
    public string ServiceName { get; set; } = "UnknownService";

    /// <summary>
    /// Service version reported in resource attributes.
    /// </summary>
    public string ServiceVersion { get; set; } = "1.0.0";

    /// <summary>
    /// Environment name (e.g., Development, Staging, Production).
    /// Automatically set from ASPNETCORE_ENVIRONMENT if not specified.
    /// </summary>
    public string? Environment { get; set; }

    /// <summary>
    /// Logging configuration.
    /// </summary>
    public LoggingOptions Logging { get; set; } = new();

    /// <summary>
    /// Distributed tracing configuration.
    /// </summary>
    public TracingOptions Tracing { get; set; } = new();

    /// <summary>
    /// Metrics configuration.
    /// </summary>
    public MetricsOptions Metrics { get; set; } = new();
}

/// <summary>
/// Configuration for the logging pillar.
/// </summary>
public sealed class LoggingOptions
{
    /// <summary>
    /// Master switch to enable/disable OpenTelemetry-based structured logging.
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Whether to include formatted message in the log record.
    /// </summary>
    public bool IncludeFormattedMessage { get; set; } = true;

    /// <summary>
    /// Whether to include scopes in the log record.
    /// </summary>
    public bool IncludeScopes { get; set; } = true;

    /// <summary>
    /// Export destinations for logs.
    /// </summary>
    public ExportDestination Destination { get; set; } = new();
}

/// <summary>
/// Configuration for the distributed tracing pillar.
/// </summary>
public sealed class TracingOptions
{
    /// <summary>
    /// Master switch to enable/disable distributed tracing.
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Instrument ASP.NET Core incoming HTTP requests.
    /// </summary>
    public bool InstrumentAspNetCore { get; set; } = true;

    /// <summary>
    /// Instrument outgoing HttpClient requests.
    /// </summary>
    public bool InstrumentHttpClient { get; set; } = true;

    /// <summary>
    /// Instrument SqlClient database calls.
    /// </summary>
    public bool InstrumentSqlClient { get; set; } = true;

    /// <summary>
    /// Whether SQL command text is captured in trace spans (may contain sensitive data).
    /// </summary>
    public bool RecordSqlCommandText { get; set; } = false;

    /// <summary>
    /// Additional custom ActivitySource names to listen on.
    /// </summary>
    public List<string> AdditionalSources { get; set; } = [];

    /// <summary>
    /// Sampling ratio (0.0 to 1.0). 1.0 means capture everything.
    /// </summary>
    public double SamplingRatio { get; set; } = 1.0;

    /// <summary>
    /// Export destination for traces.
    /// </summary>
    public ExportDestination Destination { get; set; } = new();
}

/// <summary>
/// Configuration for the metrics pillar.
/// </summary>
public sealed class MetricsOptions
{
    /// <summary>
    /// Master switch to enable/disable metrics collection.
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Collect ASP.NET Core HTTP server metrics.
    /// </summary>
    public bool InstrumentAspNetCore { get; set; } = true;

    /// <summary>
    /// Collect outgoing HttpClient metrics.
    /// </summary>
    public bool InstrumentHttpClient { get; set; } = true;

    /// <summary>
    /// Collect .NET runtime metrics (GC, thread pool, etc.).
    /// </summary>
    public bool InstrumentRuntime { get; set; } = true;

    /// <summary>
    /// Collect process-level metrics (CPU, memory).
    /// </summary>
    public bool InstrumentProcess { get; set; } = true;

    /// <summary>
    /// Additional custom Meter names to listen on.
    /// </summary>
    public List<string> AdditionalMeters { get; set; } = [];

    /// <summary>
    /// Export interval for periodic metric reader (in milliseconds).
    /// </summary>
    public int ExportIntervalMs { get; set; } = 60000;

    /// <summary>
    /// Export destination for metrics.
    /// </summary>
    public ExportDestination Destination { get; set; } = new();
}

/// <summary>
/// Configures where a telemetry signal is exported.
/// </summary>
public sealed class ExportDestination
{
    /// <summary>
    /// The exporter type. Supported: Console, File, Otlp, Datadog, Splunk.
    /// </summary>
    public ExporterType Type { get; set; } = ExporterType.Console;

    /// <summary>
    /// OTLP endpoint (used by Otlp, Datadog agent, Splunk HEC via OTLP).
    /// Example: "http://localhost:4317" (gRPC) or "http://localhost:4318" (HTTP/protobuf).
    /// </summary>
    public string? Endpoint { get; set; }

    /// <summary>
    /// OTLP protocol: "grpc" or "httpprotobuf".
    /// </summary>
    public string Protocol { get; set; } = "grpc";

    /// <summary>
    /// Optional headers sent with export requests (e.g., API keys).
    /// Format: "key1=value1,key2=value2".
    /// </summary>
    public string? Headers { get; set; }

    /// <summary>
    /// File path when Type is File (used for logging only).
    /// </summary>
    public string? FilePath { get; set; }

    /// <summary>
    /// Maximum file size in MB before rolling (File exporter).
    /// </summary>
    public int MaxFileSizeMb { get; set; } = 100;
}

/// <summary>
/// Supported exporter types.
/// </summary>
public enum ExporterType
{
    /// <summary>
    /// Write telemetry to stdout/console.
    /// </summary>
    Console,

    /// <summary>
    /// Write logs to a physical file.
    /// </summary>
    File,

    /// <summary>
    /// Export via OpenTelemetry Protocol (OTLP) � works with any OTLP-compatible backend.
    /// </summary>
    Otlp,

    /// <summary>
    /// Export to Datadog via OTLP (Datadog Agent must be configured to receive OTLP).
    /// Default endpoint: http://localhost:4317
    /// </summary>
    Datadog,

    /// <summary>
    /// Export to Splunk via OTLP (Splunk OTel Collector).
    /// Default endpoint: http://localhost:4317
    /// </summary>
    Splunk
}
