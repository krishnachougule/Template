using System.Text;
using OpenTelemetry;
using OpenTelemetry.Logs;

namespace IGC.Fulfillment.Shared.Observability.Exporters;

/// <summary>
/// Writes OpenTelemetry LogRecords to a rolling file.
/// File size is tracked in memory to avoid a filesystem stat on every batch.
/// Flushing is deferred to end-of-batch rather than per-line to minimise syscalls.
/// </summary>
public sealed class FileLogExporter : BaseExporter<LogRecord>
{
    private readonly string _filePath;
    private readonly long _maxFileSizeBytes;
    private readonly object _lock = new();
    private StreamWriter? _writer;
    private long _approximateBytes;
    private bool _rollFailed;  // latched when RollFile fails � prevents retry storm

    public FileLogExporter(string filePath, int maxFileSizeMb)
    {
        if (string.IsNullOrWhiteSpace(filePath))
            throw new ArgumentException("File path must not be empty.", nameof(filePath));

        if (maxFileSizeMb <= 0)
            throw new ArgumentOutOfRangeException(nameof(maxFileSizeMb), "Max file size must be greater than zero.");

        _filePath = filePath;
        _maxFileSizeBytes = maxFileSizeMb * 1024L * 1024L;

        var directory = Path.GetDirectoryName(_filePath);
        if (!string.IsNullOrEmpty(directory))
            Directory.CreateDirectory(directory);

        var stream = new FileStream(_filePath, FileMode.Append, FileAccess.Write, FileShare.Read);
        _approximateBytes = stream.Length; // seed from existing file so we don't over-fill on restart
        _writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = false }; // flush per-batch, not per-line
    }

    public override ExportResult Export(in Batch<LogRecord> batch)
    {
        try
        {
            lock (_lock)
            {
                if (_writer is null) return ExportResult.Failure;

                foreach (var logRecord in batch)
                {
                    var timestamp = logRecord.Timestamp != default
                        ? logRecord.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff")
                        : DateTimeOffset.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");

                    var sb = new StringBuilder();
                    sb.Append($"[{timestamp}] [{logRecord.LogLevel}] [{logRecord.CategoryName ?? "Unknown"}] {logRecord.FormattedMessage ?? logRecord.Body ?? string.Empty}");

                    if (logRecord.Exception is not null)
                    {
                        sb.AppendLine();
                        sb.Append($"  Exception: {logRecord.Exception}");
                    }

                    var line = sb.ToString();
                    _writer.WriteLine(line);
                    _approximateBytes += Encoding.UTF8.GetByteCount(line) + Environment.NewLine.Length;
                }

                // Single flush for the entire batch � one syscall instead of one per line
                _writer.Flush();

                // Only attempt roll when the in-memory counter is over the limit
                // and a previous roll has not already failed (prevents retry storm)
                if (!_rollFailed && _approximateBytes >= _maxFileSizeBytes)
                    RollFile();
            }

            return ExportResult.Success;
        }
        catch
        {
            return ExportResult.Failure;
        }
    }

    private void RollFile()
    {
        // Dispose the current writer before moving the file
        _writer?.Dispose();
        _writer = null;

        try
        {
            var rolledName = Path.Combine(
                Path.GetDirectoryName(_filePath) ?? ".",
                $"{Path.GetFileNameWithoutExtension(_filePath)}_{DateTime.UtcNow:yyyyMMdd_HHmmss}{Path.GetExtension(_filePath)}");

            File.Move(_filePath, rolledName);

            var stream = new FileStream(_filePath, FileMode.Create, FileAccess.Write, FileShare.Read);
            _writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = false };
            _approximateBytes = 0;
            _rollFailed = false;
        }
        catch
        {
            // Roll failed � latch the flag so we stop retrying on every subsequent batch.
            // Re-open the original file in append mode so logging continues even without rolling.
            _rollFailed = true;
            _approximateBytes = 0; // reset counter so we don't re-enter on every batch

            try
            {
                var stream = new FileStream(_filePath, FileMode.Append, FileAccess.Write, FileShare.Read);
                _writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = false };
            }
            catch
            {
                // Cannot recover � _writer remains null, Export() will return Failure
            }
        }
    }

    protected override bool OnShutdown(int timeoutMilliseconds)
    {
        lock (_lock)
        {
            _writer?.Flush();
            _writer?.Dispose();
            _writer = null;
        }
        return true;
    }
}
