﻿using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace IGC.Fulfillment.Shared.Observability.Diagnostics;

/// <summary>
/// Central place for custom ActivitySource and Meter definitions.
/// Services that need custom spans or metrics should reference these.
/// </summary>
public static class ObservabilityDefaults
{
    /// <summary>
    /// Default activity source name used by platform middleware and decorators.
    /// </summary>
    public const string ActivitySourceName = "IGC.Fulfillment";

    /// <summary>
    /// Default meter name used by platform components.
    /// </summary>
    public const string MeterName = "IGC.Fulfillment";

    /// <summary>
    /// Shared ActivitySource for creating custom spans across the platform.
    /// </summary>
    public static readonly ActivitySource ActivitySource = new(ActivitySourceName, "1.0.0");

    /// <summary>
    /// Shared Meter for recording custom metrics across the platform.
    /// </summary>
    public static readonly Meter Meter = new(MeterName, "1.0.0");

    // ── HTTP instruments ──────────────────────────────────────────────────────

    /// <summary>
    /// Counter: total HTTP requests handled.
    /// </summary>
    public static readonly Counter<long> RequestCounter =
        Meter.CreateCounter<long>("igc.http.requests.total", "requests", "Total HTTP requests handled");

    /// <summary>
    /// Histogram: HTTP request duration in milliseconds.
    /// </summary>
    public static readonly Histogram<double> RequestDuration =
        Meter.CreateHistogram<double>("igc.http.request.duration", "ms", "HTTP request duration");

    // ── Exception instruments ─────────────────────────────────────────────────

    /// <summary>
    /// Counter: total unhandled exceptions.
    /// </summary>
    public static readonly Counter<long> ExceptionCounter =
        Meter.CreateCounter<long>("igc.exceptions.total", "exceptions", "Total unhandled exceptions");

    // ── Facade instruments ────────────────────────────────────────────────────

    /// <summary>
    /// Counter: total facade operations executed.
    /// </summary>
    public static readonly Counter<long> FacadeOperationCounter =
        Meter.CreateCounter<long>("igc.facade.operations.total", "operations", "Total facade operations");

    /// <summary>
    /// Histogram: facade operation duration in milliseconds.
    /// </summary>
    public static readonly Histogram<double> FacadeOperationDuration =
        Meter.CreateHistogram<double>("igc.facade.operation.duration", "ms", "Facade operation duration");

    // ── Adapter instruments ───────────────────────────────────────────────────

    /// <summary>
    /// Counter: total adapter operations executed.
    /// </summary>
    public static readonly Counter<long> AdapterOperationCounter =
        Meter.CreateCounter<long>("igc.adapter.operations.total", "operations", "Total adapter operations");

    /// <summary>
    /// Histogram: adapter operation duration in milliseconds.
    /// </summary>
    public static readonly Histogram<double> AdapterOperationDuration =
        Meter.CreateHistogram<double>("igc.adapter.operation.duration", "ms", "Adapter operation duration");
}
