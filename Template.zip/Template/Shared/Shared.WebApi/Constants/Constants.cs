﻿namespace IGC.Fulfillment.Shared.WebApi.Constants;

public static class WebApiConstants
{
    public static class Defaults
    {
        public const string DefaultCorsPolicy = "DefaultCorsPolicy";

        // ── Request headers ───────────────────────────────────────────────────
        public const string CorrelationIdHeader      = "Correlation-Id";      // Optional  — generated if absent
        public const string WorkflowInstanceIdHeader  = "Workflow-Instance-Id"; // Optional  — Orchestrator only
        public const string IdempotencyKeyHeader      = "Idempotency-Key";     // Required  — POST/PATCH only
        public const string RequestTimestampHeader    = "Request-Timestamp";   // Optional  — caller provided

        // ── Response headers ──────────────────────────────────────────────────
        public const string IdempotencyReplayedHeader = "Idempotency-Replayed"; // Always written — true/false
        public const string ProcessingTimeMsHeader    = "Processing-Time-Ms";   // Always written — full pipeline ms

        // ── HttpContext.Items keys ────────────────────────────────────────────
        public const string MarkIdempotencyReplayedKey = "MarkIdempotencyReplayed";
    }
}
