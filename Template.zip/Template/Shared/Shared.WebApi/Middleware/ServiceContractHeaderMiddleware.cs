﻿using System.Diagnostics;
using IGC.Fulfillment.Shared.WebApi.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace IGC.Fulfillment.Shared.WebApi.Middleware;

/// <summary>
/// Owns all platform-contract headers for every service. Wired automatically via UsePlatform().
///
/// Request headers:
///   Correlation-Id       — Optional. Read from request or generated; echoed on response.
///   Workflow-Instance-Id — Optional. Saga ID; only the Orchestrator sets this.
///   Request-Timestamp    — Optional. ISO-8601 caller timestamp for stale-retry / SLA detection.
///   Idempotency-Key      — Required on POST/PATCH. Returns 400 if absent.
///
/// Response headers (always present):
///   Correlation-Id       — Echoed so the caller can join the distributed trace.
///   Idempotency-Replayed — true when served from an idempotency cache; false otherwise.
///   Processing-Time-Ms   — Exact wall-clock ms; stopwatch stops after the full pipeline completes.
/// </summary>
public sealed class ServiceContractHeaderMiddleware
{
    private static readonly HashSet<string> IdempotencyRequiredMethods =
        new(StringComparer.OrdinalIgnoreCase) { "POST", "PATCH" };

    private readonly RequestDelegate _next;
    private readonly ILogger<ServiceContractHeaderMiddleware> _logger;

    public ServiceContractHeaderMiddleware(RequestDelegate next, ILogger<ServiceContractHeaderMiddleware> logger)
    {
        _next   = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // ── Correlation-Id (optional — generated when absent) ─────────────────
        var correlationId = context.Request.Headers[WebApiConstants.Defaults.CorrelationIdHeader]
                                   .FirstOrDefault()
                            ?? Guid.NewGuid().ToString("N");

        context.Items[WebApiConstants.Defaults.CorrelationIdHeader] = correlationId;

        // ── Workflow-Instance-Id (optional) ───────────────────────────────────
        var workflowInstanceId = context.Request.Headers[WebApiConstants.Defaults.WorkflowInstanceIdHeader]
                                         .FirstOrDefault();

        if (workflowInstanceId is not null)
            context.Items[WebApiConstants.Defaults.WorkflowInstanceIdHeader] = workflowInstanceId;

        // ── Request-Timestamp (optional) ──────────────────────────────────────
        var requestTimestamp = context.Request.Headers[WebApiConstants.Defaults.RequestTimestampHeader]
                                      .FirstOrDefault();

        if (requestTimestamp is not null)
            context.Items[WebApiConstants.Defaults.RequestTimestampHeader] = requestTimestamp;

        // ── Idempotency-Key (required on POST/PATCH) ──────────────────────────
        var idempotencyKey = context.Request.Headers[WebApiConstants.Defaults.IdempotencyKeyHeader]
                                    .FirstOrDefault();

        if (idempotencyKey is null
            && IdempotencyRequiredMethods.Contains(context.Request.Method)
            && !IsInfraPath(context.Request.Path))
        {
            _logger.LogWarning(
                "Missing {Header} on {Method} {Path}",
                WebApiConstants.Defaults.IdempotencyKeyHeader,
                context.Request.Method,
                context.Request.Path);

            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            await context.Response.WriteAsync(
                $"The '{WebApiConstants.Defaults.IdempotencyKeyHeader}' header is required " +
                $"for {context.Request.Method} requests.");
            return;
        }

        if (idempotencyKey is not null)
            context.Items[WebApiConstants.Defaults.IdempotencyKeyHeader] = idempotencyKey;

        // ── Idempotency-Replayed flag (toggled by downstream idempotency cache) 
        var isReplayed = false;
        context.Items[WebApiConstants.Defaults.MarkIdempotencyReplayedKey] = (Action)(() => isReplayed = true);

        // ── Register response headers BEFORE awaiting _next ───────────────────
        // OnStarting fires when headers flush. Processing-Time-Ms is written here
        // using the stopwatch reference — which is stopped AFTER _next returns,
        // ensuring the full pipeline execution time is captured accurately.
        var stopwatch = Stopwatch.StartNew();

        context.Response.OnStarting(() =>
        {
            context.Response.Headers[WebApiConstants.Defaults.CorrelationIdHeader]       = correlationId;
            context.Response.Headers[WebApiConstants.Defaults.ProcessingTimeMsHeader]    = stopwatch.ElapsedMilliseconds.ToString();
            context.Response.Headers[WebApiConstants.Defaults.IdempotencyReplayedHeader] = isReplayed.ToString().ToLowerInvariant();
            return Task.CompletedTask;
        });

        // ── Execute the rest of the pipeline ──────────────────────────────────
        using (_logger.BeginScope(new Dictionary<string, object>
               {
                   [WebApiConstants.Defaults.CorrelationIdHeader]     = correlationId,
                   [WebApiConstants.Defaults.WorkflowInstanceIdHeader] = workflowInstanceId ?? string.Empty
               }))
        {
            await _next(context);  // ← full pipeline runs here
        }

        // Stopwatch stops AFTER the full pipeline (controller + facades + DB) completes.
        // OnStarting already captured the reference so the header gets the correct value.
        stopwatch.Stop();
    }

    /// <summary>Skips idempotency enforcement for infrastructure paths.</summary>
    private static bool IsInfraPath(PathString path) =>
        path.StartsWithSegments("/health",  StringComparison.OrdinalIgnoreCase) ||
        path.StartsWithSegments("/swagger", StringComparison.OrdinalIgnoreCase);
}