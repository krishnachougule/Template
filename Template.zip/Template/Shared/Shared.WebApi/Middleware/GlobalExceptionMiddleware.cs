using System.Net;
using System.Text.Json;
using IGC.Fulfillment.Shared.WebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace IGC.Fulfillment.Shared.WebApi.Middleware;

/// <summary>
/// Catches all unhandled exceptions and converts them into the standard error envelope.
/// OperationCanceledException is logged and results in a 499 response with an empty body
/// (client disconnected � no point writing a body). All writes are guarded against
/// responses that have already started streaming.
/// </summary>
public class GlobalExceptionMiddleware
{
    private static readonly JsonSerializerOptions JsonOptions =
        new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (OperationCanceledException)
        {
            // Bug 3 fix: only set status if the response hasn't started; never write a body
            // as the client has already disconnected. Do not re-throw � the pipeline is done.
            _logger.LogInformation("Request was cancelled by the client");

            if (!context.Response.HasStarted)
                context.Response.StatusCode = 499;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An unhandled exception occurred: {Message}", ex.Message);

            // Bug 2 fix: guard against writing to a response that has already started streaming
            if (!context.Response.HasStarted)
            {
                await WriteErrorResponse(context, HttpStatusCode.InternalServerError,
                    "An unexpected error occurred. Please try again later.");
            }
        }
    }

    private static async Task WriteErrorResponse(
        HttpContext context,
        HttpStatusCode statusCode,
        string message)
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)statusCode;

        var errorResponse = new ErrorResponse
        {
            Type = statusCode.ToString(),
            Title = message,
            Status = (int)statusCode,
            Detail = message,
            Instance = context.Request.Path,
            CorrelationId = context.Items["CorrelationId"]?.ToString()
        };

        await context.Response.WriteAsync(JsonSerializer.Serialize(errorResponse, JsonOptions));
    }
}
