﻿using IGC.Fulfillment.Shared.WebApi.Constants;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Reflection;

namespace IGC.Fulfillment.Shared.WebApi.Extensions;

/// <summary>
/// Convention-based assembly scanning extensions for IServiceCollection.
/// Registers concrete types against their matching interfaces by naming convention (scoped lifetime).
/// Supported suffixes: Repository, Facade, DataService, Adapter.
/// Convention: class OrderAdapter implements IOrderAdapter → registered as IOrderAdapter → OrderAdapter.
/// </summary>
public static class ServiceCollectionExtensions
{
    private static readonly string[] ConventionSuffixes = ["Repository", "Facade", "DataService", "Adapter"];

    /// <summary>
    /// Single call — registers the full platform:
    /// CORS, Swagger (dev only), and all convention-matched types as scoped.
    /// </summary>
    public static IServiceCollection AddPlatform(
        this IServiceCollection services,
        IConfiguration configuration,
        IWebHostEnvironment environment,
        params Assembly[] assemblies)
    {
        // CORS — policy consumed by UsePlatform's app.UseCors(...)
        services.AddCors(options =>
        {
            options.AddPolicy(WebApiConstants.Defaults.DefaultCorsPolicy, policy =>
            {
                policy
                    .WithOrigins(configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? [])
                    .AllowAnyHeader()
                    .AllowAnyMethod();
            });
        });

        // Swagger — only registered in development; UsePlatform gates middleware the same way
        if (environment.IsDevelopment())
        {
            var serviceName = configuration["Observability:ServiceName"] ?? environment.ApplicationName;

            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new() { Title = serviceName, Version = "v1" });
            });
        }

        // Convention scanning — guard against the same assembly scanned more than once
        foreach (var assembly in assemblies.Distinct())
            services.AddScopedByConvention(assembly);

        return services;
    }

    /// <summary>
    /// Scans the given assembly and registers all classes whose names end with a known suffix
    /// (Repository, Facade, DataService, Adapter) against their matching I-prefixed interface, as scoped.
    /// </summary>
    public static IServiceCollection AddScopedByConvention(
        this IServiceCollection services,
        Assembly assembly)
    {
        var concreteTypes = assembly
            .GetTypes()
            .Where(t => t is { IsClass: true, IsAbstract: false, IsGenericType: false });

        foreach (var type in concreteTypes)
        {
            var matchedSuffix = ConventionSuffixes.FirstOrDefault(suffix =>
                type.Name.EndsWith(suffix, StringComparison.Ordinal));

            if (matchedSuffix is null)
                continue;

            var interfaceName = $"I{type.Name}";
            var matchedInterface = type
                .GetInterfaces()
                .FirstOrDefault(i => i.Name == interfaceName);

            if (matchedInterface is null)
                continue;

            // Skip if already registered to prevent duplicate scoped entries
            if (services.Any(sd => sd.ServiceType == matchedInterface))
                continue;

            services.AddScoped(matchedInterface, type);
        }

        return services;
    }
}