﻿using IGC.Fulfillment.Shared.WebApi.Constants;
using IGC.Fulfillment.Shared.WebApi.Middleware;
using IGC.Fulfillment.Shared.Observability;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;

namespace IGC.Fulfillment.Shared.WebApi.Extensions;

/// <summary>
/// Single call — UsePlatform() — configures the full middleware pipeline for every service.
/// Registering here means no individual service needs to wire these up manually.
/// </summary>
public static class ApplicationBuilderExtensions
{
    public static WebApplication UsePlatform(this WebApplication app)
    {
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(options =>
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1"));
        }

        // Secure transport headers — outermost, runs on every response
        app.Use(async (context, next) =>
        {
            context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
            context.Response.Headers.Append("X-Frame-Options", "DENY");
            context.Response.Headers.Append("X-XSS-Protection", "1; mode=block");
            context.Response.Headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");
            context.Response.Headers.Append("Content-Security-Policy", "default-src 'self'");
            await next();
        });

        // ── Platform contract headers (all 8 — request + response) ───────────
        // Automatically applied to every service that calls UsePlatform().
        // No per-service wiring needed.
        app.UseMiddleware<ServiceContractHeaderMiddleware>();

        // Exception handling — must wrap the rest of the pipeline
        app.UseMiddleware<GlobalExceptionMiddleware>();

        // Observability — inside exception handler; observes the final resolved status code
        app.UseObservability();

        app.UseHttpsRedirection();
        app.UseCors(WebApiConstants.Defaults.DefaultCorsPolicy);
        app.UseRateLimiter();
        app.UseAuthorization();
        app.MapControllers();
        app.MapHealthChecks("/health");

        return app;
    }
}