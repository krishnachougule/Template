using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Contracts;

/// <summary>
/// Facade interface for ShipmentLine business logic orchestration.
/// </summary>
public interface IShipmentLineFacade : IFacade
{
    Task<ShipmentLineBE?> GetShipmentLineByIdAsync(int id, CancellationToken ct = default);
    Task<IEnumerable<ShipmentLineBE>> GetShipmentLinesByShipmentIdAsync(int shipmentId, string? statusFilter = null, CancellationToken ct = default);
    Task<IEnumerable<ShipmentLineBE>> GetShipmentLinesByOrderIdAsync(int orderId, CancellationToken ct = default);
    Task<ShipmentLineBE> CreateShipmentLineAsync(ShipmentLineBE shipmentLine, CancellationToken ct = default);
    Task UpdateShipmentLineAsync(ShipmentLineBE shipmentLine, CancellationToken ct = default);
    Task DeleteShipmentLineAsync(int id, CancellationToken ct = default);
}
