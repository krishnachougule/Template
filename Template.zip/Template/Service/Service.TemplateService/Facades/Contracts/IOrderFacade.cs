using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Contracts;

/// <summary>
/// Facade interface for Order business logic orchestration.
/// </summary>
public interface IOrderFacade : IFacade
{
    Task<OrderBE?> GetOrderByIdAsync(int id, CancellationToken ct = default);
    Task<OrderBE?> GetOrderByOrderNumberAsync(string orderNumber, CancellationToken ct = default);
    Task<IEnumerable<OrderBE>> GetOrdersByCustomerIdAsync(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null, CancellationToken ct = default);
    Task<OrderBE> CreateOrderAsync(OrderBE order, CancellationToken ct = default);
    Task UpdateOrderAsync(OrderBE order, CancellationToken ct = default);
    Task DeleteOrderAsync(int id, CancellationToken ct = default);
}
