namespace ICG.Fulfillment.Service.TemplateService.Facades.Contracts;

/// <summary>
/// Marker interface for all facade contracts.
/// </summary>
public interface IFacade
{
}