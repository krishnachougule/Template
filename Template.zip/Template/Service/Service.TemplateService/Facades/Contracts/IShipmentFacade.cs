using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Contracts;

/// <summary>
/// Facade interface for Shipment business logic orchestration.
/// </summary>
public interface IShipmentFacade : IFacade
{
    Task<ShipmentBE?> GetShipmentByIdAsync(int id, CancellationToken ct = default);
    Task<ShipmentBE?> GetShipmentByShipmentNumberAsync(string shipmentNumber, CancellationToken ct = default);
    Task<IEnumerable<ShipmentBE>> GetShipmentsByOrderIdAsync(int orderId, string? statusFilter = null, CancellationToken ct = default);
    Task<ShipmentBE> CreateShipmentAsync(ShipmentBE shipment, CancellationToken ct = default);
    Task UpdateShipmentAsync(ShipmentBE shipment, CancellationToken ct = default);
    Task DeleteShipmentAsync(int id, CancellationToken ct = default);
}
