using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.Translator;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Translators;

/// <summary>
/// Translator for mapping between ShipmentLineEntity (domain - snake_case) and ShipmentLineBusinessEntity (business - PascalCase).
/// Explicit mapping required because domain entity property names match database columns (snake_case).
/// </summary>
public class ShipmentLineEntity_ShipmentLineBE : BaseTranslator<ShipmentLineEntity, ShipmentLineBE>
{
    protected override ShipmentLineBE EntityToDto(ShipmentLineBE business, ShipmentLineEntity domain)
    {
        business.Id = domain.id;
        business.ShipmentId = domain.shipment_id;
        business.ShipmentNumber = domain.shipment_number;
        business.OrderId = domain.order_id;
        business.OrderNumber = domain.order_number;
        business.LineNumber = domain.line_number;
        business.OrderLineRef = domain.order_line_ref;
        business.Sku = domain.sku;
        business.ProductName = domain.product_name;
        business.ProductCategory = domain.product_category;
        business.QuantityOrdered = domain.quantity_ordered;
        business.QuantityShipped = domain.quantity_shipped;
        business.QuantityBackordered = domain.quantity_backordered;
        business.UnitOfMeasure = domain.unit_of_measure;
        business.UnitPrice = domain.unit_price;
        business.LineDiscount = domain.line_discount;
        business.LineTotal = domain.line_total;
        business.Currency = domain.currency;
        business.WarehouseBin = domain.warehouse_bin;
        business.LotNumber = domain.lot_number;
        business.SerialNumber = domain.serial_number;
        business.Status = domain.status;
        business.BackorderReason = domain.backorder_reason;
        business.CreatedAt = domain.created_at;
        business.UpdatedAt = domain.updated_at;
        business.CreatedBy = domain.created_by;
        business.UpdatedBy = domain.updated_by;
        business.RowVersion = domain.row_version;

        return business;
    }

    protected override ShipmentLineEntity DtoToEntity(ShipmentLineEntity domain, ShipmentLineBE business)
    {
        domain.id = business.Id;
        domain.shipment_id = business.ShipmentId;
        domain.shipment_number = business.ShipmentNumber;
        domain.order_id = business.OrderId;
        domain.order_number = business.OrderNumber;
        domain.line_number = business.LineNumber;
        domain.order_line_ref = business.OrderLineRef;
        domain.sku = business.Sku;
        domain.product_name = business.ProductName;
        domain.product_category = business.ProductCategory;
        domain.quantity_ordered = business.QuantityOrdered;
        domain.quantity_shipped = business.QuantityShipped;
        domain.quantity_backordered = business.QuantityBackordered;
        domain.unit_of_measure = business.UnitOfMeasure;
        domain.unit_price = business.UnitPrice;
        domain.line_discount = business.LineDiscount;
        domain.line_total = business.LineTotal;
        domain.currency = business.Currency;
        domain.warehouse_bin = business.WarehouseBin;
        domain.lot_number = business.LotNumber;
        domain.serial_number = business.SerialNumber;
        domain.status = business.Status;
        domain.backorder_reason = business.BackorderReason;
        domain.created_at = business.CreatedAt;
        domain.updated_at = business.UpdatedAt;
        domain.created_by = business.CreatedBy;
        domain.updated_by = business.UpdatedBy;
        domain.row_version = business.RowVersion;

        return domain;
    }
}
