using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.Translator;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Translators;

/// <summary>
/// Translator for mapping between ShipmentEntity (domain - snake_case) and ShipmentBusinessEntity (business - PascalCase).
/// Explicit mapping required because domain entity property names match database columns (snake_case).
/// </summary>
public class ShipmentEntity_ShipmentBE : BaseTranslator<ShipmentEntity, ShipmentBE>
{
    protected override ShipmentBE EntityToDto(ShipmentBE business, ShipmentEntity domain)
    {
        business.Id = domain.id;
        business.OrderId = domain.order_id;
        business.OrderNumber = domain.order_number;
        business.ShipmentNumber = domain.shipment_number;
        business.ShipmentSequence = domain.shipment_sequence;
        business.CarrierCode = domain.carrier_code;
        business.ServiceLevel = domain.service_level;
        business.TrackingNumber = domain.tracking_number;
        business.WarehouseCode = domain.warehouse_code;
        business.ShipToName = domain.ship_to_name;
        business.ShipToAddress1 = domain.ship_to_address1;
        business.ShipToAddress2 = domain.ship_to_address2;
        business.ShipToCity = domain.ship_to_city;
        business.ShipToState = domain.ship_to_state;
        business.ShipToZip = domain.ship_to_zip;
        business.ShipToCountry = domain.ship_to_country;
        business.TotalPackages = domain.total_packages;
        business.TotalWeightKg = domain.total_weight_kg;
        business.ShippingCost = domain.shipping_cost;
        business.Status = domain.status;
        business.FailureReason = domain.failure_reason;
        business.EstimatedDelivery = domain.estimated_delivery;
        business.DispatchedAt = domain.dispatched_at;
        business.DeliveredAt = domain.delivered_at;
        business.CreatedAt = domain.created_at;
        business.UpdatedAt = domain.updated_at;
        business.CreatedBy = domain.created_by;
        business.UpdatedBy = domain.updated_by;
        business.RowVersion = domain.row_version;

        return business;
    }

    protected override ShipmentEntity DtoToEntity(ShipmentEntity domain, ShipmentBE business)
    {
        domain.id = business.Id;
        domain.order_id = business.OrderId;
        domain.order_number = business.OrderNumber;
        domain.shipment_number = business.ShipmentNumber;
        domain.shipment_sequence = business.ShipmentSequence;
        domain.carrier_code = business.CarrierCode;
        domain.service_level = business.ServiceLevel;
        domain.tracking_number = business.TrackingNumber;
        domain.warehouse_code = business.WarehouseCode;
        domain.ship_to_name = business.ShipToName;
        domain.ship_to_address1 = business.ShipToAddress1;
        domain.ship_to_address2 = business.ShipToAddress2;
        domain.ship_to_city = business.ShipToCity;
        domain.ship_to_state = business.ShipToState;
        domain.ship_to_zip = business.ShipToZip;
        domain.ship_to_country = business.ShipToCountry;
        domain.total_packages = business.TotalPackages;
        domain.total_weight_kg = business.TotalWeightKg;
        domain.shipping_cost = business.ShippingCost;
        domain.status = business.Status;
        domain.failure_reason = business.FailureReason;
        domain.estimated_delivery = business.EstimatedDelivery;
        domain.dispatched_at = business.DispatchedAt;
        domain.delivered_at = business.DeliveredAt;
        domain.created_at = business.CreatedAt;
        domain.updated_at = business.UpdatedAt;
        domain.created_by = business.CreatedBy;
        domain.updated_by = business.UpdatedBy;
        domain.row_version = business.RowVersion;

        return domain;
    }
}
