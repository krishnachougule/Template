using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.Translator;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Translators;

/// <summary>
/// Translator for mapping between OrderEntity (domain - snake_case) and OrderBusinessEntity (business - PascalCase).
/// Explicit mapping required because domain entity property names match database columns (snake_case).
/// </summary>
public class OrderEntity_OrderBE : BaseTranslator<OrderEntity, OrderBE>
{
    protected override OrderBE EntityToDto(OrderBE business, OrderEntity domain)
    {
        business.Id = domain.id;
        business.OrderNumber = domain.order_number;
        business.CustomerId = domain.customer_id;
        business.CustomerName = domain.customer_name;
        business.CustomerPoRef = domain.customer_po_ref;
        business.OrderType = domain.order_type;
        business.Channel = domain.channel;
        business.SalesRepId = domain.sales_rep_id;
        business.SubtotalAmount = domain.subtotal_amount;
        business.DiscountAmount = domain.discount_amount;
        business.TaxAmount = domain.tax_amount;
        business.TotalAmount = domain.total_amount;
        business.Currency = domain.currency;
        business.Status = domain.status;
        business.CancellationReason = domain.cancellation_reason;
        business.CreditStatus = domain.credit_status;
        business.CreditCheckedAt = domain.credit_checked_at;
        business.RequestedShipDate = domain.requested_ship_date;
        business.ConfirmedShipDate = domain.confirmed_ship_date;
        business.CreatedAt = domain.created_at;
        business.UpdatedAt = domain.updated_at;
        business.CreatedBy = domain.created_by;
        business.UpdatedBy = domain.updated_by;
        business.RowVersion = domain.row_version;

        return business;
    }

    protected override OrderEntity DtoToEntity(OrderEntity domain, OrderBE business)
    {
        domain.id = business.Id;
        domain.order_number = business.OrderNumber;
        domain.customer_id = business.CustomerId;
        domain.customer_name = business.CustomerName;
        domain.customer_po_ref = business.CustomerPoRef;
        domain.order_type = business.OrderType;
        domain.channel = business.Channel;
        domain.sales_rep_id = business.SalesRepId;
        domain.subtotal_amount = business.SubtotalAmount;
        domain.discount_amount = business.DiscountAmount;
        domain.tax_amount = business.TaxAmount;
        domain.total_amount = business.TotalAmount;
        domain.currency = business.Currency;
        domain.status = business.Status;
        domain.cancellation_reason = business.CancellationReason;
        domain.credit_status = business.CreditStatus;
        domain.credit_checked_at = business.CreditCheckedAt;
        domain.requested_ship_date = business.RequestedShipDate;
        domain.confirmed_ship_date = business.ConfirmedShipDate;
        domain.created_at = business.CreatedAt;
        domain.updated_at = business.UpdatedAt;
        domain.created_by = business.CreatedBy;
        domain.updated_by = business.UpdatedBy;
        domain.row_version = business.RowVersion;

        return domain;
    }
}
