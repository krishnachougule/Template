using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Facades.Base;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Impl;

/// <summary>
/// Order Facade implementation - orchestrates business logic and data access.
/// Translates between Business Entities (PascalCase) and Domain Entities (snake_case).
/// </summary>
public class OrderFacade : BaseFacade, IOrderFacade
{
    public OrderFacade(
        IServiceDataService dataService,
        ITranslatorService translator,
        ILogger<OrderFacade> logger) : base(dataService, translator, logger)
    {
    }

    public async Task<OrderBE?> GetOrderByIdAsync(int id, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = DataService.Orders.GetById(id);
            return domainEntity != null
                ? Translator.Map<OrderBE>(domainEntity)
                : null;
        }, ct: ct);
    }

    public async Task<OrderBE?> GetOrderByOrderNumberAsync(string orderNumber, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = DataService.Orders.GetByOrderNumber(orderNumber);
            return domainEntity != null
                ? Translator.Map<OrderBE>(domainEntity)
                : null;
        }, ct: ct);
    }

    public async Task<IEnumerable<OrderBE>> GetOrdersByCustomerIdAsync(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntities = DataService.Orders.GetByCustomerId(customerId, statusFilter, pageNumber, pageSize);
            return Translator.MapRange<OrderBE>(domainEntities);
        }, ct: ct);
    }

    public async Task<OrderBE> CreateOrderAsync(OrderBE businessEntity, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = Translator.Map<OrderEntity>(businessEntity);
            DataService.Orders.Create(domainEntity);
            businessEntity.Id = domainEntity.id;
            return businessEntity;
        }, ct: ct);
    }

    public async Task UpdateOrderAsync(OrderBE businessEntity, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var domainEntity = Translator.Map<OrderEntity>(businessEntity);
            DataService.Orders.Update(domainEntity);
        }, ct: ct);
    }

    public async Task DeleteOrderAsync(int id, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var entity = DataService.Orders.GetById(id);
            if (entity != null)
            {
                DataService.Orders.Delete(entity);
            }
        }, ct: ct);
    }
}
