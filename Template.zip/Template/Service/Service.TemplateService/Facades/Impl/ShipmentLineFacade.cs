using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Facades.Base;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Impl;

/// <summary>
/// ShipmentLine Facade implementation - orchestrates business logic and data access.
/// Translates between Business Entities (PascalCase) and Domain Entities (snake_case).
/// </summary>
public class ShipmentLineFacade : BaseFacade, IShipmentLineFacade
{
    public ShipmentLineFacade(
        IServiceDataService dataService,
        ITranslatorService translator,
        ILogger<ShipmentLineFacade> logger) : base(dataService, translator, logger)
    {
    }

    public async Task<ShipmentLineBE?> GetShipmentLineByIdAsync(int id, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = DataService.ShipmentLines.GetById(id);
            return domainEntity != null
                ? Translator.Map<ShipmentLineBE>(domainEntity)
                : null;
        }, ct: ct);
    }

    public async Task<IEnumerable<ShipmentLineBE>> GetShipmentLinesByShipmentIdAsync(int shipmentId, string? statusFilter = null, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntities = DataService.ShipmentLines.GetByShipmentId(shipmentId, statusFilter);
            return Translator.MapRange<ShipmentLineBE>(domainEntities);
        }, ct: ct);
    }

    public async Task<IEnumerable<ShipmentLineBE>> GetShipmentLinesByOrderIdAsync(int orderId, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntities = DataService.ShipmentLines.GetByOrderId(orderId);
            return Translator.MapRange<ShipmentLineBE>(domainEntities);
        }, ct: ct);
    }

    public async Task<ShipmentLineBE> CreateShipmentLineAsync(ShipmentLineBE businessEntity, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = Translator.Map<ShipmentLineEntity>(businessEntity);
            DataService.ShipmentLines.Create(domainEntity);
            businessEntity.Id = domainEntity.id;
            return businessEntity;
        }, ct: ct);
    }

    public async Task UpdateShipmentLineAsync(ShipmentLineBE businessEntity, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var domainEntity = Translator.Map<ShipmentLineEntity>(businessEntity);
            DataService.ShipmentLines.Update(domainEntity);
        }, ct: ct);
    }

    public async Task DeleteShipmentLineAsync(int id, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var entity = DataService.ShipmentLines.GetById(id);
            if (entity != null)
            {
                DataService.ShipmentLines.Delete(entity);
            }
        }, ct: ct);
    }
}
