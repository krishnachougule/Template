using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.Data;
using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Facades.Base;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Impl;

/// <summary>
/// Shipment Facade implementation - orchestrates business logic and data access.
/// Translates between Business Entities (PascalCase) and Domain Entities (snake_case).
/// </summary>
public class ShipmentFacade : BaseFacade, IShipmentFacade
{
    public ShipmentFacade(
        IServiceDataService dataService,
        ITranslatorService translator,
        ILogger<ShipmentFacade> logger) : base(dataService, translator, logger)
    {
    }

    public async Task<ShipmentBE?> GetShipmentByIdAsync(int id, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = DataService.Shipments.GetById(id);
            return domainEntity != null
                ? Translator.Map<ShipmentBE>(domainEntity)
                : null;
        }, ct: ct);
    }

    public async Task<ShipmentBE?> GetShipmentByShipmentNumberAsync(string shipmentNumber, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = DataService.Shipments.GetByShipmentNumber(shipmentNumber);
            return domainEntity != null
                ? Translator.Map<ShipmentBE>(domainEntity)
                : null;
        }, ct: ct);
    }

    public async Task<IEnumerable<ShipmentBE>> GetShipmentsByOrderIdAsync(int orderId, string? statusFilter = null, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntities = DataService.Shipments.GetByOrderId(orderId, statusFilter);
            return Translator.MapRange<ShipmentBE>(domainEntities);
        }, ct: ct);
    }

    public async Task<ShipmentBE> CreateShipmentAsync(ShipmentBE businessEntity, CancellationToken ct = default)
    {
        return await ExecuteAsync(() =>
        {
            var domainEntity = Translator.Map<ShipmentEntity>(businessEntity);
            DataService.Shipments.Create(domainEntity);
            businessEntity.Id = domainEntity.id;
            return businessEntity;
        }, ct: ct);
    }

    public async Task UpdateShipmentAsync(ShipmentBE businessEntity, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var existing = DataService.Shipments.GetById(businessEntity.Id)
                ?? throw new TranslatorException($"Shipment with Id {businessEntity.Id} not found.");

            var domainEntity = Translator.Map<ShipmentBE, ShipmentEntity>(businessEntity, existing);
            DataService.Shipments.Update(domainEntity);
        }, ct: ct);
    }

    public async Task DeleteShipmentAsync(int id, CancellationToken ct = default)
    {
        await ExecuteAsync(() =>
        {
            var entity = DataService.Shipments.GetById(id);
            if (entity != null)
            {
                DataService.Shipments.Delete(entity);
            }
        }, ct: ct);
    }
}
