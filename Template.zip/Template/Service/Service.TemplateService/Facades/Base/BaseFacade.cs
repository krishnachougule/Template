﻿using System.Diagnostics;
using System.Runtime.CompilerServices;
using ICG.Fulfillment.Service.TemplateService.Data;
using IGC.Fulfillment.Shared.Observability.Diagnostics;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;

namespace ICG.Fulfillment.Service.TemplateService.Facades.Base;

/// <summary>
/// Base facade class providing common infrastructure for all facades.
/// Automatically instruments every operation with tracing, metrics and structured logging.
/// All observability paths are guarded so no overhead is incurred when signals are disabled.
/// </summary>
public abstract class BaseFacade
{
    protected readonly ITranslatorService Translator;
    protected readonly IServiceDataService DataService;
    protected readonly ILogger Logger;

    // Cached once per concrete type — GetType().Name is a virtual call + string; cache it.
    private readonly string _facadeName;

    private static readonly Action<ILogger, string, string, double, Exception?> _logSuccess =
        LoggerMessage.Define<string, string, double>(
            LogLevel.Information,
            new EventId(10, "FacadeOperation"),
            "Facade {FacadeName} executed {OperationName} in {ElapsedMs:F1}ms");

    private static readonly Action<ILogger, string, string, double, Exception?> _logFailure =
        LoggerMessage.Define<string, string, double>(
            LogLevel.Error,
            new EventId(11, "FacadeOperationFailed"),
            "Facade {FacadeName} failed {OperationName} after {ElapsedMs:F1}ms");

    protected BaseFacade(IServiceDataService dataService, ITranslatorService translator, ILogger logger)
    {
        DataService = dataService;
        Translator = translator;
        Logger = logger;
        _facadeName = GetType().Name; // resolved once at construction, reused on every call
    }

    /// <summary>
    /// Executes a value-returning operation with full observability:
    /// tracing span, success/failure metrics, and structured logging.
    /// Each signal is individually guarded — no overhead when disabled.
    /// The caller's method name is automatically captured via <see cref="CallerMemberNameAttribute"/>.
    /// </summary>
    protected async Task<TResult> ExecuteAsync<TResult>(
        Func<TResult> operation,
        [CallerMemberName] string operationName = "",
        CancellationToken ct = default)
    {
        // ── Tracing ───────────────────────────────────────────────────────────
        // ActivitySource.StartActivity returns null when no listener is attached (tracing off).
        // The activity name string is only built when HasListeners is true to avoid
        // an eager string allocation that would be thrown away immediately.
        using var activity = ObservabilityDefaults.ActivitySource.HasListeners()
            ? ObservabilityDefaults.ActivitySource.StartActivity(
                $"{_facadeName}.{operationName}",
                ActivityKind.Internal)
            : null;

        activity?.SetTag("facade.name", _facadeName);
        activity?.SetTag("facade.operation", operationName);

        // ── Timing ────────────────────────────────────────────────────────────
        // Only start the stopwatch when at least one consumer needs the elapsed time:
        // metrics histogram or an enabled log level. Avoids the timer overhead otherwise.
        var needsTiming = ObservabilityDefaults.FacadeOperationDuration.Enabled
                          || Logger.IsEnabled(LogLevel.Information);

        var startTimestamp = needsTiming ? Stopwatch.GetTimestamp() : 0L;

        try
        {
            var result = await Task.Run(operation, ct);

            // ── Success metrics ───────────────────────────────────────────────
            if (ObservabilityDefaults.FacadeOperationCounter.Enabled)
            {
                ObservabilityDefaults.FacadeOperationCounter.Add(1,
                    new KeyValuePair<string, object?>("facade.name", _facadeName),
                    new KeyValuePair<string, object?>("facade.operation", operationName),
                    new KeyValuePair<string, object?>("outcome", "success"));
            }

            if (needsTiming)
            {
                var elapsedMs = GetElapsedMs(startTimestamp);

                if (ObservabilityDefaults.FacadeOperationDuration.Enabled)
                {
                    ObservabilityDefaults.FacadeOperationDuration.Record(elapsedMs,
                        new KeyValuePair<string, object?>("facade.name", _facadeName),
                        new KeyValuePair<string, object?>("facade.operation", operationName));
                }

                // LoggerMessage.Define guards IsEnabled internally — passing elapsedMs
                // only makes sense once we know timing was needed anyway.
                _logSuccess(Logger, _facadeName, operationName, elapsedMs, null);
            }

            return result;
        }
        catch (Exception ex)
        {
            // ── Tracing ───────────────────────────────────────────────────────
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            activity?.RecordException(ex);

            // ── Failure metrics ───────────────────────────────────────────────
            if (ObservabilityDefaults.FacadeOperationCounter.Enabled)
            {
                ObservabilityDefaults.FacadeOperationCounter.Add(1,
                    new KeyValuePair<string, object?>("facade.name", _facadeName),
                    new KeyValuePair<string, object?>("facade.operation", operationName),
                    new KeyValuePair<string, object?>("outcome", "failure"));
            }

            if (ObservabilityDefaults.ExceptionCounter.Enabled)
            {
                ObservabilityDefaults.ExceptionCounter.Add(1,
                    new KeyValuePair<string, object?>("exception.type", ex.GetType().Name),
                    new KeyValuePair<string, object?>("facade.name", _facadeName));
            }

            // ── Failure logging ───────────────────────────────────────────────
            var elapsedMs = needsTiming ? GetElapsedMs(startTimestamp) : 0d;
            _logFailure(Logger, _facadeName, operationName, elapsedMs, ex);

            throw;
        }
    }

    /// <summary>
    /// Executes a void operation by delegating to the generic overload.
    /// All observability (tracing, metrics, logging) is inherited from there.
    /// The caller's method name is automatically captured via <see cref="CallerMemberNameAttribute"/>.
    /// </summary>
    protected async Task ExecuteAsync(
        Action operation,
        [CallerMemberName] string operationName = "",
        CancellationToken ct = default)
    {
        await ExecuteAsync<object?>(
            () => { operation(); return null; },
            operationName: operationName,
            ct: ct);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Computes elapsed milliseconds from a <see cref="Stopwatch.GetTimestamp"/> snapshot.
    /// Uses timestamp arithmetic instead of a <see cref="Stopwatch"/> instance — avoids
    /// the object allocation entirely while retaining the same high-resolution accuracy.
    /// </summary>
    private static double GetElapsedMs(long startTimestamp)
        => (Stopwatch.GetTimestamp() - startTimestamp) * 1000d / Stopwatch.Frequency;
}
