using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Controllers.Base;
using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using Microsoft.AspNetCore.Mvc;

namespace ICG.Fulfillment.Service.TemplateService.Controllers;

/// <summary>
/// Controller for Shipment operations.
/// </summary>
public class ShipmentsController : BaseController<IShipmentAdapter>
{
    public ShipmentsController(IShipmentAdapter adapter) : base(adapter) { }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ShipmentResponse>> GetById(int id, CancellationToken ct)
    {
        var response = await Adapter.GetShipmentByIdAsync(id, ct);
        return OkOrNotFound(response);
    }

    [HttpGet("by-shipment-number/{shipmentNumber}")]
    public async Task<ActionResult<ShipmentResponse>> GetByShipmentNumber(string shipmentNumber, CancellationToken ct)
    {
        var response = await Adapter.GetShipmentByShipmentNumberAsync(shipmentNumber, ct);
        return OkOrNotFound(response);
    }

    [HttpGet("by-order/{orderId:int}")]
    public async Task<ActionResult<IEnumerable<ShipmentResponse>>> GetByOrderId(
        int orderId,
        [FromQuery] string? statusFilter = null,
        CancellationToken ct = default)
    {
        var responses = await Adapter.GetShipmentsByOrderIdAsync(orderId, statusFilter, ct);
        return Ok(responses);
    }

    [HttpPost]
    public async Task<ActionResult<ShipmentResponse>> Create([FromBody] CreateShipmentRequest request, CancellationToken ct)
    {
        var response = await Adapter.CreateShipmentAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id = response.Id }, response);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateShipmentRequest request, CancellationToken ct)
    {
        if (id != request.Id)
            return BadRequest("ID mismatch");

        await Adapter.UpdateShipmentAsync(request, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await Adapter.DeleteShipmentAsync(id, ct);
        return NoContent();
    }
}
