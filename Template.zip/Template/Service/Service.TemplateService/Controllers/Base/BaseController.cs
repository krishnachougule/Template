using Microsoft.AspNetCore.Mvc;

namespace ICG.Fulfillment.Service.TemplateService.Controllers.Base;

/// <summary>
/// Base controller providing common configuration and a typed adapter instance.
/// Mirrors the BaseAdapter and BaseFacade patterns used elsewhere in the service.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public abstract class BaseController<TAdapter> : ControllerBase
{
    protected readonly TAdapter Adapter;

    protected BaseController(TAdapter adapter)
    {
        Adapter = adapter;
    }

    /// <summary>
    /// Returns <see cref="OkObjectResult"/> when <paramref name="value"/> is non-null,
    /// otherwise returns <see cref="NotFoundResult"/>.
    /// </summary>
    protected ActionResult<T> OkOrNotFound<T>(T? value) where T : class
        => value is null ? NotFound() : Ok(value);
}