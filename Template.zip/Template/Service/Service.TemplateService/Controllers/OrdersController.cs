using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Controllers.Base;
using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using Microsoft.AspNetCore.Mvc;

namespace ICG.Fulfillment.Service.TemplateService.Controllers;

/// <summary>
/// Controller for Order operations.
/// </summary>
public class OrdersController : BaseController<IOrderAdapter>
{
    public OrdersController(IOrderAdapter adapter) : base(adapter) { }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<OrderResponse>> GetById(int id, CancellationToken ct)
    {
        var response = await Adapter.GetOrderByIdAsync(id, ct);
        return OkOrNotFound(response);
    }

    [HttpGet("by-order-number/{orderNumber}")]
    public async Task<ActionResult<OrderResponse>> GetByOrderNumber(string orderNumber, CancellationToken ct)
    {
        var response = await Adapter.GetOrderByOrderNumberAsync(orderNumber, ct);
        return OkOrNotFound(response);
    }

    [HttpGet("by-customer/{customerId}")]
    public async Task<ActionResult<IEnumerable<OrderResponse>>> GetByCustomerId(
        string customerId, 
        [FromQuery] string? statusFilter = null,
        [FromQuery] int? pageNumber = null,
        [FromQuery] int? pageSize = null,
        CancellationToken ct = default)
    {
        var responses = await Adapter.GetOrdersByCustomerIdAsync(customerId, statusFilter, pageNumber, pageSize, ct);
        return Ok(responses);
    }

    [HttpPost]
    public async Task<ActionResult<OrderResponse>> Create([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        var response = await Adapter.CreateOrderAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id = response.Id }, response);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateOrderRequest request, CancellationToken ct)
    {
        if (id != request.Id)
            return BadRequest("ID mismatch");

        await Adapter.UpdateOrderAsync(request, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await Adapter.DeleteOrderAsync(id, ct);
        return NoContent();
    }
}
