using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Controllers.Base;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using Microsoft.AspNetCore.Mvc;

namespace ICG.Fulfillment.Service.TemplateService.Controllers;

/// <summary>
/// Controller for ShipmentLine operations.
/// </summary>
public class ShipmentLinesController : BaseController<IShipmentLineAdapter>
{
    public ShipmentLinesController(IShipmentLineAdapter adapter) : base(adapter) { }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ShipmentLineResponse>> GetById(int id, CancellationToken ct)
    {
        var response = await Adapter.GetShipmentLineByIdAsync(id, ct);
        return OkOrNotFound(response);
    }

    [HttpGet("by-shipment/{shipmentId:int}")]
    public async Task<ActionResult<IEnumerable<ShipmentLineResponse>>> GetByShipmentId(
        int shipmentId,
        [FromQuery] string? statusFilter = null,
        CancellationToken ct = default)
    {
        var responses = await Adapter.GetShipmentLinesByShipmentIdAsync(shipmentId, statusFilter, ct);
        return Ok(responses);
    }

    [HttpGet("by-order/{orderId:int}")]
    public async Task<ActionResult<IEnumerable<ShipmentLineResponse>>> GetByOrderId(
        int orderId,
        CancellationToken ct = default)
    {
        var responses = await Adapter.GetShipmentLinesByOrderIdAsync(orderId, ct);
        return Ok(responses);
    }
}
