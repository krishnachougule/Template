using Asp.Versioning;
using IGC.Fulfillment.Shared.WebApi.Extensions;
using IGC.Fulfillment.Shared.Observability;
using ICG.Fulfillment.Service.TemplateService.Data;
using IGC.Fulfillment.Shared.ServiceProxy;
using IGC.Fulfillment.Shared.Translator;
using Microsoft.AspNetCore.RateLimiting;

// ---------------------------------------------------------------------------
// Builder
// ---------------------------------------------------------------------------
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddObservability(builder.Configuration, builder.Environment.EnvironmentName);
builder.Services.AddDataServices(builder.Configuration);
builder.Services.AddTranslatorService();

// Single platform call � registers CORS, Swagger (dev), and all convention-scanned types
builder.Services.AddPlatform(
    builder.Configuration,
    builder.Environment,
    typeof(Program).Assembly
);

builder.Services.AddHttpContextAccessor();
builder.Services.AddControllers();
builder.Services.AddAuthorization();
builder.Services.AddHealthChecks();

builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("default", limiterOptions =>
    {
        limiterOptions.PermitLimit = 100;
        limiterOptions.Window = TimeSpan.FromMinutes(1);
    });
});

builder.Services.AddDistributedMemoryCache();
builder.Services.AddApiVersioning(options =>
{
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.ReportApiVersions = true;
});

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------
var app = builder.Build();

// Single pipeline call � Swagger (dev), headers, correlation, exceptions, observability, routing
app.UsePlatform();

// ---------------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------------
app.Run();
