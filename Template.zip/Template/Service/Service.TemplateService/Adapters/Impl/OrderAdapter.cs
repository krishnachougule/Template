using ICG.Fulfillment.Service.TemplateService.Adapters.Base;
using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Impl;

/// <summary>
/// Order Adapter implementation - handles translation between DTOs and Business Entities.
/// </summary>
public class OrderAdapter : BaseAdapter<IOrderFacade>, IOrderAdapter
{
    public OrderAdapter(IOrderFacade facade, ITranslatorService translator, ILogger<OrderAdapter> logger)
        : base(facade, translator, logger)
    {
    }

    public Task<OrderResponse?> GetOrderByIdAsync(int id, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = await Facade.GetOrderByIdAsync(id, ct);
            return businessEntity != null
                ? Translator.Map<OrderResponse>(businessEntity)
                : null;
        }, ct: ct);

    public Task<OrderResponse?> GetOrderByOrderNumberAsync(string orderNumber, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = await Facade.GetOrderByOrderNumberAsync(orderNumber, ct);
            return businessEntity != null
                ? Translator.Map<OrderResponse>(businessEntity)
                : null;
        }, ct: ct);

    public Task<IEnumerable<OrderResponse>> GetOrdersByCustomerIdAsync(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntities = await Facade.GetOrdersByCustomerIdAsync(customerId, statusFilter, pageNumber, pageSize, ct);
            return Translator.MapRange<OrderResponse>(businessEntities);
        }, ct: ct);

    public Task<OrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = Translator.Map<OrderBE>(request);
            var created = await Facade.CreateOrderAsync(businessEntity, ct);
            return Translator.Map<OrderResponse>(created);
        }, ct: ct);

    public Task UpdateOrderAsync(UpdateOrderRequest request, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = Translator.Map<OrderBE>(request);
            await Facade.UpdateOrderAsync(businessEntity, ct);
        }, ct: ct);

    public Task DeleteOrderAsync(int id, CancellationToken ct = default)
        => ExecuteAsync(() => Facade.DeleteOrderAsync(id, ct), ct: ct);
}
