using ICG.Fulfillment.Service.TemplateService.Adapters.Base;
using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Impl;

/// <summary>
/// ShipmentLine Adapter implementation - handles translation between DTOs and Business Entities.
/// </summary>
public class ShipmentLineAdapter : BaseAdapter<IShipmentLineFacade>, IShipmentLineAdapter
{
    public ShipmentLineAdapter(IShipmentLineFacade facade, ITranslatorService translator, ILogger<ShipmentLineAdapter> logger)
        : base(facade, translator, logger)
    {
    }

    public Task<ShipmentLineResponse?> GetShipmentLineByIdAsync(int id, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = await Facade.GetShipmentLineByIdAsync(id, ct);
            return businessEntity != null
                ? Translator.Map<ShipmentLineResponse>(businessEntity)
                : null;
        }, ct: ct);

    public Task<IEnumerable<ShipmentLineResponse>> GetShipmentLinesByShipmentIdAsync(int shipmentId, string? statusFilter = null, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntities = await Facade.GetShipmentLinesByShipmentIdAsync(shipmentId, statusFilter, ct);
            return Translator.MapRange<ShipmentLineResponse>(businessEntities);
        }, ct: ct);

    public Task<IEnumerable<ShipmentLineResponse>> GetShipmentLinesByOrderIdAsync(int orderId, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntities = await Facade.GetShipmentLinesByOrderIdAsync(orderId, ct);
            return Translator.MapRange<ShipmentLineResponse>(businessEntities);
        }, ct: ct);
}
