using ICG.Fulfillment.Service.TemplateService.Adapters.Base;
using ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;
using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Impl;

/// <summary>
/// Shipment Adapter implementation - handles translation between DTOs and Business Entities.
/// </summary>
public class ShipmentAdapter : BaseAdapter<IShipmentFacade>, IShipmentAdapter
{
    public ShipmentAdapter(IShipmentFacade facade, ITranslatorService translator, ILogger<ShipmentAdapter> logger)
        : base(facade, translator, logger)
    {
    }

    public Task<ShipmentResponse?> GetShipmentByIdAsync(int id, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = await Facade.GetShipmentByIdAsync(id, ct);
            return businessEntity != null
                ? Translator.Map<ShipmentResponse>(businessEntity)
                : null;
        }, ct: ct);

    public Task<ShipmentResponse?> GetShipmentByShipmentNumberAsync(string shipmentNumber, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = await Facade.GetShipmentByShipmentNumberAsync(shipmentNumber, ct);
            return businessEntity != null
                ? Translator.Map<ShipmentResponse>(businessEntity)
                : null;
        }, ct: ct);

    public Task<IEnumerable<ShipmentResponse>> GetShipmentsByOrderIdAsync(int orderId, string? statusFilter = null, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntities = await Facade.GetShipmentsByOrderIdAsync(orderId, statusFilter, ct);
            return Translator.MapRange<ShipmentResponse>(businessEntities);
        }, ct: ct);

    public Task<ShipmentResponse> CreateShipmentAsync(CreateShipmentRequest request, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = Translator.Map<ShipmentBE>(request);
            var created = await Facade.CreateShipmentAsync(businessEntity, ct);
            return Translator.Map<ShipmentResponse>(created);
        }, ct: ct);

    public Task UpdateShipmentAsync(UpdateShipmentRequest request, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            var businessEntity = Translator.Map<ShipmentBE>(request);
            await Facade.UpdateShipmentAsync(businessEntity, ct);
        }, ct: ct);

    public Task DeleteShipmentAsync(int id, CancellationToken ct = default)
        => ExecuteAsync(() => Facade.DeleteShipmentAsync(id, ct), ct: ct);
}
