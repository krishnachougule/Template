using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;

/// <summary>
/// Adapter interface for Order operations.
/// Handles translation between DTOs and Business Entities.
/// </summary>
public interface IOrderAdapter
{
    Task<OrderResponse?> GetOrderByIdAsync(int id, CancellationToken ct = default);
    Task<OrderResponse?> GetOrderByOrderNumberAsync(string orderNumber, CancellationToken ct = default);
    Task<IEnumerable<OrderResponse>> GetOrdersByCustomerIdAsync(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null, CancellationToken ct = default);
    Task<OrderResponse> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default);
    Task UpdateOrderAsync(UpdateOrderRequest request, CancellationToken ct = default);
    Task DeleteOrderAsync(int id, CancellationToken ct = default);
}
