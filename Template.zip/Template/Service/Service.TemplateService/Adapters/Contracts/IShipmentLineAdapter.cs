using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;

/// <summary>
/// Adapter interface for ShipmentLine operations.
/// Handles translation between DTOs and Business Entities.
/// </summary>
public interface IShipmentLineAdapter
{
    Task<ShipmentLineResponse?> GetShipmentLineByIdAsync(int id, CancellationToken ct = default);
    Task<IEnumerable<ShipmentLineResponse>> GetShipmentLinesByShipmentIdAsync(int shipmentId, string? statusFilter = null, CancellationToken ct = default);
    Task<IEnumerable<ShipmentLineResponse>> GetShipmentLinesByOrderIdAsync(int orderId, CancellationToken ct = default);
}
