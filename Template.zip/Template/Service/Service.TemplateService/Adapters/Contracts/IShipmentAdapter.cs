using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Contracts;

/// <summary>
/// Adapter interface for Shipment operations.
/// Handles translation between DTOs and Business Entities.
/// </summary>
public interface IShipmentAdapter
{
    Task<ShipmentResponse?> GetShipmentByIdAsync(int id, CancellationToken ct = default);
    Task<ShipmentResponse?> GetShipmentByShipmentNumberAsync(string shipmentNumber, CancellationToken ct = default);
    Task<IEnumerable<ShipmentResponse>> GetShipmentsByOrderIdAsync(int orderId, string? statusFilter = null, CancellationToken ct = default);
    Task<ShipmentResponse> CreateShipmentAsync(CreateShipmentRequest request, CancellationToken ct = default);
    Task UpdateShipmentAsync(UpdateShipmentRequest request, CancellationToken ct = default);
    Task DeleteShipmentAsync(int id, CancellationToken ct = default);
}
