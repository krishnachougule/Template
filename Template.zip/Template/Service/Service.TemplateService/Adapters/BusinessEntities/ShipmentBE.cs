namespace ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

/// <summary>
/// Business entity for Shipment - used in the Facade layer.
/// </summary>
public class ShipmentBE
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string ShipmentNumber { get; set; } = string.Empty;
    public short ShipmentSequence { get; set; }
    public string CarrierCode { get; set; } = string.Empty;
    public string ServiceLevel { get; set; } = string.Empty;
    public string? TrackingNumber { get; set; }
    public string WarehouseCode { get; set; } = string.Empty;
    public string ShipToName { get; set; } = string.Empty;
    public string ShipToAddress1 { get; set; } = string.Empty;
    public string? ShipToAddress2 { get; set; }
    public string ShipToCity { get; set; } = string.Empty;
    public string ShipToState { get; set; } = string.Empty;
    public string ShipToZip { get; set; } = string.Empty;
    public string ShipToCountry { get; set; } = "US";
    public short TotalPackages { get; set; }
    public decimal TotalWeightKg { get; set; }
    public decimal ShippingCost { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? FailureReason { get; set; }
    public DateTime? EstimatedDelivery { get; set; }
    public DateTime? DispatchedAt { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public string UpdatedBy { get; set; } = string.Empty;
    public int RowVersion { get; set; }
}
