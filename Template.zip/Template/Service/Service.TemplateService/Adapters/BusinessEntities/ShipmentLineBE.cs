namespace ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

/// <summary>
/// Business entity for ShipmentLine - used in the Facade layer.
/// </summary>
public class ShipmentLineBE
{
    public int Id { get; set; }
    public int ShipmentId { get; set; }
    public string ShipmentNumber { get; set; } = string.Empty;
    public int OrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public short LineNumber { get; set; }
    public string OrderLineRef { get; set; } = string.Empty;
    public string Sku { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductCategory { get; set; } = string.Empty;
    public int QuantityOrdered { get; set; }
    public int QuantityShipped { get; set; }
    public int QuantityBackordered { get; set; }
    public string UnitOfMeasure { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public decimal LineDiscount { get; set; }
    public decimal LineTotal { get; set; }
    public string Currency { get; set; } = "USD";
    public string WarehouseBin { get; set; } = string.Empty;
    public string? LotNumber { get; set; }
    public string? SerialNumber { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? BackorderReason { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public string UpdatedBy { get; set; } = string.Empty;
    public int RowVersion { get; set; }
}
