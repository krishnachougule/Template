namespace ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

/// <summary>
/// Business entity for a JSONPlaceholder user - used in the Facade layer.
/// </summary>
public class UserBE
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Website { get; set; } = string.Empty;
}
