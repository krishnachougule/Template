namespace ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;

/// <summary>
/// Business entity for Order - used in the Facade layer.
/// </summary>
public class OrderBE
{
    public int Id { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string CustomerId { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string? CustomerPoRef { get; set; }
    public string OrderType { get; set; } = string.Empty;
    public string Channel { get; set; } = string.Empty;
    public string? SalesRepId { get; set; }
    public decimal SubtotalAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string Currency { get; set; } = "USD";
    public string Status { get; set; } = string.Empty;
    public string? CancellationReason { get; set; }
    public string CreditStatus { get; set; } = string.Empty;
    public DateTime? CreditCheckedAt { get; set; }
    public DateTime? RequestedShipDate { get; set; }
    public DateTime? ConfirmedShipDate { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public string UpdatedBy { get; set; } = string.Empty;
    public int RowVersion { get; set; }
}
