using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.DTOs.Responses;
using IGC.Fulfillment.Shared.Translator;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Translators;

public class OrderBE_OrderResponse : BaseTranslator<OrderBE, OrderResponse>
{
}
