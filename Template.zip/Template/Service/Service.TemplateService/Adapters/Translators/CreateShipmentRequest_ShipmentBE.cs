using ICG.Fulfillment.Service.TemplateService.Adapters.BusinessEntities;
using ICG.Fulfillment.Service.TemplateService.DTOs.Requests;
using IGC.Fulfillment.Shared.Translator;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Translators;

public class CreateShipmentRequest_ShipmentBE : BaseTranslator<CreateShipmentRequest, ShipmentBE>
{
}
