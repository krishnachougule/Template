﻿using System.Diagnostics;
using System.Runtime.CompilerServices;
using ICG.Fulfillment.Service.TemplateService.Facades.Contracts;
using IGC.Fulfillment.Shared.Observability.Diagnostics;
using IGC.Fulfillment.Shared.Translator.Interfaces;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;

namespace ICG.Fulfillment.Service.TemplateService.Adapters.Base;

/// <summary>
/// Base adapter class providing common infrastructure for all adapters.
/// Automatically instruments every operation with tracing, metrics and structured logging.
/// All observability paths are guarded so no overhead is incurred when signals are disabled.
/// </summary>
public abstract class BaseAdapter<T> where T : IFacade
{
    protected readonly ITranslatorService Translator;
    protected readonly T Facade;
    protected readonly ILogger Logger;

    // Cached once per concrete type — GetType().Name is a virtual call + string; cache it.
    private readonly string _adapterName;

    private static readonly Action<ILogger, string, string, double, Exception?> _logSuccess =
        LoggerMessage.Define<string, string, double>(
            LogLevel.Information,
            new EventId(20, "AdapterOperation"),
            "Adapter {AdapterName} executed {OperationName} in {ElapsedMs:F1}ms");

    private static readonly Action<ILogger, string, string, double, Exception?> _logFailure =
        LoggerMessage.Define<string, string, double>(
            LogLevel.Error,
            new EventId(21, "AdapterOperationFailed"),
            "Adapter {AdapterName} failed {OperationName} after {ElapsedMs:F1}ms");

    protected BaseAdapter(T facade, ITranslatorService translator, ILogger logger)
    {
        Facade = facade;
        Translator = translator;
        Logger = logger;
        _adapterName = GetType().Name; // resolved once at construction, reused on every call
    }

    /// <summary>
    /// Executes a value-returning operation with full observability:
    /// tracing span, success/failure metrics, and structured logging.
    /// Each signal is individually guarded — no overhead when disabled.
    /// The caller's method name is automatically captured via <see cref="CallerMemberNameAttribute"/>.
    /// </summary>
    protected async Task<TResult> ExecuteAsync<TResult>(
        Func<Task<TResult>> operation,
        [CallerMemberName] string operationName = "",
        CancellationToken ct = default)
    {
        // ── Tracing ───────────────────────────────────────────────────────────
        // ActivitySource.StartActivity returns null when no listener is attached (tracing off).
        // The activity name string is only built when HasListeners is true to avoid
        // an eager string allocation that would be thrown away immediately.
        using var activity = ObservabilityDefaults.ActivitySource.HasListeners()
            ? ObservabilityDefaults.ActivitySource.StartActivity(
                $"{_adapterName}.{operationName}",
                ActivityKind.Internal)
            : null;

        activity?.SetTag("adapter.name", _adapterName);
        activity?.SetTag("adapter.operation", operationName);

        // ── Timing ────────────────────────────────────────────────────────────
        // Only start the stopwatch when at least one consumer needs the elapsed time:
        // metrics histogram or an enabled log level. Avoids the timer overhead otherwise.
        var needsTiming = ObservabilityDefaults.AdapterOperationDuration.Enabled
                          || Logger.IsEnabled(LogLevel.Information);

        var startTimestamp = needsTiming ? Stopwatch.GetTimestamp() : 0L;

        try
        {
            var result = await operation();

            // ── Success metrics ───────────────────────────────────────────────
            if (ObservabilityDefaults.AdapterOperationCounter.Enabled)
            {
                ObservabilityDefaults.AdapterOperationCounter.Add(1,
                    new KeyValuePair<string, object?>("adapter.name", _adapterName),
                    new KeyValuePair<string, object?>("adapter.operation", operationName),
                    new KeyValuePair<string, object?>("outcome", "success"));
            }

            if (needsTiming)
            {
                var elapsedMs = GetElapsedMs(startTimestamp);

                if (ObservabilityDefaults.AdapterOperationDuration.Enabled)
                {
                    ObservabilityDefaults.AdapterOperationDuration.Record(elapsedMs,
                        new KeyValuePair<string, object?>("adapter.name", _adapterName),
                        new KeyValuePair<string, object?>("adapter.operation", operationName));
                }

                // LoggerMessage.Define guards IsEnabled internally — passing elapsedMs
                // only makes sense once we know timing was needed anyway.
                _logSuccess(Logger, _adapterName, operationName, elapsedMs, null);
            }

            return result;
        }
        catch (Exception ex)
        {
            // ── Tracing ───────────────────────────────────────────────────────
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            activity?.RecordException(ex);

            // ── Failure metrics ───────────────────────────────────────────────
            if (ObservabilityDefaults.AdapterOperationCounter.Enabled)
            {
                ObservabilityDefaults.AdapterOperationCounter.Add(1,
                    new KeyValuePair<string, object?>("adapter.name", _adapterName),
                    new KeyValuePair<string, object?>("adapter.operation", operationName),
                    new KeyValuePair<string, object?>("outcome", "failure"));
            }

            if (ObservabilityDefaults.ExceptionCounter.Enabled)
            {
                ObservabilityDefaults.ExceptionCounter.Add(1,
                    new KeyValuePair<string, object?>("exception.type", ex.GetType().Name),
                    new KeyValuePair<string, object?>("adapter.name", _adapterName));
            }

            // ── Failure logging ───────────────────────────────────────────────
            var elapsedMs = needsTiming ? GetElapsedMs(startTimestamp) : 0d;
            _logFailure(Logger, _adapterName, operationName, elapsedMs, ex);

            throw;
        }
    }

    /// <summary>
    /// Executes a void operation by delegating to the generic overload.
    /// All observability (tracing, metrics, logging) is inherited from there.
    /// The caller's method name is automatically captured via <see cref="CallerMemberNameAttribute"/>.
    /// </summary>
    protected async Task ExecuteAsync(
        Func<Task> operation,
        [CallerMemberName] string operationName = "",
        CancellationToken ct = default)
    {
        await ExecuteAsync<object?>(
            async () => { await operation(); return null; },
            operationName: operationName,
            ct: ct);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Computes elapsed milliseconds from a <see cref="Stopwatch.GetTimestamp"/> snapshot.
    /// Uses timestamp arithmetic instead of a <see cref="Stopwatch"/> instance — avoids
    /// the object allocation entirely while retaining the same high-resolution accuracy.
    /// </summary>
    private static double GetElapsedMs(long startTimestamp)
        => (Stopwatch.GetTimestamp() - startTimestamp) * 1000d / Stopwatch.Frequency;
}
