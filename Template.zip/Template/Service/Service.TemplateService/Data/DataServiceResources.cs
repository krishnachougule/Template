namespace ICG.Fulfillment.Service.TemplateService.Data;

/// <summary>
/// Centralized repository for all stored procedure names used in the TemplateService.
/// </summary>
internal static class DataServiceResources
{
    internal struct Order
    {
        internal const string GetById = "template_service.usp_TemplateService_GetOrderById";
        internal const string GetByOrderNumber = "template_service.usp_TemplateService_GetOrderByOrderNumber";
        internal const string GetByCustomerId = "template_service.usp_TemplateService_GetOrdersByCustomerId";
        internal const string Insert = "template_service.usp_TemplateService_InsertOrder";
        internal const string Update = "template_service.usp_TemplateService_UpdateOrderById";
        internal const string Delete = "template_service.usp_TemplateService_DeleteOrderById";
    }

    internal struct Shipment
    {
        internal const string GetById = "template_service.usp_TemplateService_GetShipmentById";
        internal const string GetByShipmentNumber = "template_service.usp_TemplateService_GetShipmentByShipmentNumber";
        internal const string GetByOrderId = "template_service.usp_TemplateService_GetShipmentsByOrderId";
        internal const string Insert = "template_service.usp_TemplateService_InsertShipment";
        internal const string Update = "template_service.usp_TemplateService_UpdateShipmentById";
        internal const string Delete = "template_service.usp_TemplateService_DeleteShipmentById";
    }

    internal struct ShipmentLine
    {
        internal const string GetById = "template_service.usp_TemplateService_GetShipmentLineById";
        internal const string GetByShipmentId = "template_service.usp_TemplateService_GetShipmentLinesByShipmentId";
        internal const string GetByOrderId = "template_service.usp_TemplateService_GetShipmentLinesByOrderId";
        internal const string Insert = "template_service.usp_TemplateService_InsertShipmentLine";
        internal const string Update = "template_service.usp_TemplateService_UpdateShipmentLineById";
        internal const string Delete = "template_service.usp_TemplateService_DeleteShipmentLineById";
    }
}
