using ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ICG.Fulfillment.Service.TemplateService.Data;

/// <summary>
/// Aggregates all repositories into a single injectable data service.
/// Repositories are resolved from the DI container � no manual wiring needed
/// when a new repository is added. Just add the property and it resolves automatically.
/// </summary>
public class ServiceDataService : IServiceDataService
{
    public IOrderRepository Orders { get; }
    public IShipmentRepository Shipments { get; }
    public IShipmentLineRepository ShipmentLines { get; }

    public ServiceDataService(IServiceProvider serviceProvider)
    {
        Orders = serviceProvider.GetRequiredService<IOrderRepository>();
        Shipments = serviceProvider.GetRequiredService<IShipmentRepository>();
        ShipmentLines = serviceProvider.GetRequiredService<IShipmentLineRepository>();
    }
}
