using IGC.Fulfillment.Shared.DataProxy;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;
using IGC.Fulfillment.Shared.DataProxy.Enums;
using IGC.Fulfillment.Shared.WebApi.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace ICG.Fulfillment.Service.TemplateService.Data;

/// <summary>
/// Registers IDataService and all repositories, data services, facades, and adapters in this assembly
/// using naming-convention scanning from Shared.WebApi.
/// </summary>
public static class DataServiceRegistration
{
    /// <summary>
    /// Registers IDataService with the database provider resolved from configuration.
    /// Reads "DatabaseProvider" setting (SqlServer, MySql) and "DefaultConnection" connection string.
    /// All repositories, data services, facades, and adapters are auto-registered by naming convention.
    /// </summary>
    public static IServiceCollection AddDataServices(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection string not found in configuration.");

        var providerName = configuration["DatabaseProvider"] ?? "SqlServer";

        services.AddScoped<IDataService>(sp => new DataService(providerName, connectionString));
        services.AddScopedByConvention(Assembly.GetExecutingAssembly());

        return services;
    }

    /// <summary>
    /// Registers IDataService with an explicit database provider type.
    /// All repositories, data services, facades, and adapters are auto-registered by naming convention.
    /// </summary>
    public static IServiceCollection AddDataServices(
        this IServiceCollection services,
        IConfiguration configuration,
        DatabaseProvider provider)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection string not found in configuration.");

        services.AddScoped<IDataService>(sp => new DataService(provider, connectionString));
        services.AddScopedByConvention(Assembly.GetExecutingAssembly());

        return services;
    }

    /// <summary>
    /// Registers IDataService with explicit connection string and provider name.
    /// All repositories, data services, facades, and adapters are auto-registered by naming convention.
    /// </summary>
    public static IServiceCollection AddDataServices(
        this IServiceCollection services,
        string providerName,
        string connectionString)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(connectionString, nameof(connectionString));
        ArgumentException.ThrowIfNullOrWhiteSpace(providerName, nameof(providerName));

        services.AddScoped<IDataService>(sp => new DataService(providerName, connectionString));
        services.AddScopedByConvention(Assembly.GetExecutingAssembly());

        return services;
    }
}
