using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;
using IGC.Fulfillment.Shared.DataProxy;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories;

/// <summary>
/// Repository implementation for Order data access.
/// Uses snake_case property names to match database columns.
/// </summary>
public class OrderRepository : Repository, IOrderRepository
{
    public OrderRepository(IDataService dataService) : base(dataService) { }

    public OrderEntity GetById(int id)
    {
        return QueryFirst<OrderEntity>(DataServiceResources.Order.GetById, new { Id = id });
    }

    public OrderEntity? GetByOrderNumber(string orderNumber)
    {
        return QueryFirstOrDefault<OrderEntity>(DataServiceResources.Order.GetByOrderNumber, new { OrderNumber = orderNumber });
    }

    public IEnumerable<OrderEntity> GetByCustomerId(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null)
    {
        return Query<OrderEntity>(DataServiceResources.Order.GetByCustomerId, new 
        { 
            CustomerId = customerId,
            StatusFilter = statusFilter,
            PageNumber = pageNumber,
            PageSize = pageSize
        });
    }

    public void Create(OrderEntity entity)
    {
        var id = QueryFirst<int>(DataServiceResources.Order.Insert, new
        {
            entity.order_number,
            entity.customer_id,
            entity.customer_name,
            entity.customer_po_ref,
            entity.order_type,
            entity.channel,
            entity.sales_rep_id,
            entity.subtotal_amount,
            entity.discount_amount,
            entity.tax_amount,
            entity.total_amount,
            entity.currency,
            entity.status,
            entity.cancellation_reason,
            entity.credit_status,
            entity.credit_checked_at,
            entity.requested_ship_date,
            entity.confirmed_ship_date,
            entity.created_by,
            entity.updated_by
        });
        entity.id = id;
    }

    public void Update(OrderEntity entity)
    {
        Execute(DataServiceResources.Order.Update, new
        {
            entity.id,
            entity.order_number,
            entity.customer_id,
            entity.customer_name,
            entity.customer_po_ref,
            entity.order_type,
            entity.channel,
            entity.sales_rep_id,
            entity.subtotal_amount,
            entity.discount_amount,
            entity.tax_amount,
            entity.total_amount,
            entity.currency,
            entity.status,
            entity.cancellation_reason,
            entity.credit_status,
            entity.credit_checked_at,
            entity.requested_ship_date,
            entity.confirmed_ship_date,
            entity.updated_by,
            entity.row_version
        });
    }

    public void Delete(OrderEntity entity)
    {
        Execute(DataServiceResources.Order.Delete, new { Id = entity.id });
    }
}
