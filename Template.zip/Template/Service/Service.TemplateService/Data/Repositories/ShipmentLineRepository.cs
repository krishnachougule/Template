using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;
using IGC.Fulfillment.Shared.DataProxy;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories;

/// <summary>
/// Repository implementation for ShipmentLine data access.
/// Uses snake_case property names to match database columns.
/// </summary>
public class ShipmentLineRepository : Repository, IShipmentLineRepository
{
    public ShipmentLineRepository(IDataService dataService) : base(dataService) { }

    public ShipmentLineEntity GetById(int id)
    {
        return QueryFirst<ShipmentLineEntity>(DataServiceResources.ShipmentLine.GetById, new { Id = id });
    }

    public IEnumerable<ShipmentLineEntity> GetByShipmentId(int shipmentId, string? statusFilter = null)
    {
        return Query<ShipmentLineEntity>(DataServiceResources.ShipmentLine.GetByShipmentId, new 
        { 
            ShipmentId = shipmentId,
            StatusFilter = statusFilter
        });
    }

    public IEnumerable<ShipmentLineEntity> GetByOrderId(int orderId)
    {
        return Query<ShipmentLineEntity>(DataServiceResources.ShipmentLine.GetByOrderId, new { OrderId = orderId });
    }

    public void Create(ShipmentLineEntity entity)
    {
        var id = QueryFirst<int>(DataServiceResources.ShipmentLine.Insert, new
        {
            entity.shipment_id,
            entity.shipment_number,
            entity.order_id,
            entity.order_number,
            entity.line_number,
            entity.order_line_ref,
            entity.sku,
            entity.product_name,
            entity.product_category,
            entity.quantity_ordered,
            entity.quantity_shipped,
            entity.quantity_backordered,
            entity.unit_of_measure,
            entity.unit_price,
            entity.line_discount,
            entity.line_total,
            entity.currency,
            entity.warehouse_bin,
            entity.lot_number,
            entity.serial_number,
            entity.status,
            entity.backorder_reason,
            entity.created_by,
            entity.updated_by
        });
        entity.id = id;
    }

    public void Update(ShipmentLineEntity entity)
    {
        Execute(DataServiceResources.ShipmentLine.Update, new
        {
            entity.id,
            entity.shipment_id,
            entity.shipment_number,
            entity.order_id,
            entity.order_number,
            entity.line_number,
            entity.order_line_ref,
            entity.sku,
            entity.product_name,
            entity.product_category,
            entity.quantity_ordered,
            entity.quantity_shipped,
            entity.quantity_backordered,
            entity.unit_of_measure,
            entity.unit_price,
            entity.line_discount,
            entity.line_total,
            entity.currency,
            entity.warehouse_bin,
            entity.lot_number,
            entity.serial_number,
            entity.status,
            entity.backorder_reason,
            entity.updated_by,
            entity.row_version
        });
    }

    public void Delete(ShipmentLineEntity entity)
    {
        Execute(DataServiceResources.ShipmentLine.Delete, new { Id = entity.id });
    }
}
