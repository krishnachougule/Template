using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;

/// <summary>
/// Repository interface for Shipment data access operations.
/// </summary>
public interface IShipmentRepository : IRepository<ShipmentEntity, int>
{
    ShipmentEntity? GetByShipmentNumber(string shipmentNumber);
    IEnumerable<ShipmentEntity> GetByOrderId(int orderId, string? statusFilter = null);
}
