using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;

/// <summary>
/// Repository interface for Order data access operations.
/// </summary>
public interface IOrderRepository : IRepository<OrderEntity, int>
{
    OrderEntity? GetByOrderNumber(string orderNumber);
    IEnumerable<OrderEntity> GetByCustomerId(string customerId, string? statusFilter = null, int? pageNumber = null, int? pageSize = null);
}
