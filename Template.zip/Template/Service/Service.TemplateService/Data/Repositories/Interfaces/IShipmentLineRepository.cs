using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;

/// <summary>
/// Repository interface for ShipmentLine data access operations.
/// </summary>
public interface IShipmentLineRepository : IRepository<ShipmentLineEntity, int>
{
    IEnumerable<ShipmentLineEntity> GetByShipmentId(int shipmentId, string? statusFilter = null);
    IEnumerable<ShipmentLineEntity> GetByOrderId(int orderId);
}
