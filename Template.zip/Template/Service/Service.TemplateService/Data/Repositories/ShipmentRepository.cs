using ICG.Fulfillment.Service.TemplateService.Data.Entities;
using ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;
using IGC.Fulfillment.Shared.DataProxy;
using IGC.Fulfillment.Shared.DataProxy.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data.Repositories;

/// <summary>
/// Repository implementation for Shipment data access.
/// Uses snake_case property names to match database columns.
/// </summary>
public class ShipmentRepository : Repository, IShipmentRepository
{
    public ShipmentRepository(IDataService dataService) : base(dataService) { }

    public ShipmentEntity GetById(int id)
    {
        return QueryFirst<ShipmentEntity>(DataServiceResources.Shipment.GetById, new { Id = id });
    }

    public ShipmentEntity? GetByShipmentNumber(string shipmentNumber)
    {
        return QueryFirstOrDefault<ShipmentEntity>(DataServiceResources.Shipment.GetByShipmentNumber, new { ShipmentNumber = shipmentNumber });
    }

    public IEnumerable<ShipmentEntity> GetByOrderId(int orderId, string? statusFilter = null)
    {
        return Query<ShipmentEntity>(DataServiceResources.Shipment.GetByOrderId, new 
        { 
            OrderId = orderId,
            StatusFilter = statusFilter
        });
    }

    public void Create(ShipmentEntity entity)
    {
        var id = QueryFirst<int>(DataServiceResources.Shipment.Insert, new
        {
            entity.order_id,
            entity.order_number,
            entity.shipment_number,
            entity.shipment_sequence,
            entity.carrier_code,
            entity.service_level,
            entity.tracking_number,
            entity.warehouse_code,
            entity.ship_to_name,
            entity.ship_to_address1,
            entity.ship_to_address2,
            entity.ship_to_city,
            entity.ship_to_state,
            entity.ship_to_zip,
            entity.ship_to_country,
            entity.total_packages,
            entity.total_weight_kg,
            entity.shipping_cost,
            entity.status,
            entity.failure_reason,
            entity.estimated_delivery,
            entity.dispatched_at,
            entity.delivered_at,
            entity.created_by,
            entity.updated_by
        });
        entity.id = id;
    }

    public void Update(ShipmentEntity entity)
    {
        Execute(DataServiceResources.Shipment.Update, new
        {
            entity.id,
            entity.order_id,
            entity.order_number,
            entity.shipment_number,
            entity.shipment_sequence,
            entity.carrier_code,
            entity.service_level,
            entity.tracking_number,
            entity.warehouse_code,
            entity.ship_to_name,
            entity.ship_to_address1,
            entity.ship_to_address2,
            entity.ship_to_city,
            entity.ship_to_state,
            entity.ship_to_zip,
            entity.ship_to_country,
            entity.total_packages,
            entity.total_weight_kg,
            entity.shipping_cost,
            entity.status,
            entity.failure_reason,
            entity.estimated_delivery,
            entity.dispatched_at,
            entity.delivered_at,
            entity.updated_by,
            entity.row_version
        });
    }

    public void Delete(ShipmentEntity entity)
    {
        Execute(DataServiceResources.Shipment.Delete, new { Id = entity.id });
    }
}
