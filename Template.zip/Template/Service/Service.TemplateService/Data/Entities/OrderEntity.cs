using System.ComponentModel.DataAnnotations.Schema;

namespace ICG.Fulfillment.Service.TemplateService.Data.Entities;

/// <summary>
/// Domain entity representing an order in the database.
/// Property names match database column names exactly (snake_case).
/// </summary>
public class OrderEntity
{
    public int id { get; set; }
    public string order_number { get; set; } = string.Empty;
    public string customer_id { get; set; } = string.Empty;
    public string customer_name { get; set; } = string.Empty;
    public string? customer_po_ref { get; set; }
    public string order_type { get; set; } = string.Empty;
    public string channel { get; set; } = string.Empty;
    public string? sales_rep_id { get; set; }
    public decimal subtotal_amount { get; set; }
    public decimal discount_amount { get; set; }
    public decimal tax_amount { get; set; }
    public decimal total_amount { get; set; }
    public string currency { get; set; } = "USD";
    public string status { get; set; } = string.Empty;
    public string? cancellation_reason { get; set; }
    public string credit_status { get; set; } = string.Empty;
    public DateTime? credit_checked_at { get; set; }
    public DateTime? requested_ship_date { get; set; }
    public DateTime? confirmed_ship_date { get; set; }
    public DateTime created_at { get; set; }
    public DateTime updated_at { get; set; }
    public string created_by { get; set; } = string.Empty;
    public string updated_by { get; set; } = string.Empty;
    public int row_version { get; set; }
}
