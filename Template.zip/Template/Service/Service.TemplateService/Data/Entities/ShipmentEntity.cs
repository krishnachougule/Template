using System.ComponentModel.DataAnnotations.Schema;

namespace ICG.Fulfillment.Service.TemplateService.Data.Entities;

/// <summary>
/// Domain entity representing a shipment in the database.
/// Property names match database column names exactly (snake_case).
/// </summary>
public class ShipmentEntity
{
    public int id { get; set; }
    public int order_id { get; set; }
    public string order_number { get; set; } = string.Empty;
    public string shipment_number { get; set; } = string.Empty;
    public short shipment_sequence { get; set; }
    public string carrier_code { get; set; } = string.Empty;
    public string service_level { get; set; } = string.Empty;
    public string? tracking_number { get; set; }
    public string warehouse_code { get; set; } = string.Empty;
    public string ship_to_name { get; set; } = string.Empty;
    public string ship_to_address1 { get; set; } = string.Empty;
    public string? ship_to_address2 { get; set; }
    public string ship_to_city { get; set; } = string.Empty;
    public string ship_to_state { get; set; } = string.Empty;
    public string ship_to_zip { get; set; } = string.Empty;
    public string ship_to_country { get; set; } = "US";
    public short total_packages { get; set; }
    public decimal total_weight_kg { get; set; }
    public decimal shipping_cost { get; set; }
    public string status { get; set; } = string.Empty;
    public string? failure_reason { get; set; }
    public DateTime? estimated_delivery { get; set; }
    public DateTime? dispatched_at { get; set; }
    public DateTime? delivered_at { get; set; }
    public DateTime created_at { get; set; }
    public DateTime updated_at { get; set; }
    public string created_by { get; set; } = string.Empty;
    public string updated_by { get; set; } = string.Empty;
    public int row_version { get; set; }
}
