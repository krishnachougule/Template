using System.ComponentModel.DataAnnotations.Schema;

namespace ICG.Fulfillment.Service.TemplateService.Data.Entities;

/// <summary>
/// Domain entity representing a shipment line item in the database.
/// Property names match database column names exactly (snake_case).
/// </summary>
public class ShipmentLineEntity
{
    public int id { get; set; }
    public int shipment_id { get; set; }
    public string shipment_number { get; set; } = string.Empty;
    public int order_id { get; set; }
    public string order_number { get; set; } = string.Empty;
    public short line_number { get; set; }
    public string order_line_ref { get; set; } = string.Empty;
    public string sku { get; set; } = string.Empty;
    public string product_name { get; set; } = string.Empty;
    public string product_category { get; set; } = string.Empty;
    public int quantity_ordered { get; set; }
    public int quantity_shipped { get; set; }
    public int quantity_backordered { get; set; }
    public string unit_of_measure { get; set; } = string.Empty;
    public decimal unit_price { get; set; }
    public decimal line_discount { get; set; }
    public decimal line_total { get; set; }
    public string currency { get; set; } = "USD";
    public string warehouse_bin { get; set; } = string.Empty;
    public string? lot_number { get; set; }
    public string? serial_number { get; set; }
    public string status { get; set; } = string.Empty;
    public string? backorder_reason { get; set; }
    public DateTime created_at { get; set; }
    public DateTime updated_at { get; set; }
    public string created_by { get; set; } = string.Empty;
    public string updated_by { get; set; } = string.Empty;
    public int row_version { get; set; }
}
