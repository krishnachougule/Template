using ICG.Fulfillment.Service.TemplateService.Data.Repositories.Interfaces;

namespace ICG.Fulfillment.Service.TemplateService.Data;

/// <summary>
/// Aggregates all repositories into a single injectable data service for facades.
/// Facades inject this one class and access any repository they need.
/// </summary>
public interface IServiceDataService
{
    IOrderRepository Orders { get; }
    IShipmentRepository Shipments { get; }
    IShipmentLineRepository ShipmentLines { get; }
}
